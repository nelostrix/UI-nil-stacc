"""NIL Digital Twin — High-Fidelity Physics, Telemetry, and Operational State Twin."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class MotorCharacteristics:
    kt_torque_constant: float = 0.85  # Nm / A
    kv_speed_constant: float = 120.0  # RPM / V
    rotor_inertia: float = 0.00045   # kg*m^2
    winding_resistance: float = 1.2   # Ohms
    thermal_resistance: float = 1.8   # C / W
    max_continuous_torque: float = 12.0 # Nm
    peak_torque: float = 36.0          # Nm


@dataclass
class SensorConfig:
    sensor_id: str
    sensor_type: str  # camera, imu, lidar, encoder, ft
    sampling_rate_hz: float = 100.0
    noise_variance: float = 0.001
    calibration_matrix: List[List[float]] = field(default_factory=lambda: [
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
    ])
    bias: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    status: str = "calibrated"


@dataclass
class SafetyEnvelope:
    max_payload_kg: float = 15.0
    max_cartesian_speed: float = 1.5  # m/s
    max_joint_torque_pct: float = 90.0
    collision_stop_distance_m: float = 0.05
    e_stop_triggered: bool = False
    temperature_threshold_c: float = 75.0


@dataclass
class DigitalTwinState:
    robot_id: str
    robot_name: str
    firmware_version: str = "2.8.1"
    nil_runtime_version: str = "1.4.3"
    current_payload_kg: float = 2.5
    center_of_mass: Tuple[float, float, float] = (0.12, 0.04, 0.35)
    joint_positions: List[float] = field(default_factory=lambda: [0.0, -0.4, 0.8, -0.4, 0.0, 0.0])
    joint_velocities: List[float] = field(default_factory=lambda: [0.0] * 6)
    joint_temperatures: List[float] = field(default_factory=lambda: [38.5, 42.1, 40.0, 36.2, 35.0, 34.8])
    active_controller_profile: str = "precision_assembly_v3"
    operating_hours: float = 1420.5
    last_sync_timestamp: float = field(default_factory=time.time)


class DigitalTwin:
    """Enterprise Digital Twin linking Physical Fleet, Simulation, and AI Engine."""

    def __init__(self, robot_id: str = "ROBOT-001", name: str = "Universal 6DOF Cell Arm") -> None:
        self.robot_id = robot_id
        self.state = DigitalTwinState(robot_id=robot_id, robot_name=name)
        self.motor_profiles: Dict[str, MotorCharacteristics] = {
            f"joint_{i+1}": MotorCharacteristics() for i in range(6)
        }
        self.sensor_configs: Dict[str, SensorConfig] = {
            "wrist_camera": SensorConfig(sensor_id="cam_01", sensor_type="camera", sampling_rate_hz=30.0),
            "base_imu": SensorConfig(sensor_id="imu_01", sensor_type="imu", sampling_rate_hz=200.0),
            "ft_sensor": SensorConfig(sensor_id="ft_01", sensor_type="ft", sampling_rate_hz=500.0),
        }
        self.safety = SafetyEnvelope()
        self.telemetry_history: List[Dict[str, Any]] = []

    def sync_from_physical(self, telemetry: Dict[str, Any]) -> None:
        """Ingest live physical robot telemetry into Digital Twin."""
        if "positions" in telemetry:
            self.state.joint_positions = telemetry["positions"]
        if "velocities" in telemetry:
            self.state.joint_velocities = telemetry["velocities"]
        if "temperatures" in telemetry:
            self.state.joint_temperatures = telemetry["temperatures"]
        if "payload_kg" in telemetry:
            self.state.current_payload_kg = telemetry["payload_kg"]

        self.state.last_sync_timestamp = time.time()
        self.telemetry_history.append({
            "timestamp": self.state.last_sync_timestamp,
            "positions": self.state.joint_positions,
            "temperatures": self.state.joint_temperatures,
            "payload": self.state.current_payload_kg,
        })
        if len(self.telemetry_history) > 1000:
            self.telemetry_history.pop(0)

    def compare_with_simulation(self, sim_state: Dict[str, Any]) -> Dict[str, Any]:
        """Compute reality gap and parameter drift between physical twin and simulation."""
        sim_pos = sim_state.get("positions", [0.0] * len(self.state.joint_positions))
        errors = [
            abs(phys - sim)
            for phys, sim in zip(self.state.joint_positions, sim_pos)
        ]
        avg_tracking_error = sum(errors) / max(1, len(errors))
        return {
            "robot_id": self.robot_id,
            "avg_tracking_error_rad": avg_tracking_error,
            "joint_errors": errors,
            "reality_gap_pct": round(avg_tracking_error * 100.0, 3),
            "status": "nominal" if avg_tracking_error < 0.05 else "parameter_drift_detected",
        }

    def export_snapshot(self) -> Dict[str, Any]:
        return {
            "state": asdict(self.state),
            "safety": asdict(self.safety),
            "sensors": {k: asdict(v) for k, v in self.sensor_configs.items()},
            "motors": {k: asdict(v) for k, v in self.motor_profiles.items()},
            "telemetry_points": len(self.telemetry_history),
        }
