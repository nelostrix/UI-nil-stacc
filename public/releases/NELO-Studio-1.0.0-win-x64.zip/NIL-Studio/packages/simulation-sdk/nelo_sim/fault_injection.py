"""NIL Enterprise Fault Injection Suite for Robotics Reliability."""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class FaultConfig:
    sensor_dropout_rate: float = 0.0      # 0.0 to 1.0 probability
    encoder_drift_std: float = 0.0        # radians std dev
    actuator_delay_ms: float = 0.0        # milliseconds
    network_latency_ms: float = 0.0       # milliseconds
    packet_loss_rate: float = 0.0         # 0.0 to 1.0 probability
    motor_saturation_pct: float = 100.0   # 10% to 100% torque clamp
    camera_occlusion: bool = False        # Blackout / frozen frame
    mechanical_binding_friction: float = 0.0 # additional friction Nm


class FaultInjector:
    """Injects real-world physical and electronic faults into simulation & validation."""

    def __init__(self, config: Optional[FaultConfig] = None) -> None:
        self.config = config or FaultConfig()
        self.injected_events: List[Dict[str, Any]] = []

    def set_faults(self, **kwargs: Any) -> None:
        for k, v in kwargs.items():
            if hasattr(self.config, k):
                setattr(self.config, k, v)

    def apply_sensor_dropout(self, sensor_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if self.config.sensor_dropout_rate > 0.0 and random.random() < self.config.sensor_dropout_rate:
            self.injected_events.append({"type": "sensor_dropout", "timestamp": time.time()})
            return None
        return sensor_data

    def apply_encoder_drift(self, positions: List[float]) -> List[float]:
        if self.config.encoder_drift_std > 0.0:
            return [
                p + random.gauss(0.0, self.config.encoder_drift_std)
                for p in positions
            ]
        return positions

    def apply_actuator_torques(self, torques: List[float]) -> List[float]:
        scale = max(0.1, min(1.0, self.config.motor_saturation_pct / 100.0))
        return [
            t * scale - (self.config.mechanical_binding_friction if t > 0 else -self.config.mechanical_binding_friction)
            for t in torques
        ]

    def get_summary(self) -> Dict[str, Any]:
        return {
            "active_faults": {
                "sensor_dropout": self.config.sensor_dropout_rate > 0,
                "encoder_drift": self.config.encoder_drift_std > 0,
                "actuator_delay": self.config.actuator_delay_ms > 0,
                "network_latency": self.config.network_latency_ms > 0,
                "packet_loss": self.config.packet_loss_rate > 0,
                "motor_saturation": self.config.motor_saturation_pct < 100.0,
                "camera_occluded": self.config.camera_occlusion,
            },
            "events_recorded": len(self.injected_events),
        }
