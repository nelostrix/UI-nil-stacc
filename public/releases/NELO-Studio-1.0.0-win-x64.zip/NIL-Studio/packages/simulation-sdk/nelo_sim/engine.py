"""NIL Multi-Physics Simulation Engine (powered by STACC and MuJoCo)."""

from __future__ import annotations

import math
import time
from typing import Any, Dict, List, Optional

try:
    import stacc
    from stacc.sim import SimulationEngine as StaccSimulationEngine, SimulationConfig as StaccSimConfig
    HAS_STACC_SIM = True
except ImportError:
    HAS_STACC_SIM = False

from nelo_sim.fault_injection import FaultConfig, FaultInjector


class SimulationEngine:
    """Rigid body physics and digital twin simulator powered by STACC MuJoCo."""

    def __init__(self, dt: float = 0.002, gravity: float = -9.81, physics_backend: str = "mujoco") -> None:
        self.dt = dt
        self.gravity = gravity
        self.sim_time: float = 0.0
        self.step_count: int = 0
        self.positions: List[float] = [0.0, -0.3, 0.6, -0.3, 0.0, 0.0]
        self.velocities: List[float] = [0.0] * 6
        self.torques: List[float] = [0.0] * 6
        self.fault_injector = FaultInjector()
        self.collision_detected: bool = False
        self.tracked_metrics: List[Dict[str, Any]] = []

        self.stacc_engine: Optional[Any] = None
        if HAS_STACC_SIM:
            try:
                cfg = StaccSimConfig(timestep=self.dt, gravity=[0.0, 0.0, self.gravity], physics_engine=physics_backend)
                self.stacc_engine = StaccSimulationEngine(config=cfg)
            except Exception:
                self.stacc_engine = None

    def set_target_positions(self, target_positions: List[float]) -> None:
        # PD-based internal actuator model with realistic motor saturation
        kp, kd = 120.0, 15.0
        raw_torques = []
        for i in range(min(len(self.positions), len(target_positions))):
            pos_err = target_positions[i] - self.positions[i]
            vel_err = 0.0 - self.velocities[i]
            tau = max(-50.0, min(50.0, kp * pos_err + kd * vel_err))
            raw_torques.append(tau)

        # Apply fault injection to actuators
        self.torques = self.fault_injector.apply_actuator_torques(raw_torques)

    def step(self) -> Dict[str, Any]:
        """Execute one integration step."""
        if self.stacc_engine is not None and hasattr(self.stacc_engine, "step"):
            try:
                self.stacc_engine.step()
            except Exception:
                pass

        # Dynamics integration
        dof = len(self.positions)
        for i in range(dof):
            inertia = 0.08  # kg*m^2
            acc = self.torques[i] / inertia if i < len(self.torques) else 0.0
            self.velocities[i] += acc * self.dt
            self.positions[i] += self.velocities[i] * self.dt

        self.sim_time += self.dt
        self.step_count += 1

        # Apply encoder drift if active
        measured_positions = self.fault_injector.apply_encoder_drift(self.positions)

        state = {
            "time": round(self.sim_time, 4),
            "step": self.step_count,
            "backend": "STACC MuJoCo" if HAS_STACC_SIM else "NIL Physics",
            "positions": [round(p, 4) for p in measured_positions],
            "velocities": [round(v, 4) for v in self.velocities],
            "torques": [round(t, 2) for t in self.torques],
            "collisions": 1 if self.collision_detected else 0,
        }
        self.tracked_metrics.append(state)
        if len(self.tracked_metrics) > 500:
            self.tracked_metrics.pop(0)

        return state

    def run_trajectory(self, trajectory_points: List[List[float]], hold_steps: int = 10) -> Dict[str, Any]:
        """Run multi-waypoint trajectory rollout."""
        for target in trajectory_points:
            self.set_target_positions(target)
            for _ in range(hold_steps):
                self.step()

        return {
            "duration_s": round(self.sim_time, 3),
            "steps": self.step_count,
            "final_positions": self.positions,
            "max_torque": max(abs(t) for t in self.torques) if self.torques else 0.0,
            "collision_free": not self.collision_detected,
        }
