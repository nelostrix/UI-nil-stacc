"""NIL AI Persistent User Knowledge & Adaptive Learning Memory Engine."""

from __future__ import annotations

import json
import os
import re
import time
import uuid
from typing import Any, Dict, List, Optional


class UserMemoryStore:
    """
    Manages persistent personalization, user preferences, hardware configurations,
    custom directives, and autonomous knowledge extraction for NIL AI Copilot.
    """

    def __init__(self, storage_path: Optional[str] = None) -> None:
        if storage_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            self.storage_path = os.path.join(base_dir, "agent_store", "user_memory.json")
        else:
            self.storage_path = storage_path

        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        self._data: Dict[str, Any] = self._load()

    def _load(self) -> Dict[str, Any]:
        default_data = {
            "version": "1.2.0",
            "user_profile": {
                "name": "Robotics Engineer",
                "role": "Robotics & Controls Engineer",
                "preferred_languages": ["Python", "C++", "Rust"],
                "preferred_frameworks": ["STACC", "MuJoCo", "PyTorch", "ROS2"],
                "hardware_context": "6-DOF Manipulator on STACC 1000Hz HAL"
            },
            "custom_instructions": (
                "You are an expert robotics AI pair programmer. Always write clean, production-grade, "
                "mathematically sound robotics code. Prefer modular architectures, type hints, and real kinematics/dynamics equations."
            ),
            "memory_enabled": True,
            "memories": [
                {
                    "id": "mem_default_1",
                    "category": "hardware",
                    "content": "Workcell uses a 6-DOF robotic manipulator operating on STACC 1000Hz in-device shared memory HAL.",
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "source": "initial_setup"
                },
                {
                    "id": "mem_default_2",
                    "category": "preferences",
                    "content": "Prefers standard markdown code blocks with explicit language specifiers (python, cpp, json, rir).",
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "source": "initial_setup"
                },
                {
                    "id": "mem_default_3",
                    "category": "project",
                    "content": "Developing autonomous pick-and-place, trajectory optimization, and impedance control for warehouse manipulation.",
                    "created_at": time.time(),
                    "updated_at": time.time(),
                    "source": "initial_setup"
                }
            ]
        }

        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if isinstance(loaded, dict) and "memories" in loaded:
                        return loaded
            except Exception:
                pass

        self._save(default_data)
        return default_data

    def _save(self, data: Optional[Dict[str, Any]] = None) -> None:
        if data is None:
            data = self._data
        try:
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"[UserMemoryStore] Error saving user memory: {e}")

    def get_all(self) -> Dict[str, Any]:
        """Return the entire memory payload."""
        return self._data

    def get_memories(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return list of memories, optionally filtered by category."""
        memories = self._data.get("memories", [])
        if category:
            return [m for m in memories if m.get("category") == category]
        return memories

    def add_memory(self, content: str, category: str = "learned_facts", source: str = "user_explicit") -> Dict[str, Any]:
        """Add a new memory item."""
        content = content.strip()
        if not content:
            return {}

        # Avoid exact duplicates
        for m in self._data.get("memories", []):
            if m.get("content", "").lower() == content.lower():
                m["updated_at"] = time.time()
                self._save()
                return m

        mem_id = f"mem_{uuid.uuid4().hex[:8]}"
        now = time.time()
        new_item = {
            "id": mem_id,
            "category": category,
            "content": content,
            "created_at": now,
            "updated_at": now,
            "source": source
        }
        self._data.setdefault("memories", []).append(new_item)
        self._save()
        return new_item

    def update_memory(self, memory_id: str, content: str, category: Optional[str] = None) -> bool:
        """Update an existing memory item."""
        for m in self._data.get("memories", []):
            if m.get("id") == memory_id:
                m["content"] = content.strip()
                if category:
                    m["category"] = category
                m["updated_at"] = time.time()
                self._save()
                return True
        return False

    def delete_memory(self, memory_id: str) -> bool:
        """Delete a memory item by ID."""
        initial_len = len(self._data.get("memories", []))
        self._data["memories"] = [m for m in self._data.get("memories", []) if m.get("id") != memory_id]
        if len(self._data["memories"]) != initial_len:
            self._save()
            return True
        return False

    def clear_all(self) -> None:
        """Clear all memories except user profile."""
        self._data["memories"] = []
        self._save()

    def update_profile(self, profile: Dict[str, Any]) -> None:
        """Update user profile information."""
        self._data["user_profile"] = {**self._data.get("user_profile", {}), **profile}
        self._save()

    def update_instructions(self, custom_instructions: str) -> None:
        """Update user's global custom instructions."""
        self._data["custom_instructions"] = custom_instructions.strip()
        self._save()

    def set_memory_enabled(self, enabled: bool) -> None:
        """Toggle memory system on or off."""
        self._data["memory_enabled"] = bool(enabled)
        self._save()

    def extract_and_learn(self, user_message: str, assistant_response: str) -> List[Dict[str, Any]]:
        """
        Analyze conversation turn and autonomously extract facts, preferences,
        hardware details, or project instructions (similar to ChatGPT / Claude memory).
        """
        if not self._data.get("memory_enabled", True):
            return []

        extracted: List[Dict[str, Any]] = []
        msg_clean = user_message.strip()

        # Patterns indicating user facts or preferences
        fact_patterns = [
            (r"(?:i am|i'm|my name is)\s+([A-Za-z0-9_\-\s]{2,40})", "profile", "User identity: {}"),
            (r"(?:i am building|i'm building|we are building|i am working on|i'm working on)\s+([^\.\n]+)", "project", "Working on: {}"),
            (r"(?:i prefer|i like|always use|always write|prefer using)\s+([^\.\n]+)", "preferences", "User preference: {}"),
            (r"(?:my robot is|we use robot|the robot has|our robot has)\s+([^\.\n]+)", "hardware", "Hardware details: {}"),
            (r"(?:my hardware is|our hardware is|using board|using actuator)\s+([^\.\n]+)", "hardware", "Hardware: {}"),
            (r"(?:remember that|note that|keep in mind that)\s+([^\.\n]+)", "directives", "Directive: {}"),
            (r"(?:my payload is|payload is|target mass is)\s+([0-9\.]+\s*(?:kg|grams|g|lbs))", "hardware", "Robot payload: {}"),
            (r"(?:operating frequency is|hal frequency is|bus frequency is)\s+([0-9\.]+\s*(?:hz|khz))", "hardware", "HAL bus frequency: {}"),
        ]

        for pattern, cat, tmpl in fact_patterns:
            matches = re.finditer(pattern, msg_clean, re.IGNORECASE)
            for match in matches:
                val = match.group(1).strip()
                if len(val) > 2 and len(val) < 150:
                    fact_str = tmpl.format(val)
                    item = self.add_memory(fact_str, category=cat, source="auto_extracted")
                    if item:
                        extracted.append(item)

        return extracted

    def format_memory_for_system_prompt(self) -> str:
        """
        Format all active memories into a compact markdown context block for LLM prompts.
        """
        if not self._data.get("memory_enabled", True):
            return ""

        lines = ["# User Knowledge & Learned Memory (Personalization):"]
        
        custom_inst = self._data.get("custom_instructions", "").strip()
        if custom_inst:
            lines.append(f"## Custom User Directives:\n{custom_inst}")

        profile = self._data.get("user_profile", {})
        if profile:
            profile_parts = []
            if profile.get("role"):
                profile_parts.append(f"Role: {profile['role']}")
            if profile.get("preferred_languages"):
                profile_parts.append(f"Languages: {', '.join(profile['preferred_languages'])}")
            if profile.get("preferred_frameworks"):
                profile_parts.append(f"Frameworks: {', '.join(profile['preferred_frameworks'])}")
            if profile.get("hardware_context"):
                profile_parts.append(f"Hardware: {profile['hardware_context']}")
            if profile_parts:
                lines.append(f"## Profile: {'; '.join(profile_parts)}")

        memories = self._data.get("memories", [])
        if memories:
            lines.append("## Learned Facts & Context:")
            for m in memories[-15:]:  # Include up to 15 most recent relevant memories
                content = m.get("content", "").strip()
                if content:
                    lines.append(f"• [{m.get('category', 'fact').upper()}] {content}")

        return "\n".join(lines)
