"""NIL Universal AI Model Router & Live Discovery Engine.
Dynamically fetches live model catalogs across OpenAI, Anthropic, Gemini, DeepSeek,
Groq, OpenRouter, Ollama, and Custom endpoints, with intelligent capability routing.
"""

from __future__ import annotations

import json
import logging
import re
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("nil.ai.router")


class ModelRouter:
    """
    Dynamic live model discovery, validation, and capability routing engine.
    """

    # Non-conversational model patterns to filter out from OpenAI / providers
    EXCLUDED_PATTERNS = [
        "embedding", "embed", "tts", "whisper", "dall-e", "davinci", "babbage",
        "curie", "ada", "moderation", "similarity", "edit", "insert", "search",
        "code-search", "audio", "canary", "realtime-preview"
    ]

    # Curated Flagships for instant preview when offline or key not yet entered
    CURATED_FLAGSHIPS = {
        "openai": [
            {"id": "gpt-4o", "name": "GPT-4o (Omni Flagship)", "context": "128k", "capabilities": ["vision", "tools", "fast"], "category": "flagship"},
            {"id": "gpt-4o-mini", "name": "GPT-4o Mini (Affordable Fast)", "context": "128k", "capabilities": ["vision", "tools", "speed"], "category": "lightweight"},
            {"id": "o1", "name": "o1 (Deep Reasoning Flagship)", "context": "200k", "capabilities": ["reasoning", "math", "code"], "category": "reasoning"},
            {"id": "o3-mini", "name": "o3-mini (High-Speed STEM Reasoning)", "context": "200k", "capabilities": ["reasoning", "coding", "fast"], "category": "reasoning"},
            {"id": "gpt-4.5-preview", "name": "GPT-4.5 Preview (Largest Knowledge Base)", "context": "128k", "capabilities": ["deep-knowledge", "creative"], "category": "flagship"},
            {"id": "chatgpt-4o-latest", "name": "ChatGPT-4o Latest Dynamic", "context": "128k", "capabilities": ["general", "tools"], "category": "flagship"},
            {"id": "gpt-4-turbo", "name": "GPT-4 Turbo (128k)", "context": "128k", "capabilities": ["vision", "tools"], "category": "legacy"}
        ],
        "anthropic": [
            {"id": "claude-3-7-sonnet-20250219", "name": "Claude 3.7 Sonnet (Hybrid Reasoning & Coding)", "context": "200k", "capabilities": ["thinking", "coding", "vision"], "category": "flagship"},
            {"id": "claude-3-5-sonnet-20241022", "name": "Claude 3.5 Sonnet v2 (Industry Coding Standard)", "context": "200k", "capabilities": ["coding", "vision", "tools"], "category": "flagship"},
            {"id": "claude-3-5-haiku-20241022", "name": "Claude 3.5 Haiku (Ultra-Fast Response)", "context": "200k", "capabilities": ["speed", "tools"], "category": "lightweight"},
            {"id": "claude-3-opus-20240229", "name": "Claude 3 Opus (Complex Analysis)", "context": "200k", "capabilities": ["deep-analysis", "writing"], "category": "flagship"}
        ],
        "gemini": [
            {"id": "gemini-2.0-flash", "name": "Gemini 2.0 Flash (Next-Gen Multimodal)", "context": "1M", "capabilities": ["multimodal", "speed", "tools"], "category": "flagship"},
            {"id": "gemini-2.0-flash-lite", "name": "Gemini 2.0 Flash-Lite (Cost Efficiency)", "context": "1M", "capabilities": ["speed", "efficiency"], "category": "lightweight"},
            {"id": "gemini-2.0-pro-exp-02-05", "name": "Gemini 2.0 Pro Experimental (Complex Reasoning)", "context": "2M", "capabilities": ["reasoning", "coding", "2m-context"], "category": "reasoning"},
            {"id": "gemini-1.5-pro", "name": "Gemini 1.5 Pro (Long-Context Video & Code)", "context": "2M", "capabilities": ["2m-context", "multimodal"], "category": "flagship"},
            {"id": "gemini-1.5-flash", "name": "Gemini 1.5 Flash (High Throughput)", "context": "1M", "capabilities": ["speed", "audio"], "category": "lightweight"}
        ],
        "deepseek": [
            {"id": "deepseek-chat", "name": "DeepSeek-V3 (671B MoE Chat)", "context": "64k", "capabilities": ["coding", "architecture", "fast"], "category": "flagship"},
            {"id": "deepseek-reasoner", "name": "DeepSeek-R1 (Pure Reinforcement Reasoning)", "context": "64k", "capabilities": ["deep-thinking", "math", "logic"], "category": "reasoning"}
        ],
        "groq": [
            {"id": "llama-3.3-70b-versatile", "name": "Llama 3.3 70B Versatile (~350 tok/s)", "context": "128k", "capabilities": ["ultra-fast", "coding", "tools"], "category": "flagship"},
            {"id": "deepseek-r1-distill-llama-70b", "name": "DeepSeek-R1 Distill Llama 70B", "context": "128k", "capabilities": ["reasoning", "fast"], "category": "reasoning"},
            {"id": "llama-3.1-8b-instant", "name": "Llama 3.1 8B Instant (~800 tok/s)", "context": "128k", "capabilities": ["instant", "tools"], "category": "lightweight"},
            {"id": "mixtral-8x7b-32768", "name": "Mixtral 8x7B (MoE Architecture)", "context": "32k", "capabilities": ["moe", "fast"], "category": "legacy"}
        ],
        "openrouter": [
            {"id": "anthropic/claude-3.7-sonnet", "name": "Claude 3.7 Sonnet (via OpenRouter)", "context": "200k", "capabilities": ["hybrid-reasoning", "coding"], "category": "flagship"},
            {"id": "openai/gpt-4o", "name": "GPT-4o (via OpenRouter)", "context": "128k", "capabilities": ["vision", "tools"], "category": "flagship"},
            {"id": "deepseek/deepseek-r1", "name": "DeepSeek R1 (via OpenRouter)", "context": "64k", "capabilities": ["reasoning", "open-weights"], "category": "reasoning"},
            {"id": "meta-llama/llama-3.3-70b-instruct", "name": "Llama 3.3 70B Instruct", "context": "128k", "capabilities": ["fast", "open-source"], "category": "flagship"},
            {"id": "qwen/qwen-2.5-coder-32b-instruct", "name": "Qwen 2.5 Coder 32B Instruct", "context": "128k", "capabilities": ["coding-expert", "low-cost"], "category": "coding"},
            {"id": "google/gemini-2.0-flash-001", "name": "Gemini 2.0 Flash (via OpenRouter)", "context": "1M", "capabilities": ["multimodal", "fast"], "category": "lightweight"}
        ]
    }

    def fetch_live_models(
        self,
        provider: str = "custom",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Query provider's live endpoint directly to fetch the actual active model list.
        Falls back to curated active catalog if no API key or if offline.
        """
        provider_clean = (provider or "custom").lower()
        live_models: List[Dict[str, Any]] = []

        # 1. LOCAL OLLAMA
        if provider_clean == "local":
            endpoint = (base_url.rstrip("/") if base_url else "http://127.0.0.1:11434") + "/api/tags"
            try:
                req = urllib.request.Request(endpoint, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req, timeout=3) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    for m in data.get("models", []):
                        m_id = m.get("name", "")
                        size_gb = round(m.get("size", 0) / (1024**3), 2)
                        family = m.get("details", {}).get("family", "local")
                        quant = m.get("details", {}).get("quantization_level", "Q4_K_M")
                        live_models.append({
                            "id": m_id,
                            "name": f"{m_id} ({size_gb} GB • {quant})",
                            "context": "32k-128k",
                            "capabilities": ["in-device", "private", family],
                            "category": "local_installed",
                            "size_gb": size_gb,
                            "quantization": quant
                        })
            except Exception:
                pass

            if not live_models:
                live_models = [
                    {"id": "llama3.2:latest", "name": "Llama 3.2 3B (Edge Compact)", "context": "128k", "capabilities": ["in-device", "fast"], "category": "local"},
                    {"id": "mistral:latest", "name": "Mistral 7B (Instruct)", "context": "32k", "capabilities": ["in-device", "general"], "category": "local"},
                    {"id": "codellama:latest", "name": "CodeLlama 7B (Python / C++)", "context": "16k", "capabilities": ["in-device", "coding"], "category": "local"},
                    {"id": "qwen2.5-coder:7b", "name": "Qwen 2.5 Coder 7B", "context": "32k", "capabilities": ["in-device", "coding"], "category": "local"}
                ]

        # 2. OPENAI LIVE API
        elif provider_clean == "openai":
            if api_key:
                try:
                    req = urllib.request.Request(
                        "https://api.openai.com/v1/models",
                        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        for item in data.get("data", []):
                            m_id = item.get("id", "")
                            # Filter out non-chat models
                            if any(p in m_id.lower() for p in self.EXCLUDED_PATTERNS):
                                continue
                            caps = ["chat", "api"]
                            cat = "standard"
                            ctx = "128k"
                            if "o1" in m_id or "o3" in m_id:
                                caps = ["reasoning", "math", "code"]
                                cat = "reasoning"
                                ctx = "200k"
                            elif "gpt-4o" in m_id:
                                caps = ["vision", "tools", "fast"]
                                cat = "flagship"
                            elif "gpt-4.5" in m_id:
                                caps = ["deep-knowledge", "creative"]
                                cat = "flagship"

                            live_models.append({
                                "id": m_id,
                                "name": m_id,
                                "context": ctx,
                                "capabilities": caps,
                                "category": cat,
                                "created": item.get("created")
                            })
                except Exception as e:
                    logger.debug("Live OpenAI models query failed: %s", e)

            # Fallback/merge with curated flagships if live query was empty or offline
            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("openai", []))

        # 3. ANTHROPIC CLAUDE
        elif provider_clean == "anthropic":
            # Anthropic models list
            if api_key:
                try:
                    req = urllib.request.Request(
                        "https://api.anthropic.com/v1/models",
                        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        for item in data.get("data", []):
                            m_id = item.get("id", "")
                            live_models.append({
                                "id": m_id,
                                "name": item.get("display_name") or m_id,
                                "context": "200k",
                                "capabilities": ["vision", "coding", "tools"],
                                "category": "flagship"
                            })
                except Exception:
                    pass

            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("anthropic", []))

        # 4. GOOGLE GEMINI LIVE API
        elif provider_clean == "gemini":
            if api_key:
                try:
                    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
                    req = urllib.request.Request(url, headers={"Content-Type": "application/json"})
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        for m in data.get("models", []):
                            methods = m.get("supportedGenerationMethods", [])
                            if "generateContent" not in methods:
                                continue
                            raw_name = m.get("name", "")
                            # strip "models/" prefix
                            clean_id = raw_name.replace("models/", "")
                            display_name = m.get("displayName") or clean_id
                            input_token_limit = m.get("inputTokenLimit", 1048576)
                            ctx_str = f"{int(input_token_limit / 1000)}k" if input_token_limit < 1000000 else f"{int(input_token_limit / 1000000)}M"

                            caps = ["multimodal", "generateContent"]
                            if "flash" in clean_id: caps.append("speed")
                            if "pro" in clean_id: caps.append("reasoning")

                            live_models.append({
                                "id": clean_id,
                                "name": f"{display_name} ({ctx_str})",
                                "context": ctx_str,
                                "capabilities": caps,
                                "category": "gemini_live"
                            })
                except Exception as e:
                    logger.debug("Gemini live models query failed: %s", e)

            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("gemini", []))

        # 5. DEEPSEEK LIVE API
        elif provider_clean == "deepseek":
            if api_key:
                try:
                    req = urllib.request.Request(
                        "https://api.deepseek.com/models",
                        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        for item in data.get("data", []):
                            m_id = item.get("id", "")
                            live_models.append({
                                "id": m_id,
                                "name": m_id,
                                "context": "64k",
                                "capabilities": ["coding", "reasoning" if "reasoner" in m_id else "chat"],
                                "category": "deepseek_live"
                            })
                except Exception:
                    pass

            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("deepseek", []))

        # 6. GROQ LIVE API
        elif provider_clean == "groq":
            if api_key:
                try:
                    req = urllib.request.Request(
                        "https://api.groq.com/openai/v1/models",
                        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        data = json.loads(resp.read().decode("utf-8"))
                        for item in data.get("data", []):
                            m_id = item.get("id", "")
                            if any(p in m_id.lower() for p in ["whisper", "embedding"]):
                                continue
                            ctx_len = item.get("context_window", 131072)
                            ctx_str = f"{int(ctx_len/1000)}k"
                            live_models.append({
                                "id": m_id,
                                "name": f"{m_id} ({ctx_str})",
                                "context": ctx_str,
                                "capabilities": ["ultra-fast", "lpux"],
                                "category": "groq_live"
                            })
                except Exception:
                    pass

            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("groq", []))

        # 7. OPENROUTER LIVE API (250+ LIVE MODELS)
        elif provider_clean == "openrouter":
            try:
                headers = {"Content-Type": "application/json"}
                if api_key:
                    headers["Authorization"] = f"Bearer {api_key}"
                req = urllib.request.Request("https://openrouter.ai/api/v1/models", headers=headers)
                with urllib.request.urlopen(req, timeout=6) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    items = data.get("data", [])
                    for item in items[:40]:  # Top 40 models
                        m_id = item.get("id", "")
                        name = item.get("name", m_id)
                        ctx_len = item.get("context_length", 128000)
                        ctx_str = f"{int(ctx_len/1000)}k" if ctx_len < 1000000 else f"{int(ctx_len/1000000)}M"
                        pricing = item.get("pricing", {})
                        prompt_price = float(pricing.get("prompt", "0") or 0) * 1000000
                        price_str = f"${prompt_price:.2f}/M" if prompt_price > 0 else "Free"

                        live_models.append({
                            "id": m_id,
                            "name": f"{name} ({ctx_str} • {price_str})",
                            "context": ctx_str,
                            "capabilities": ["openrouter", ctx_str, price_str],
                            "category": "openrouter_live"
                        })
            except Exception as e:
                logger.debug("OpenRouter live catalog query failed: %s", e)

            if not live_models:
                live_models = list(self.CURATED_FLAGSHIPS.get("openrouter", []))

        # 8. CUSTOM / SELF-HOSTED (LM STUDIO / vLLM / LocalAI)
        else:
            endpoint = (base_url.rstrip("/") if base_url else "http://127.0.0.1:11434/v1") + "/models"
            headers = {"Content-Type": "application/json"}
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"

            try:
                req = urllib.request.Request(endpoint, headers=headers)
                with urllib.request.urlopen(req, timeout=4) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    items = data.get("data", []) or data.get("models", [])
                    for item in items:
                        m_id = item.get("id") or item.get("name")
                        if m_id and not any(p in m_id.lower() for p in self.EXCLUDED_PATTERNS):
                            live_models.append({
                                "id": m_id,
                                "name": m_id,
                                "context": "custom",
                                "capabilities": ["custom-endpoint"],
                                "category": "custom_live"
                            })
            except Exception:
                pass

            if not live_models:
                live_models = [
                    {"id": "qwen2.5-coder:32b", "name": "Qwen 2.5 Coder 32B", "context": "128k", "capabilities": ["coding"], "category": "custom"},
                    {"id": "deepseek-r1:latest", "name": "DeepSeek R1 (GGUF / vLLM)", "context": "64k", "capabilities": ["reasoning"], "category": "custom"},
                    {"id": "meta-llama/Llama-3.3-70B-Instruct", "name": "Llama 3.3 70B Instruct", "context": "128k", "capabilities": ["open-source"], "category": "custom"}
                ]

        # Sort with reasoning and flagships first
        def sort_key(m: Dict[str, Any]) -> int:
            cat = m.get("category", "")
            if "flagship" in cat: return 0
            if "reasoning" in cat: return 1
            if "live" in cat: return 2
            return 3

        live_models.sort(key=sort_key)

        return {
            "status": "success",
            "provider": provider_clean,
            "models": live_models,
            "count": len(live_models),
            "is_live_queried": bool(api_key or provider_clean in ["local", "openrouter"])
        }

    def format_request_for_model(
        self,
        provider: str,
        model: str,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048
    ) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """
        Validate and format the request payload specifically tailored to the target model
        (handling OpenAI o1/o3 parameter requirements, Claude system prompt formats, etc.).
        """
        provider_clean = (provider or "local").lower()
        model_clean = (model or "").strip()

        # Handle OpenAI o1/o3 reasoning model rules
        is_openai_reasoning = provider_clean == "openai" and any(r in model_clean.lower() for r in ["o1", "o3"])

        payload: Dict[str, Any] = {
            "model": model_clean,
            "messages": messages
        }

        if is_openai_reasoning:
            # OpenAI o1/o3 do not accept temperature and require max_completion_tokens
            payload["max_completion_tokens"] = max_tokens
            # Convert system messages to developer role if needed
            converted_msgs = []
            for m in messages:
                if m.get("role") == "system":
                    converted_msgs.append({"role": "developer", "content": m.get("content", "")})
                else:
                    converted_msgs.append(m)
            payload["messages"] = converted_msgs
        else:
            payload["temperature"] = temperature
            payload["max_tokens"] = max_tokens

        headers: Dict[str, str] = {"Content-Type": "application/json"}
        return payload, headers
