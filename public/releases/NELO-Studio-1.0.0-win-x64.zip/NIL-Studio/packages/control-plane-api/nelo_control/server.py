"""NIL Enterprise Control Plane API Server."""

from __future__ import annotations

import json
import time
import os
from dataclasses import asdict, dataclass, field
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, parse_qs

from nelo_fleet.manager import FleetManager
from nelo_twin.twin import DigitalTwin
from nelo_ci.runner import RoboticsCIRunner
from nelo_ai.orchestrator import AIEngineeringOrchestrator
from nelo_compute.model_registry import ModelRegistry
from nelo_compute.runtime import InDeviceInferenceRuntime
from nelo_license import LicenseManager, LicenseTier


class ControlPlaneState:
    """In-memory enterprise control plane datastore."""

    def __init__(self) -> None:
        self.orgs = [{"id": "org_01", "name": "DeepRobotics Labs", "plan": "Enterprise"}]
        self.teams = [{"id": "team_alpha", "name": "Manipulation & Perception", "members": 12}]
        self.projects = [
            {"id": "proj_01", "name": "Autonomous Palletizer v2", "robot_type": "6DOF Arm", "status": "active"},
            {"id": "proj_02", "name": "Warehouse AMR Fleet", "robot_type": "Differential AMR", "status": "active"},
        ]
        self.fleet_mgr = FleetManager()
        self.digital_twins = {"DT-001": DigitalTwin("ROBOT-001")}
        self.ci_runner = RoboticsCIRunner()
        self.ai_orchestrator = AIEngineeringOrchestrator()
        self.model_registry = ModelRegistry()
        self.compute_runtime = InDeviceInferenceRuntime()
        self.license_mgr = LicenseManager()
        self.audit_logs = [
            {"timestamp": "2026-08-28 18:30:12", "actor": "sarah.eng@deeprobotics.ai", "action": "DEPLOY_POLICY", "target": "ROBOT-002", "details": "Policy 'warehouse_pick_v14' deployed"},
            {"timestamp": "2026-08-28 18:45:00", "actor": "system.ci", "action": "RUN_VALIDATION", "target": "BUILD-1842", "details": "Continuous robotics validation passed"},
        ]
        self.secrets = {"CLOUDFLARE_API_KEY": "••••••••••••", "MUJOCO_LICENSE": "NIL-PRO-2026-ENT"}


class ControlPlaneHTTPHandler(BaseHTTPRequestHandler):
    """REST API Handler for Control Plane and Studio integration."""

    state = ControlPlaneState()

    def _send_json(self, data: Any, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode("utf-8"))

    def do_OPTIONS(self) -> None:
        self._send_json({"status": "ok"})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/status":
            self._send_json({"status": "ONLINE", "version": "1.0.0", "service": "NIL-Control-Plane"})
        elif path == "/api/compute/status":
            self._send_json(self.state.compute_runtime.get_status())
        elif path == "/api/compute/models":
            self._send_json(self.state.model_registry.list_catalog())
        elif path == "/api/fleet":
            self._send_json(self.state.fleet_mgr.list_robots())
        elif path == "/api/projects":
            self._send_json(self.state.projects)
        elif path == "/api/audit":
            self._send_json(self.state.audit_logs)
        elif path == "/api/twin":
            dt = self.state.digital_twins.get("DT-001")
            self._send_json(dt.export_snapshot() if dt else {})
        elif path == "/api/ci/latest":
            report = self.state.ci_runner.run_suite()
            self._send_json({
                "build_id": report.build_id,
                "commit_sha": report.commit_sha,
                "passed": report.passed,
                "total_tests": report.total_tests,
                "passed_count": report.passed_count,
                "failed_count": report.failed_count,
                "blocking_reasons": report.blocking_reasons,
                "results": [
                    {"name": r.name, "category": r.category, "passed": r.passed, "duration_ms": r.duration_ms, "message": r.message}
                    for r in report.test_results
                ],
            })
        elif path == "/api/license/status":
            self._send_json(self.state.license_mgr.get_status())
        elif path == "/api/license/fingerprint":
            self._send_json({
                "status": "success",
                "machine_fingerprint": self.state.license_mgr.get_machine_fingerprint()
            })
        elif path == "/" or path == "/index.html":
            desktop_index = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "apps", "desktop", "index.html")
            if os.path.exists(desktop_index):
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                with open(desktop_index, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self._send_json({"service": "NIL-Control-Plane", "status": "ONLINE", "studio": "http://localhost:3000"})
        elif path == "/bundle.js" or path == "/app.js":
            file_name = "app.js" if path == "/app.js" else "bundle.js"
            bundle_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "apps", "desktop", file_name)
            if os.path.exists(bundle_path):
                self.send_response(200)
                self.send_header("Content-Type", "text/javascript")
                self.end_headers()
                with open(bundle_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self._send_json({"error": f"{file_name} not found"}, status=404)
        else:
            self._send_json({"error": "Endpoint not found", "path": path, "studio": "http://localhost:3000"}, status=404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}

        if path == "/api/ai/prompt":
            prompt = body.get("prompt", "Analyze robot")
            res = self.state.ai_orchestrator.process_prompt(prompt, {})
            self._send_json(res)
        elif path == "/api/ai/chat":
            messages = body.get("messages", [])
            provider = body.get("provider", "local")
            model = body.get("model")
            api_key = body.get("api_key")
            base_url = body.get("base_url")
            temperature = float(body.get("temperature", 0.7))
            max_tokens = int(body.get("max_tokens", 2048))
            agent_role = body.get("agent_role", "lead")
            enable_web_search = bool(body.get("enable_web_search", False))
            res = self.state.ai_orchestrator.chat_completion(
                messages=messages,
                provider=provider,
                model=model,
                api_key=api_key,
                base_url=base_url,
                temperature=temperature,
                max_tokens=max_tokens,
                agent_role=agent_role,
                enable_web_search=enable_web_search
            )
            self._send_json(res)
        elif path == "/api/ai/models/discover":
            provider = body.get("provider", "custom")
            base_url = body.get("base_url")
            api_key = body.get("api_key")
            res = self.state.ai_orchestrator.discover_models(provider=provider, base_url=base_url, api_key=api_key)
            self._send_json(res)
        elif path == "/api/ai/search":
            query = body.get("query", "")
            max_results = int(body.get("max_results", 5))
            res = self.state.ai_orchestrator.web_search_engine.search(query=query, max_results=max_results)
            self._send_json({"status": "success", "data": res})
        elif path == "/api/ai/memory":
            action = body.get("action", "get")
            if action == "add":
                content = body.get("content", "")
                category = body.get("category", "learned_facts")
                item = self.state.ai_orchestrator.user_memory.add_memory(content=content, category=category)
                self._send_json({"status": "success", "item": item, "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "update":
                mem_id = body.get("id", "")
                content = body.get("content", "")
                category = body.get("category")
                ok = self.state.ai_orchestrator.user_memory.update_memory(memory_id=mem_id, content=content, category=category)
                self._send_json({"status": "success" if ok else "error", "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "delete":
                mem_id = body.get("id", "")
                ok = self.state.ai_orchestrator.user_memory.delete_memory(memory_id=mem_id)
                self._send_json({"status": "success" if ok else "error", "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "clear":
                self.state.ai_orchestrator.user_memory.clear_all()
                self._send_json({"status": "success", "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "update_profile":
                profile = body.get("profile", {})
                self.state.ai_orchestrator.user_memory.update_profile(profile)
                self._send_json({"status": "success", "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "update_instructions":
                instructions = body.get("instructions", "")
                self.state.ai_orchestrator.user_memory.update_instructions(instructions)
                self._send_json({"status": "success", "data": self.state.ai_orchestrator.user_memory.get_all()})
            elif action == "set_enabled":
                enabled = body.get("enabled", True)
                self.state.ai_orchestrator.user_memory.set_memory_enabled(enabled)
                self._send_json({"status": "success", "data": self.state.ai_orchestrator.user_memory.get_all()})
            else:
                self._send_json({"status": "success", "data": self.state.ai_orchestrator.user_memory.get_all()})
        elif path == "/api/compute/models/install":
            model_id = body.get("model_id", "")
            res = self.state.model_registry.install_model(model_id)
            self._send_json(res)
        elif path == "/api/compute/models/run":
            model_id = body.get("model_id", "")
            is_running = body.get("is_running", True)
            res = self.state.model_registry.set_running_model(model_id, is_running)
            self._send_json(res)
        elif path == "/api/fleet/deploy":
            robot_id = body.get("robot_id", "ROBOT-001")
            policy = body.get("policy", "default_policy")
            res = self.state.fleet_mgr.deploy_policy(robot_id, policy)
            self._send_json(res)
        elif path == "/api/fleet/rollback":
            robot_id = body.get("robot_id", "ROBOT-001")
            res = self.state.fleet_mgr.rollback(robot_id)
            self._send_json(res)
        elif path == "/api/license/activate":
            key = body.get("key") or body.get("license", "")
            res = self.state.license_mgr.activate_key_or_doc(key)
            self._send_json(res)
        elif path == "/api/license/deactivate":
            res = self.state.license_mgr.deactivate()
            self._send_json(res)
        elif path == "/api/license/generate":
            customer = body.get("customer_name", "Enterprise Client")
            org = body.get("organization", "NIL Robotics Partner")
            email = body.get("email", "client@nelostrix.com")
            tier_str = body.get("tier", "enterprise")
            expiry_days = int(body.get("expiry_days", 365))
            is_perp = bool(body.get("is_perpetual", False))
            machine_id = body.get("machine_id")
            tier = LicenseTier.ENTERPRISE
            if tier_str == "pro": tier = LicenseTier.PRO
            elif tier_str == "academic": tier = LicenseTier.ACADEMIC
            elif tier_str == "community": tier = LicenseTier.COMMUNITY
            res = self.state.license_mgr.generate_license(
                customer_name=customer,
                organization=org,
                email=email,
                tier=tier,
                expiry_days=expiry_days,
                is_perpetual=is_perp,
                machine_id=machine_id
            )
            self._send_json({"status": "success", "data": res})
        else:
            self._send_json({"error": "POST Endpoint not found"}, status=404)


def run_server(port: int = 8080) -> None:
    HTTPServer.allow_reuse_address = True
    server = None
    for p in range(port, port + 10):
        try:
            server = HTTPServer(("0.0.0.0", p), ControlPlaneHTTPHandler)
            port = p
            break
        except OSError:
            continue

    if server is None:
        print(f"[NIL Control Plane] Control plane already active on http://0.0.0.0:{port}")
        return

    print(f"[NIL Control Plane] Server listening on http://0.0.0.0:{port}")
    try:
        server.serve_forever()
    except Exception:
        pass


if __name__ == "__main__":
    run_server()
