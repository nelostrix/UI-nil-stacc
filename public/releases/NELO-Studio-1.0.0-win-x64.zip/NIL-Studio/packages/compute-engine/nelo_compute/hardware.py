"""In-Device Compute Hardware Profiler and Accelerator Detection."""

from __future__ import annotations

import os
import platform
import subprocess
import shutil
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ComputeDevice:
    device_id: str
    name: str
    device_type: str  # cuda_gpu, rocm_gpu, apple_metal, cpu_npu, jetson
    total_memory_gb: float
    free_memory_gb: float
    compute_units: int
    quantization_support: List[str] = field(default_factory=lambda: ["fp16", "int8", "int4", "q4_k_m"])
    is_active: bool = False


@dataclass
class HardwareProfile:
    os_name: str
    arch: str
    cpu_cores: int
    total_ram_gb: float
    free_ram_gb: float
    accelerator: str  # cuda, rocm, metal, cpu
    devices: List[ComputeDevice] = field(default_factory=list)
    optimal_quantization: str = "q4_k_m"
    max_model_param_b: float = 7.0  # Max parameters recommended for in-device compute


class InDeviceHardwareProfiler:
    """Detects available local accelerators, VRAM, and compute capabilities."""

    @staticmethod
    def get_system_ram() -> tuple[float, float, float]:
        total_ram = 7.0
        free_ram = 2.0
        used_ram = 5.0
        try:
            with open("/proc/meminfo", "r") as f:
                mem = {}
                for line in f:
                    parts = line.split(":")
                    if len(parts) == 2:
                        mem[parts[0].strip()] = int(parts[1].split()[0])
                total_ram = mem.get("MemTotal", 0) / (1024 * 1024)
                avail_ram = mem.get("MemAvailable", 0) / (1024 * 1024)
                used_ram = total_ram - avail_ram
                free_ram = avail_ram
        except Exception:
            pass
        return round(total_ram, 2), round(free_ram, 2), round(used_ram, 2)

    @classmethod
    def detect_hardware(cls) -> HardwareProfile:
        total_ram, free_ram, used_ram = cls.get_system_ram()
        cpu_cores = os.cpu_count() or 8
        devices: List[ComputeDevice] = []
        accelerator = "cpu"
        opt_quant = "q4_k_m"

        # Check NVIDIA CUDA
        if shutil.which("nvidia-smi"):
            try:
                out = subprocess.check_output(
                    ["nvidia-smi", "--query-gpu=name,memory.total,memory.free", "--format=csv,noheader,nounits"],
                    encoding="utf-8"
                ).strip()
                for i, line in enumerate(out.split("\n")):
                    if line.strip():
                        parts = [p.strip() for p in line.split(",")]
                        name = parts[0]
                        total_vram = float(parts[1]) / 1024.0
                        free_vram = float(parts[2]) / 1024.0
                        devices.append(ComputeDevice(
                            device_id=f"cuda:{i}",
                            name=name,
                            device_type="cuda_gpu",
                            total_memory_gb=round(total_vram, 1),
                            free_memory_gb=round(free_vram, 1),
                            compute_units=48,
                            is_active=(i == 0),
                        ))
                if devices:
                    accelerator = "cuda"
            except Exception:
                pass

        # Check AMD ROCm / Radeon GPU via lspci / sysfs
        if not devices:
            try:
                lspci_out = subprocess.check_output(["lspci"], text=True)
                for line in lspci_out.splitlines():
                    if "VGA" in line or "3D controller" in line or "Display controller" in line:
                        gpu_name = line.split(":")[-1].strip()
                        if "AMD" in gpu_name or "ATI" in gpu_name or "Radeon" in gpu_name:
                            accelerator = "amd_radeon"
                            devices.append(ComputeDevice(
                                device_id="gpu:amd_0",
                                name=gpu_name,
                                device_type="amd_radeon_igpu",
                                total_memory_gb=round(total_ram * 0.5, 1),  # Dynamic Shared VRAM
                                free_memory_gb=round(free_ram * 0.5, 1),
                                compute_units=cpu_cores * 2,
                                quantization_support=["fp16", "int8", "int4", "q4_k_m"],
                                is_active=True,
                            ))
                        elif "Intel" in gpu_name:
                            accelerator = "intel_gpu"
                            devices.append(ComputeDevice(
                                device_id="gpu:intel_0",
                                name=gpu_name,
                                device_type="intel_iris_igpu",
                                total_memory_gb=round(total_ram * 0.5, 1),
                                free_memory_gb=round(free_ram * 0.5, 1),
                                compute_units=cpu_cores,
                                is_active=True,
                            ))
            except Exception:
                pass

        # Check Apple Silicon Metal
        if platform.system() == "Darwin" and platform.machine() == "arm64":
            accelerator = "metal"
            devices.append(ComputeDevice(
                device_id="metal:0",
                name="Apple Neural Engine / Metal GPU (Unified)",
                device_type="apple_metal",
                total_memory_gb=total_ram,
                free_memory_gb=free_ram,
                compute_units=16,
                is_active=True,
            ))

        # CPU / AVX2 / AVX-512 Host Engine
        cpu_name = "x86_64 CPU"
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "model name" in line:
                        cpu_name = line.split(":")[1].strip()
                        break
        except Exception:
            pass

        if not devices:
            devices.append(ComputeDevice(
                device_id="cpu:0",
                name=f"{cpu_name} ({cpu_cores} Cores)",
                device_type="cpu_npu",
                total_memory_gb=total_ram,
                free_memory_gb=free_ram,
                compute_units=cpu_cores,
                is_active=True,
            ))

        # Max model recommendation
        total_avail_mem = devices[0].free_memory_gb if devices else free_ram
        if total_avail_mem >= 24.0:
            max_params = 32.0
            opt_quant = "fp16"
        elif total_avail_mem >= 12.0:
            max_params = 14.0
            opt_quant = "q8_0"
        elif total_avail_mem >= 6.0:
            max_params = 7.0
            opt_quant = "q4_k_m"
        else:
            max_params = 4.0
            opt_quant = "q4_k_s"

        return HardwareProfile(
            os_name=f"{platform.system()} {platform.release()}",
            arch=platform.machine(),
            cpu_cores=cpu_cores,
            total_ram_gb=total_ram,
            free_ram_gb=free_ram,
            accelerator=accelerator,
            devices=devices,
            optimal_quantization=opt_quant,
            max_model_param_b=max_params,
        )
