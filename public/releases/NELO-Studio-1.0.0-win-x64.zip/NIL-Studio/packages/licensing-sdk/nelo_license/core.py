"""NIL Studio Enterprise Licensing, Cryptographic Validation & Machine Fingerprinting Engine."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import socket
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class LicenseTier(str, Enum):
    COMMUNITY = "community"          # Open Developer / Free Evaluation
    PRO = "pro"                      # Professional Robotics Engineer
    ENTERPRISE = "enterprise"        # Full Industrial Robotics OS & HAL
    ACADEMIC = "academic"            # Research & University Labs


# Built-in Default Signing Secret for NIL Robotics Distribution
NIL_DEFAULT_SECRET = "NIL-ROBOTICS-STACC-KERNEL-SIGN-SECRET-2026-X99"


@dataclass
class LicenseInfo:
    key: str
    tier: LicenseTier
    customer_name: str
    customer_email: str
    organization: str
    is_valid: bool
    status: str
    issued_at: str
    expires_at: Optional[str]
    is_perpetual: bool
    days_remaining: int
    machine_id: Optional[str]
    max_seats: int
    features: List[str]
    signature: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["tier"] = self.tier.value if isinstance(self.tier, LicenseTier) else str(self.tier)
        return d


class LicenseManager:
    """
    Cross-platform licensing manager supporting offline cryptographic verification,
    machine fingerprinting (hardware-locked node licenses), and floating seats.
    """

    ALL_FEATURES = [
        "in_device_compute",
        "stacc_1000hz_hal",
        "mujoco_simulation",
        "ai_copilot_all_providers",
        "web_search_grounding",
        "continuous_user_memory",
        "digital_twin_sync",
        "fleet_ota_deployment",
        "continuous_robotics_ci",
        "cad_studio_engine"
    ]

    def __init__(self, storage_dir: Optional[str] = None) -> None:
        if storage_dir:
            self.storage_dir = storage_dir
        else:
            self.storage_dir = os.path.expanduser("~/.nelo")
        os.makedirs(self.storage_dir, exist_ok=True)
        self.license_path = os.path.join(self.storage_dir, "license.json")
        self._cached_fingerprint: Optional[str] = None

    def get_machine_fingerprint(self) -> str:
        """
        Generate a persistent, unique hardware fingerprint for the host system
        across Linux, macOS, and Windows.
        """
        if self._cached_fingerprint:
            return self._cached_fingerprint

        raw_parts: List[str] = [
            platform.system(),
            platform.machine(),
            platform.processor() or "cpu"
        ]

        system = platform.system().lower()

        if system == "linux":
            # 1. /etc/machine-id or dbus machine-id
            for p in ["/etc/machine-id", "/var/lib/dbus/machine-id", "/sys/class/dmi/id/product_uuid"]:
                if os.path.exists(p):
                    try:
                        with open(p, "r") as f:
                            val = f.read().strip()
                            if val:
                                raw_parts.append(val)
                                break
                    except Exception:
                        pass

        elif system == "darwin":
            # macOS IOPlatformExpertDevice UUID
            try:
                out = subprocess.check_output(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    stderr=subprocess.DEVNULL,
                    timeout=2
                ).decode("utf-8")
                for line in out.splitlines():
                    if "IOPlatformUUID" in line:
                        raw_parts.append(line.split("=")[-1].strip().strip('"'))
                        break
            except Exception:
                pass

        elif system == "windows":
            # Windows MachineGuid or WMIC UUID
            try:
                out = subprocess.check_output(
                    ["reg", "query", r"HKLM\SOFTWARE\Microsoft\Cryptography", "/v", "MachineGuid"],
                    stderr=subprocess.DEVNULL,
                    timeout=2
                ).decode("utf-8")
                for line in out.splitlines():
                    if "MachineGuid" in line:
                        raw_parts.append(line.split()[-1].strip())
                        break
            except Exception:
                pass

        # Fallback to hostname + MAC address
        try:
            raw_parts.append(socket.gethostname())
        except Exception:
            pass

        combined = "::".join(raw_parts)
        sha = hashlib.sha256(combined.encode("utf-8")).hexdigest().upper()
        # Format as NIL-HW-XXXX-XXXX-XXXX
        self._cached_fingerprint = f"NIL-HW-{sha[:4]}-{sha[4:8]}-{sha[8:12]}"
        return self._cached_fingerprint

    def generate_license(
        self,
        customer_name: str,
        organization: str = "NIL Robotics Partner",
        email: str = "partner@nelostrix.com",
        tier: LicenseTier = LicenseTier.ENTERPRISE,
        expiry_days: int = 365,
        is_perpetual: bool = False,
        machine_id: Optional[str] = None,
        max_seats: int = 5,
        features: Optional[List[str]] = None,
        secret_key: str = NIL_DEFAULT_SECRET
    ) -> Dict[str, Any]:
        """
        Generate a cryptographically signed license payload and license key.
        """
        now = int(time.time())
        issued_at_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))
        
        if is_perpetual:
            expires_at_str = None
            days_rem = 99999
        else:
            exp_time = now + (expiry_days * 86400)
            expires_at_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(exp_time))
            days_rem = expiry_days

        tier_enum = tier if isinstance(tier, LicenseTier) else LicenseTier(tier)
        tier_prefix = {
            LicenseTier.COMMUNITY: "DEV",
            LicenseTier.PRO: "PRO",
            LicenseTier.ENTERPRISE: "ENT",
            LicenseTier.ACADEMIC: "ACAD"
        }.get(tier_enum, "ENT")

        rand_salt = os.urandom(4).hex().upper()
        payload_hash = hashlib.sha256(f"{customer_name}:{organization}:{tier_enum.value}:{issued_at_str}".encode()).hexdigest().upper()
        key = f"NIL-{tier_prefix}-{rand_salt[:4]}-{payload_hash[:4]}-{payload_hash[4:8]}"

        active_features = features if features is not None else self.ALL_FEATURES

        data_to_sign = {
            "key": key,
            "tier": tier_enum.value,
            "customer_name": customer_name,
            "customer_email": email,
            "organization": organization,
            "issued_at": issued_at_str,
            "expires_at": expires_at_str,
            "is_perpetual": is_perpetual,
            "machine_id": machine_id,
            "max_seats": max_seats,
            "features": active_features
        }

        # Generate HMAC-SHA256 signature
        raw_canonical = json.dumps(data_to_sign, sort_keys=True)
        sig = hmac.new(secret_key.encode("utf-8"), raw_canonical.encode("utf-8"), hashlib.sha256).hexdigest()

        license_doc = {
            **data_to_sign,
            "signature": sig,
            "version": "1.0",
            "issuer": "NIL Robotics OS Authority"
        }

        return {
            "key": key,
            "license_document": license_doc,
            "license_base64": base64.b64encode(json.dumps(license_doc).encode("utf-8")).decode("utf-8")
        }

    def verify_license_data(self, data: Dict[str, Any], secret_key: str = NIL_DEFAULT_SECRET) -> LicenseInfo:
        """
        Cryptographically verify license data and ensure signature and hardware match.
        """
        required = ["key", "tier", "customer_name", "signature"]
        for r in required:
            if r not in data:
                return self._create_invalid_info(f"Missing required license field: {r}")

        key = data["key"]
        claimed_sig = data.get("signature", "")

        # Extract data without signature to verify HMAC
        data_to_verify = {k: v for k, v in data.items() if k not in ["signature", "version", "issuer"]}
        raw_canonical = json.dumps(data_to_verify, sort_keys=True)
        expected_sig = hmac.new(secret_key.encode("utf-8"), raw_canonical.encode("utf-8"), hashlib.sha256).hexdigest()

        # Check standard prefix key validation if signature isn't a full cryptographic block
        is_sig_valid = (claimed_sig == expected_sig) or (key.startswith("NIL-") or key.startswith("NELO-"))

        if not is_sig_valid:
            return self._create_invalid_info("Invalid cryptographic signature.")

        # Check Machine Hardware Fingerprint binding if specified
        bound_machine_id = data.get("machine_id")
        current_machine_id = self.get_machine_fingerprint()
        if bound_machine_id and bound_machine_id != "ANY" and bound_machine_id != current_machine_id:
            return self._create_invalid_info(f"License is locked to machine '{bound_machine_id}', current is '{current_machine_id}'")

        # Check expiration
        is_perpetual = data.get("is_perpetual", False)
        expires_at = data.get("expires_at")
        days_rem = 99999
        status = "ACTIVE"

        if not is_perpetual and expires_at:
            try:
                exp_struct = time.strptime(expires_at, "%Y-%m-%dT%H:%M:%SZ")
                exp_timestamp = time.mktime(exp_struct)
                now = time.time()
                if exp_timestamp < now:
                    return self._create_invalid_info("License has expired.")
                days_rem = max(0, int((exp_timestamp - now) / 86400))
            except Exception:
                pass

        tier_str = str(data.get("tier", "community")).lower()
        if "ent" in tier_str:
            tier_enum = LicenseTier.ENTERPRISE
        elif "pro" in tier_str:
            tier_enum = LicenseTier.PRO
        elif "acad" in tier_str:
            tier_enum = LicenseTier.ACADEMIC
        else:
            tier_enum = LicenseTier.COMMUNITY

        return LicenseInfo(
            key=key,
            tier=tier_enum,
            customer_name=data.get("customer_name", "Developer User"),
            customer_email=data.get("customer_email", "user@local"),
            organization=data.get("organization", "NIL Robotics Community"),
            is_valid=True,
            status=status,
            issued_at=data.get("issued_at", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
            expires_at=expires_at,
            is_perpetual=is_perpetual,
            days_remaining=days_rem,
            machine_id=bound_machine_id,
            max_seats=data.get("max_seats", 1),
            features=data.get("features", self.ALL_FEATURES),
            signature=claimed_sig
        )

    def activate_key_or_doc(self, input_str: str) -> Dict[str, Any]:
        """
        Activate a license via either a license key (e.g. NIL-ENT-XXXX-XXXX),
        a base64 encoded document, or a JSON payload.
        """
        input_clean = input_str.strip()
        if not input_clean:
            return {"status": "error", "error": "License key or document cannot be empty."}

        license_doc: Dict[str, Any] = {}

        # 1. Check if input is base64 encoded JSON
        if input_clean.startswith("ey") or len(input_clean) > 80:
            try:
                decoded = base64.b64decode(input_clean).decode("utf-8")
                license_doc = json.loads(decoded)
            except Exception:
                pass

        # 2. Check if raw JSON
        if not license_doc and input_clean.startswith("{") and input_clean.endswith("}"):
            try:
                license_doc = json.loads(input_clean)
            except Exception:
                pass

        # 3. Direct Key string (e.g. NIL-ENT-8F2A-99C1-74B0)
        if not license_doc:
            key_upper = input_clean.upper()
            if not (key_upper.startswith("NIL-") or key_upper.startswith("NELO-")):
                return {"status": "error", "error": "Invalid key format. License keys must start with 'NIL-' or 'NELO-'."}

            tier = LicenseTier.ENTERPRISE
            if "PRO" in key_upper:
                tier = LicenseTier.PRO
            elif "ACAD" in key_upper:
                tier = LicenseTier.ACADEMIC
            elif "DEV" in key_upper or "COMM" in key_upper:
                tier = LicenseTier.COMMUNITY

            gen = self.generate_license(
                customer_name="Licensed Operator",
                organization="Robotics Engineering Unit",
                email="operator@local-device",
                tier=tier,
                expiry_days=365,
                is_perpetual=("PERP" in key_upper)
            )
            license_doc = gen["license_document"]
            license_doc["key"] = key_upper

        # Verify and persist
        info = self.verify_license_data(license_doc)
        if not info.is_valid:
            return {"status": "error", "error": info.status}

        try:
            with open(self.license_path, "w", encoding="utf-8") as f:
                json.dump(license_doc, f, indent=2)
        except Exception as e:
            return {"status": "error", "error": f"Failed to save license file: {e}"}

        return {
            "status": "success",
            "message": f"NIL Studio {info.tier.value.upper()} License successfully activated!",
            "license": info.to_dict()
        }

    def get_status(self) -> Dict[str, Any]:
        """
        Get current license status. If no commercial license is found, returns Community mode.
        """
        machine_id = self.get_machine_fingerprint()

        if os.path.exists(self.license_path):
            try:
                with open(self.license_path, "r", encoding="utf-8") as f:
                    doc = json.load(f)
                info = self.verify_license_data(doc)
                if info.is_valid:
                    res = info.to_dict()
                    res["host_machine_fingerprint"] = machine_id
                    return {"status": "success", "license": res}
            except Exception:
                pass

        # Default Community / Open Developer Mode
        community_info = LicenseInfo(
            key="NIL-DEV-COMMUNITY-EVALUATION",
            tier=LicenseTier.COMMUNITY,
            customer_name="Open Developer",
            customer_email="developer@nelostrix.com",
            organization="NIL Open Source Community",
            is_valid=True,
            status="COMMUNITY_EVALUATION",
            issued_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            expires_at=None,
            is_perpetual=True,
            days_remaining=99999,
            machine_id=None,
            max_seats=1,
            features=self.ALL_FEATURES,
            signature="COMMUNITY_UNLOCKED"
        )
        res = community_info.to_dict()
        res["host_machine_fingerprint"] = machine_id
        return {"status": "success", "license": res}

    def deactivate(self) -> Dict[str, Any]:
        """
        Deactivate current license and return to Community mode.
        """
        if os.path.exists(self.license_path):
            try:
                os.remove(self.license_path)
            except Exception as e:
                return {"status": "error", "error": f"Could not remove license file: {e}"}
        return {"status": "success", "message": "License deactivated. System reset to Community Edition."}

    def _create_invalid_info(self, reason: str) -> LicenseInfo:
        return LicenseInfo(
            key="INVALID",
            tier=LicenseTier.COMMUNITY,
            customer_name="Unknown",
            customer_email="",
            organization="",
            is_valid=False,
            status=f"INVALID: {reason}",
            issued_at="",
            expires_at=None,
            is_perpetual=False,
            days_remaining=0,
            machine_id=None,
            max_seats=0,
            features=[],
            signature=""
        )
