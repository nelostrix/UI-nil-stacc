"""NIL Robotics SDK — Core Robotics Abstraction Layer."""

from __future__ import annotations

import math
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple


class JointType(str, Enum):
    REVOLUTE = "revolute"
    PRISMATIC = "prismatic"
    CONTINUOUS = "continuous"
    FIXED = "fixed"
    FLOATING = "floating"


@dataclass
class JointLimits:
    lower: float = -math.pi
    upper: float = math.pi
    max_velocity: float = 3.0  # rad/s or m/s
    max_effort: float = 50.0   # Nm or N
    friction: float = 0.05
    damping: float = 0.1


@dataclass
class Joint:
    name: str
    joint_type: JointType = JointType.REVOLUTE
    parent_link: str = "base_link"
    child_link: str = "link_1"
    axis: Tuple[float, float, float] = (0.0, 0.0, 1.0)
    origin_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    origin_rpy: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    limits: JointLimits = field(default_factory=JointLimits)
    position: float = 0.0
    velocity: float = 0.0
    target_position: float = 0.0
    applied_torque: float = 0.0

    def set_position(self, pos: float) -> None:
        self.position = max(self.limits.lower, min(self.limits.upper, pos))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.joint_type.value,
            "parent": self.parent_link,
            "child": self.child_link,
            "position": self.position,
            "velocity": self.velocity,
            "target": self.target_position,
            "limits": {
                "lower": self.limits.lower,
                "upper": self.limits.upper,
                "max_velocity": self.limits.max_velocity,
                "max_effort": self.limits.max_effort,
            },
        }


@dataclass
class Link:
    name: str
    mass: float = 1.0  # kg
    inertia: Tuple[float, float, float] = (0.01, 0.01, 0.01)  # Ixx, Iyy, Izz
    center_of_mass: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    visual_mesh: Optional[str] = None
    collision_mesh: Optional[str] = None


@dataclass
class Actuator:
    name: str
    joint_name: str
    motor_type: str = "bldc"
    gear_ratio: float = 50.0
    rated_torque: float = 12.0  # Nm
    peak_torque: float = 36.0   # Nm
    thermal_limit_c: float = 85.0
    temperature_c: float = 25.0
    current_limit_a: float = 15.0
    efficiency: float = 0.92

    def calculate_effective_torque(self, demanded_torque: float) -> float:
        clipped = max(-self.peak_torque, min(self.peak_torque, demanded_torque))
        if self.temperature_c > self.thermal_limit_c:
            clipped *= 0.5  # Thermal de-rating
        return clipped * self.efficiency


class Robot:
    """Universal NIL Robot model representation."""

    def __init__(self, name: str = "nelo_robot", urdf_path: Optional[str] = None) -> None:
        self.name = name
        self.urdf_path = urdf_path
        self.joints: Dict[str, Joint] = {}
        self.links: Dict[str, Link] = {}
        self.actuators: Dict[str, Actuator] = {}
        self.sensors: Dict[str, Any] = {}
        self.controllers: Dict[str, Any] = {}
        self._state_callbacks: List[Callable[[Dict[str, Any]], None]] = []

    def add_joint(self, joint: Joint) -> None:
        self.joints[joint.name] = joint

    def add_link(self, link: Link) -> None:
        self.links[link.name] = link

    def add_actuator(self, actuator: Actuator) -> None:
        self.actuators[actuator.name] = actuator

    def add_sensor(self, name: str, sensor: Any) -> None:
        self.sensors[name] = sensor

    @property
    def dof(self) -> int:
        return sum(1 for j in self.joints.values() if j.joint_type != JointType.FIXED)

    def get_joint_positions(self) -> List[float]:
        return [j.position for j in self.joints.values() if j.joint_type != JointType.FIXED]

    def set_joint_positions(self, positions: List[float]) -> None:
        active = [j for j in self.joints.values() if j.joint_type != JointType.FIXED]
        for j, pos in zip(active, positions):
            j.set_position(pos)
        self._notify_state_change()

    def get_joint_velocities(self) -> List[float]:
        return [j.velocity for j in self.joints.values() if j.joint_type != JointType.FIXED]

    def get_state(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "dof": self.dof,
            "positions": self.get_joint_positions(),
            "velocities": self.get_joint_velocities(),
            "joints": {k: v.to_dict() for k, v in self.joints.items()},
            "sensors": {k: s.read() if hasattr(s, "read") else {} for k, s in self.sensors.items()},
        }

    def _notify_state_change(self) -> None:
        state = self.get_state()
        for cb in self._state_callbacks:
            try:
                cb(state)
            except Exception:
                pass

    def on_state_change(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._state_callbacks.append(callback)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "dof": self.dof,
            "links": [l.name for l in self.links.values()],
            "joints": [j.to_dict() for j in self.joints.values()],
            "actuators": [a.name for a in self.actuators.values()],
            "sensors": list(self.sensors.keys()),
        }
