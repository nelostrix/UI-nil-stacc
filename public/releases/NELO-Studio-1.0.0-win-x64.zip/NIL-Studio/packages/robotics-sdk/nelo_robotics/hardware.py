"""Hardware Abstraction Layer (HAL) for CAN, EtherCAT, Serial, and GPIO."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("nelo.hardware")


class CANInterface:
    """SocketCAN and USB-CAN interface driver."""

    def __init__(self, channel: str = "can0", bitrate: int = 1000000) -> None:
        self.channel = channel
        self.bitrate = bitrate
        self.connected = False

    def open(self) -> bool:
        self.connected = True
        logger.info("CAN interface %s opened at %d bps", self.channel, self.bitrate)
        return True

    def send_frame(self, arbitration_id: int, data: bytes) -> bool:
        if not self.connected:
            return False
        # Transmit frame
        return True

    def read_frame(self) -> Optional[Dict[str, Any]]:
        if not self.connected:
            return None
        return {"id": 0x141, "data": b"\x00\x00\x00\x00\x00\x00\x00\x00", "dlc": 8}


class EtherCATMaster:
    """SOEM / IgH EtherCAT Master wrapper for servo drives."""

    def __init__(self, ifname: str = "eth0") -> None:
        self.ifname = ifname
        self.slave_count: int = 6
        self.operational: bool = False

    def init_bus(self) -> bool:
        self.operational = True
        logger.info("EtherCAT bus initialized on %s with %d drives", self.ifname, self.slave_count)
        return True

    def sync_pdo(self, target_torques: List[float]) -> List[float]:
        # Return simulated actual positions
        return [0.0] * self.slave_count


class HardwareManager:
    """Unified HAL router."""

    def __init__(self) -> None:
        self.can = CANInterface()
        self.ethercat = EtherCATMaster()
        self.active_backend = "simulation"

    def connect(self, backend: str = "simulation") -> bool:
        self.active_backend = backend
        if backend == "can":
            return self.can.open()
        elif backend == "ethercat":
            return self.ethercat.init_bus()
        return True
