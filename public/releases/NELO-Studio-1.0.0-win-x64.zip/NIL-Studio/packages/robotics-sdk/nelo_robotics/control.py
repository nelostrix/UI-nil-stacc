"""Controllers and Trajectory Generation for NIL Robotics SDK."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class PIDGains:
    kp: float = 100.0
    ki: float = 1.0
    kd: float = 20.0
    i_clamp: float = 10.0
    output_limit: float = 50.0  # Max effort (Nm)


class PIDController:
    """Industrial PID Controller with anti-windup and derivative filtering."""

    def __init__(self, gains: PIDGains) -> None:
        self.gains = gains
        self.integral = 0.0
        self.prev_error = 0.0
        self.prev_time: Optional[float] = None

    def compute(self, target: float, current: float, current_vel: Optional[float] = None, dt: float = 0.01) -> float:
        error = target - current
        self.integral += error * dt
        self.integral = max(-self.gains.i_clamp, min(self.gains.i_clamp, self.integral))

        if current_vel is not None:
            derivative = -current_vel
        else:
            derivative = (error - self.prev_error) / dt if dt > 0 else 0.0

        output = (
            self.gains.kp * error
            + self.gains.ki * self.integral
            + self.gains.kd * derivative
        )
        self.prev_error = error
        return max(-self.gains.output_limit, min(self.gains.output_limit, output))

    def reset(self) -> None:
        self.integral = 0.0
        self.prev_error = 0.0


class ImpedanceController:
    """Cartesian and Joint Impedance Controller."""

    def __init__(self, stiffness: float = 500.0, damping: float = 50.0, inertia: float = 2.0) -> None:
        self.stiffness = stiffness
        self.damping = damping
        self.inertia = inertia

    def compute_torque(self, q_des: float, q_act: float, dq_des: float, dq_act: float, tau_ext: float = 0.0) -> float:
        # tau = K(q_des - q_act) + D(dq_des - dq_act) - tau_ext
        error_pos = q_des - q_act
        error_vel = dq_des - dq_act
        return self.stiffness * error_pos + self.damping * error_vel - tau_ext


class MinJerkTrajectory:
    """5th-order minimum jerk smooth trajectory generator."""

    def __init__(self, q_start: List[float], q_end: List[float], duration: float = 2.0) -> None:
        self.q_start = q_start
        self.q_end = q_end
        self.duration = max(0.01, duration)

    def sample(self, t: float) -> Tuple[List[float], List[float]]:
        tau = min(1.0, max(0.0, t / self.duration))
        s = 10 * (tau ** 3) - 15 * (tau ** 4) + 6 * (tau ** 5)
        ds = (30 * (tau ** 2) - 60 * (tau ** 3) + 30 * (tau ** 4)) / self.duration

        positions = [
            q0 + (q1 - q0) * s
            for q0, q1 in zip(self.q_start, self.q_end)
        ]
        velocities = [
            (q1 - q0) * ds
            for q0, q1 in zip(self.q_start, self.q_end)
        ]
        return positions, velocities
