"""Kinematics & Dynamics for NIL Robotics SDK."""

from __future__ import annotations

import math
from typing import List, Tuple, Optional
import numpy as np


class ForwardKinematics:
    """Forward Kinematics using DH parameters and transformation matrices."""

    def __init__(self, dh_params: Optional[List[Tuple[float, float, float, float]]] = None) -> None:
        # DH params: list of (alpha, a, d, theta_offset)
        self.dh_params = dh_params or [
            (math.pi / 2, 0.0, 0.33, 0.0),
            (0.0, 0.45, 0.0, 0.0),
            (math.pi / 2, 0.0, 0.0, 0.0),
            (-math.pi / 2, 0.0, 0.40, 0.0),
            (math.pi / 2, 0.0, 0.0, 0.0),
            (0.0, 0.0, 0.15, 0.0),
        ]

    def compute_fk(self, joint_angles: List[float]) -> np.ndarray:
        """Compute 4x4 homogenous transformation matrix for end effector."""
        T = np.eye(4)
        for i, angle in enumerate(joint_angles[: len(self.dh_params)]):
            alpha, a, d, theta_offset = self.dh_params[i]
            theta = angle + theta_offset
            ct = math.cos(theta)
            st = math.sin(theta)
            ca = math.cos(alpha)
            sa = math.sin(alpha)

            Ti = np.array([
                [ct, -st * ca,  st * sa, a * ct],
                [st,  ct * ca, -ct * sa, a * st],
                [0.0,     sa,       ca,      d],
                [0.0,    0.0,      0.0,    1.0],
            ])
            T = T @ Ti
        return T

    def get_position(self, joint_angles: List[float]) -> Tuple[float, float, float]:
        T = self.compute_fk(joint_angles)
        return float(T[0, 3]), float(T[1, 3]), float(T[2, 3])


class InverseKinematics:
    """Damped Least-Squares (Levenberg-Marquardt) Numerical IK."""

    def __init__(self, fk: ForwardKinematics, damping: float = 0.05, max_iter: int = 100, tol: float = 1e-4) -> None:
        self.fk = fk
        self.damping = damping
        self.max_iter = max_iter
        self.tol = tol

    def solve(self, target_pos: Tuple[float, float, float], initial_guess: Optional[List[float]] = None) -> List[float]:
        q = np.array(initial_guess if initial_guess is not None else [0.0] * len(self.fk.dh_params), dtype=float)
        target = np.array(target_pos, dtype=float)

        for _ in range(self.max_iter):
            curr_pos = np.array(self.fk.get_position(q.tolist()), dtype=float)
            error = target - curr_pos
            if np.linalg.norm(error) < self.tol:
                break

            # Numerical Jacobian approximation (3xN)
            J = np.zeros((3, len(q)))
            eps = 1e-6
            for i in range(len(q)):
                q_plus = q.copy()
                q_plus[i] += eps
                pos_plus = np.array(self.fk.get_position(q_plus.tolist()))
                J[:, i] = (pos_plus - curr_pos) / eps

            # Damped Least Squares: dq = J^T (J J^T + lambda^2 I)^-1 error
            JJT = J @ J.T + (self.damping ** 2) * np.eye(3)
            dq = J.T @ np.linalg.solve(JJT, error)
            q += np.clip(dq, -0.2, 0.2)

        return q.tolist()
