"""Perception, Sensors, and Computer Vision for NIL Robotics SDK."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class BoundingBox:
    label: str
    confidence: float
    bbox_2d: Tuple[float, float, float, float]  # xmin, ymin, xmax, ymax
    center_3d: Optional[Tuple[float, float, float]] = None


class CameraSensor:
    """RGB-D Camera model with intrinsics and noise."""

    def __init__(self, name: str = "rgbd_camera", width: int = 640, height: int = 480, fov_deg: float = 60.0) -> None:
        self.name = name
        self.width = width
        self.height = height
        self.fov = math.radians(fov_deg)
        self.fx = (width / 2.0) / math.tan(self.fov / 2.0)
        self.fy = self.fx
        self.cx = width / 2.0
        self.cy = height / 2.0

    def read(self) -> Dict[str, Any]:
        return {
            "sensor": self.name,
            "width": self.width,
            "height": self.height,
            "intrinsics": {"fx": self.fx, "fy": self.fy, "cx": self.cx, "cy": self.cy},
            "status": "streaming",
        }

    def detect_objects(self, mock_objects: Optional[List[Dict[str, Any]]] = None) -> List[BoundingBox]:
        """Mock perception pipeline for vision-based picking."""
        if mock_objects:
            return [
                BoundingBox(
                    label=obj.get("label", "part"),
                    confidence=obj.get("confidence", 0.95),
                    bbox_2d=obj.get("bbox", (100, 100, 200, 200)),
                    center_3d=obj.get("center_3d", (0.35, -0.1, 0.05)),
                )
                for obj in mock_objects
            ]
        return [
            BoundingBox(
                label="payload_box_red",
                confidence=0.98,
                bbox_2d=(180.0, 120.0, 320.0, 260.0),
                center_3d=(0.42, 0.15, 0.08),
            )
        ]


class IMUSensor:
    """9-Axis IMU with accelerometer, gyro, and magnetics."""

    def __init__(self, name: str = "imu", noise_std: float = 0.005) -> None:
        self.name = name
        self.noise_std = noise_std

    def read(self) -> Dict[str, Any]:
        ax = random.gauss(0.0, self.noise_std)
        ay = random.gauss(0.0, self.noise_std)
        az = 9.81 + random.gauss(0.0, self.noise_std)
        return {
            "sensor": self.name,
            "accel": [ax, ay, az],
            "gyro": [random.gauss(0.0, 0.001) for _ in range(3)],
            "mag": [0.2, 0.0, 0.4],
        }
