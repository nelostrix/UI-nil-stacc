"""Motion and Path Planning for NIL Robotics SDK."""

from __future__ import annotations

import heapq
import math
from typing import List, Optional, Tuple


class AStarPlanner:
    """2D / 3D Grid Path Planning with collision checking."""

    def __init__(self, grid_size: Tuple[int, int] = (100, 100), resolution: float = 0.05) -> None:
        self.width, self.height = grid_size
        self.resolution = resolution
        self.obstacles: set[Tuple[int, int]] = set()

    def add_obstacle(self, x: float, y: float, radius: float = 0.1) -> None:
        gx, gy = int(x / self.resolution), int(y / self.resolution)
        r_cells = int(radius / self.resolution)
        for dx in range(-r_cells, r_cells + 1):
            for dy in range(-r_cells, r_cells + 1):
                if dx * dx + dy * dy <= r_cells * r_cells:
                    self.obstacles.add((gx + dx, gy + dy))

    def plan(self, start: Tuple[float, float], goal: Tuple[float, float]) -> Optional[List[Tuple[float, float]]]:
        sx, sy = int(start[0] / self.resolution), int(start[1] / self.resolution)
        gx, gy = int(goal[0] / self.resolution), int(goal[1] / self.resolution)

        open_set: List[Tuple[float, int, int]] = [(0.0, sx, sy)]
        came_from: dict[Tuple[int, int], Tuple[int, int]] = {}
        g_score: dict[Tuple[int, int], float] = {(sx, sy): 0.0}

        def heuristic(a: Tuple[int, int], b: Tuple[int, int]) -> float:
            return math.hypot(a[0] - b[0], a[1] - b[1])

        while open_set:
            _, cx, cy = heapq.heappop(open_set)
            if (cx, cy) == (gx, gy):
                path = []
                curr = (gx, gy)
                while curr in came_from:
                    path.append((curr[0] * self.resolution, curr[1] * self.resolution))
                    curr = came_from[curr]
                path.append((sx * self.resolution, sy * self.resolution))
                return path[::-1]

            for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]:
                nx, ny = cx + dx, cy + dy
                if (nx, ny) in self.obstacles:
                    continue
                step_cost = 1.414 if dx != 0 and dy != 0 else 1.0
                tentative_g = g_score[(cx, cy)] + step_cost
                if (nx, ny) not in g_score or tentative_g < g_score[(nx, ny)]:
                    g_score[(nx, ny)] = tentative_g
                    f_score = tentative_g + heuristic((nx, ny), (gx, gy))
                    heapq.heappush(open_set, (f_score, nx, ny))
                    came_from[(nx, ny)] = (cx, cy)

        return None
