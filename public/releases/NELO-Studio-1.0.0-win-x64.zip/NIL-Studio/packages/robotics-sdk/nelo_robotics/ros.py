"""ROS 2 Bridge and Topic/Service/Action Abstraction for NIL Robotics SDK."""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional


class ROSTopic:
    """Mock/Real ROS 2 Topic wrapper."""

    def __init__(self, name: str, msg_type: str) -> None:
        self.name = name
        self.msg_type = msg_type
        self.subscribers: List[Callable[[Any], None]] = []
        self.last_message: Optional[Any] = None
        self.message_count: int = 0

    def publish(self, msg: Any) -> None:
        self.last_message = msg
        self.message_count += 1
        for sub in self.subscribers:
            try:
                sub(msg)
            except Exception:
                pass

    def subscribe(self, callback: Callable[[Any], None]) -> None:
        self.subscribers.append(callback)


class ROSNode:
    """Universal ROS 2 Node container."""

    def __init__(self, node_name: str = "nelo_core_node") -> None:
        self.node_name = node_name
        self.topics: Dict[str, ROSTopic] = {}
        self.services: Dict[str, Callable[[Any], Any]] = {}

    def create_publisher(self, topic_name: str, msg_type: str) -> ROSTopic:
        if topic_name not in self.topics:
            self.topics[topic_name] = ROSTopic(topic_name, msg_type)
        return self.topics[topic_name]

    def create_subscription(self, topic_name: str, msg_type: str, callback: Callable[[Any], None]) -> ROSTopic:
        topic = self.create_publisher(topic_name, msg_type)
        topic.subscribe(callback)
        return topic

    def get_graph_state(self) -> Dict[str, Any]:
        return {
            "node": self.node_name,
            "topics": [
                {
                    "name": t.name,
                    "type": t.msg_type,
                    "sub_count": len(t.subscribers),
                    "msg_count": t.message_count,
                }
                for t in self.topics.values()
            ],
            "services": list(self.services.keys()),
        }
