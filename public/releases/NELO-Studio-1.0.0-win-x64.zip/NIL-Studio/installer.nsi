!define APP_NAME "NIL Studio"
!define APP_VERSION "1.0.0"
!define APP_PUBLISHER "NIL Robotics OS"
!define APP_DIR "$LOCALAPPDATA\NIL-Studio"

Name "${APP_NAME}"
OutFile "NIL-Studio-Setup.exe"
InstallDir "${APP_DIR}"

Section "Install"
    SetOutPath "$INSTDIR"
    File /r "*.*"
    CreateShortcut "$DESKTOP\NIL Studio.lnk" "$INSTDIR\nil-studio.bat" "" "$INSTDIR\apps\desktop\logo.png"
    CreateShortcut "$SMPROGRAMS\NIL Studio.lnk" "$INSTDIR\nil-studio.bat" "" "$INSTDIR\apps\desktop\logo.png"
SectionEnd
