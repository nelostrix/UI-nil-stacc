@echo off
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%packages\robotics-sdk;%DIR%packages\digital-twin;%DIR%packages\ai-sdk;%DIR%packages\simulation-sdk;%DIR%packages\validation-ci;%DIR%packages\fleet-sdk;%DIR%packages\control-plane-api;%DIR%packages\compute-engine;%DIR%packages\licensing-sdk;%PYTHONPATH%"
python "%DIR%bin\nelo-studio" studio %*
