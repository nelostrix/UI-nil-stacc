# NIL STUDIO / NELO-Studio
### *The AI-Native Robotics Engineering Operating System*

```
                           NIL STUDIO
                AI-Native Robotics Engineering OS
                                   │
       ┌───────────────────────────┼───────────────────────────┐
       │                           │                           │
   DEVELOPMENT                 SIMULATION                 INTELLIGENCE
       │                           │                           │
   Code IDE                   Digital Twins                AI Agents
   ROS 2                       Physics                     Planning
   SDK                         Sensors                     Reasoning
   Debugger                    Environments                Optimization
       │                           │                           │
       └───────────────────────────┼───────────────────────────┘
                                   │
                              VALIDATION
                                   │
                            ┌──────┴──────┐
                            │             │
                         SOFTWARE      HARDWARE
                            │             │
                         CI/CD       Fleet / Edge
                            │             │
                            └──────┬──────┘
                                   │
                             DEPLOYMENT
                                   │
                              REAL ROBOTS
```

---

## ⚡ Cross-Platform Single-Command Installation (Linux, macOS, Windows)

### 🐧 Linux (Ubuntu, Debian, Fedora, Arch, RHEL)
```bash
# Automated System Installer (/opt/nil-studio & /usr/local/bin/nil-studio)
./scripts/installers/install_linux.sh

# Or install via Debian Package:
sudo dpkg -i dist/deb-stage/nil-studio_1.0.0_amd64.deb
```

### 🍎 macOS (Apple Silicon M1/M2/M3/M4 & Intel x86_64)
```bash
# Automated macOS .app Bundle Installer (/Applications/NIL Studio.app)
./scripts/installers/install_mac.sh
```

### 🪟 Windows (10/11 x64)
```powershell
# PowerShell Single-Step Setup (%LOCALAPPDATA%\NIL-Studio + Start Menu + Desktop)
powershell -ExecutionPolicy Bypass -File .\scripts\installers\install_windows.ps1

# Or double-click:
.\scripts\installers\install_windows.bat
```

---

## 🔑 Commercial Licensing & Machine Activation

NIL Studio features an offline cryptographic licensing and machine hardware fingerprinting engine:

```bash
# 1. View current license status and active entitlements
nelo-studio license status

# 2. Inspect host machine hardware fingerprint (Node-Lock ID)
nelo-studio license fingerprint

# 3. Activate a commercial license key (or paste signed license document)
nelo-studio license activate NIL-ENT-A8F2-99C1-74B0

# 4. Generate a cryptographically signed license for a customer (Admin CLI)
nelo-studio license generate --customer "NASA JPL" --org "Mars Robotics" --tier enterprise --days 365

# 5. Build cross-platform distribution installers
nelo-studio package --platform all
```

---

## 🚀 Quick Start

```bash
# 1. Scaffold a new robotics project
nelo-studio init palletizing_cell --template manipulator

# 2. Launch the 3D Desktop Studio UI
nelo-studio studio --port 3000

# 3. Instruct the AI Engineering Agent Team
nelo-studio agent "Make this 6-DOF arm pick conveyor boxes and tune PID"

# 4. Run Continuous Robotics Validation (Robotics CI)
nelo-studio ci --build 1842 --strict

# 5. Manage Physical Robot Fleet & Deploy Policies OTA
nelo-studio fleet
nelo-studio fleet --deploy ROBOT-001 warehouse_pick_v14
```

---

## 🏛️ The 8 Major Subsystems

### 1. NIL Studio Desktop (`apps/desktop`)
* **3D Viewport & Digital Twin**: WebGL & Three.js canvas with interactive kinematics, collision envelopes, and sensor frustums.
* **Project Explorer**: Monorepo file explorer (`robot/`, `urdf/`, `control/`, `vision/`, `planner/`, `simulation/`, `src/`).
* **Robot Inspector**: Real-time joint sliders, limit indicators, and actuator state.
* **ROS 2 Graph & Topic Inspector**: Active topic rates, subscriber counts, and message debuggers.
* **Debugger & Telemetry**: Live torque plots, RTOS jitter monitoring, and motor temperature sparklines.
* **AI Copilot Panel**: Multi-agent collaborative engineering chat with step-by-step tool execution.

### 2. NIL Robotics SDK (`packages/robotics-sdk`)
* `core/`: Unified `Robot`, `Joint`, `Actuator`, `Sensor`, and `Link` classes.
* `kinematics/`: Forward Kinematics (DH matrix) and Damped Least-Squares Inverse Kinematics.
* `control/`: Anti-windup industrial PID, Impedance control, and Min-Jerk trajectory generators.
* `planning/`: 2D/3D A* grid planner with dynamic obstacle dilation.
* `perception/`: RGB-D cameras, 9-axis IMUs, and 6D pose estimators.
* `ros/`: ROS 2 Node, Topic, Service, and Action bridge abstraction.
* `hardware/`: Hardware Abstraction Layer for CAN, EtherCAT, Serial, and GPIO.

### 3. NIL Digital Twin (`packages/digital-twin`)
* Full synchronization between physical robots and simulation.
* Motor characteristics (torque constants, back-EMF, rotor inertia, thermal resistance).
* Dynamic payload & Center of Mass (CoM) estimation.
* Sensor noise profiles and camera calibration matrices.
* Safety envelope monitoring and parameter drift detection.

### 4. NIL AI Engineering Layer (`packages/ai-sdk`)
* **Robotics Architect**: `inspect_robot()`, `design_robot()`, `modify_urdf()`, `calculate_workspace()`, `check_constraints()`
* **Controls Engineer**: `identify_dynamics()`, `tune_pid()`, `design_controller()`, `run_stability_test()`, `analyze_oscillation()`
* **Perception Engineer**: `inspect_camera()`, `calibrate_camera()`, `build_pipeline()`, `evaluate_detection()`
* **Simulation Agent**: `create_world()`, `run_simulation()`, `inject_fault()`, `analyze_failure()`, `compare_runs()`
* **Deployment Agent**: `build_package()`, `run_hardware_checks()`, `deploy()`, `rollback()`

### 5. NIL Simulation & Fault Injection (`packages/simulation-sdk`)
* Multi-physics simulation loop at 1000Hz.
* **Enterprise Fault Injection Suite**:
  * Sensor dropout & packet loss
  * Encoder drift & Gaussian noise
  * Actuator delay & mechanical backlash
  * Motor torque saturation & thermal de-rating
  * Camera occlusion & lens flare blowout

### 6. Continuous Robotics Validation / CI (`packages/validation-ci`)
* Automated CI suite executing on every commit:
  * Unit tests & kinematics bounds
  * Simulation rollouts with Monte Carlo perturbations
  * Safety boundary and torque limit checks
  * Performance regression gating (Tracking error +X%, collision rate +Y%)
  * Automated PASS/FAIL deployment blocking.

### 7. NIL Fleet & Edge Deployment (`packages/fleet-sdk`)
* Fleet-wide status monitoring (`ROBOT-001` .. `ROBOT-005`).
* Live telemetry: Firmware version, NIL runtime, battery %, CPU/GPU %, temperatures.
* Instant OTA policy deployment, remote service restart, and safety rollback.

### 8. NIL Enterprise Control Plane (`packages/control-plane-api`)
* REST & WebSocket APIs on port 8080.
* Multi-tenant Organizations, Teams, Projects, Digital Twins, and Fleets.
* Role-Based Access Control (RBAC), Audit logs, Secrets management, and compliance accounting.

---

## 📦 Package Layout

```
NELO-Studio/
├── bin/
│   └── nelo-studio                  # Unified CLI executable
├── apps/
│   ├── desktop/                     # 3D Studio Desktop Application
│   ├── control-plane/               # Enterprise dashboard
│   └── docs/                        # Documentation
├── packages/
│   ├── robotics-sdk/                # Core robotics abstraction
│   ├── digital-twin/                # Digital Twin synchronization engine
│   ├── ai-sdk/                      # AI Engineering Agent Team & Orchestrator
│   ├── simulation-sdk/              # Multi-physics & Fault Injection suite
│   ├── validation-ci/               # Continuous Robotics Validation (CI)
│   ├── fleet-sdk/                   # Fleet management & OTA deployer
│   └── control-plane-api/           # REST / WebSocket API server
├── install.sh                       # Universal curl installer script
└── pyproject.toml                   # Python package configuration
```
