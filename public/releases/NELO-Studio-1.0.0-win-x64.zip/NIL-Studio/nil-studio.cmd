@echo off
"%~dp0nil-studio.bat" %*
