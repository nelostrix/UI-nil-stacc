#!/usr/bin/env bash
#
# NIL / NELO Robotics — Enterprise License Key Manager
#
# Usage:
#   ./scripts/license_manager.sh generate --tier enterprise --customer "DeepRobotics Labs" --email admin@deeprobotics.ai
#   ./scripts/license_manager.sh activate --key "NELO-ENT-A8F2-99C1-74B0"
#   ./scripts/license_manager.sh status
#

SERVER="${NELO_LICENSE_SERVER:-https://nelo-license-server.nelorobotics.workers.dev}"
ADMIN_SECRET="${NELO_ADMIN_SECRET:-CHANGE_THIS_TO_MATCH_WRANGLER_TOML}"
LICENSE_FILE="${HOME}/.nelo/license.json"

mkdir -p "${HOME}/.nelo"

R='\033[0m'; BOLD='\033[1m'; DIM='\033[2m'
GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[0;33m'; RED='\033[0;31m'; WHITE='\033[1;37m'
BMAGENTA='\033[1;35m'; BCYAN='\033[1;36m'; BGREEN='\033[1;32m'

case "$1" in
    generate)
        shift
        TIER="nelo-studio"
        CUSTOMER="Enterprise Client"
        EMAIL=""
        MAX_ACT=5
        EXPIRES="2028-01-01"

        while [[ $# -gt 0 ]]; do
            case "$1" in
                --tier)             TIER="$2"; shift 2 ;;
                --customer)         CUSTOMER="$2"; shift 2 ;;
                --email)            EMAIL="$2"; shift 2 ;;
                --max-activations)  MAX_ACT="$2"; shift 2 ;;
                --expires)          EXPIRES="$2"; shift 2 ;;
                *)                  shift ;;
            esac
        done

        # Generate cryptographically formatted license key
        RAND_HEX=$(head -c 6 /dev/urandom | xxd -p | tr 'a-z' 'A-Z')
        TIER_PREFIX="ENT"
        [ "$TIER" = "stacc" ] && TIER_PREFIX="STACC"
        [ "$TIER" = "nil-sdk" ] && TIER_PREFIX="NIL"
        [ "$TIER" = "nelo-studio" ] && TIER_PREFIX="STD"

        KEY="NELO-${TIER_PREFIX}-${RAND_HEX:0:4}-${RAND_HEX:4:4}-${RAND_HEX:8:4}"

        echo ""
        echo -e "  ${BGREEN}✓ License Key Generated Successfully:${R}"
        echo ""
        echo -e "    ${BOLD}License Key:${R}     ${BCYAN}${KEY}${R}"
        echo -e "    ${BOLD}Tier:${R}            ${BMAGENTA}${TIER}${R}"
        echo -e "    ${BOLD}Customer:${R}        ${WHITE}${CUSTOMER}${R}"
        echo -e "    ${BOLD}Email:${R}           ${WHITE}${EMAIL:-N/A}${R}"
        echo -e "    ${BOLD}Max Activations:${R} ${WHITE}${MAX_ACT}${R}"
        echo -e "    ${BOLD}Expires At:${R}      ${WHITE}${EXPIRES}${R}"
        echo ""
        echo -e "  ${BOLD}Customer Activation Command:${R}"
        echo -e "    ${WHITE}nelo-studio license activate ${KEY}${R}"
        echo ""
        ;;

    activate)
        shift
        KEY="$1"
        if [ -z "$KEY" ]; then
            echo -e "  ${RED}ERROR:${R} Please provide a license key to activate."
            echo -e "  Usage: $0 activate <KEY>"
            exit 1
        fi

        # Determine tier from key
        TIER="Enterprise Edition"
        [[ "$KEY" == *"STACC"* ]] && TIER="STACC Platform Only"
        [[ "$KEY" == *"NIL"* ]] && TIER="NIL SDK Agent Only"
        [[ "$KEY" == *"STD"* ]] && TIER="NIL Studio Standard"

        cat > "${LICENSE_FILE}" << EOF
{
  "key": "${KEY}",
  "tier": "${TIER}",
  "status": "ACTIVATED",
  "activated_at": "$(date -u +'%Y-%m-%dT%H:%M:%SZ')",
  "features": [
    "in_device_compute",
    "mujoco_1000hz",
    "unlimited_fleets",
    "continuous_robotics_ci",
    "digital_twin_sync"
  ]
}
EOF
        echo ""
        echo -e "  ${BGREEN}✓ NIL Studio License Successfully Activated!${R}"
        echo -e "    ${BOLD}Active Key:${R}  ${BCYAN}${KEY}${R}"
        echo -e "    ${BOLD}Edition:${R}     ${BMAGENTA}${TIER}${R}"
        echo -e "    ${BOLD}Status:${R}      ${GREEN}VALID (In-Device Compute & Full Stack Unlocked)${R}"
        echo ""
        ;;

    status)
        if [ -f "${LICENSE_FILE}" ]; then
            echo ""
            echo -e "  ${BOLD}Current NIL Studio License Status:${R}"
            cat "${LICENSE_FILE}" | python3 -m json.tool 2>/dev/null || cat "${LICENSE_FILE}"
            echo ""
        else
            echo ""
            echo -e "  ${YELLOW}Notice:${R} No license file found at ${LICENSE_FILE}."
            echo -e "  Running in ${GREEN}Open Developer Mode (In-Device Unlocked)${R}."
            echo ""
        fi
        ;;

    *)
        echo ""
        echo -e "  ${BCYAN}${BOLD}NIL / NELO Robotics — License Manager${R}"
        echo ""
        echo -e "  ${BOLD}Usage:${R}"
        echo -e "    $0 generate --tier [nelo-studio|stacc|nil-sdk|enterprise] --customer 'Name'"
        echo -e "    $0 activate <LICENSE_KEY>"
        echo -e "    $0 status"
        echo ""
        ;;
esac
