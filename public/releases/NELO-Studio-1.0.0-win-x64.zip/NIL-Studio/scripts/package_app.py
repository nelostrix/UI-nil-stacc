#!/usr/bin/env python3
"""
NIL Studio — Universal Cross-Platform Packaging & Installer Generator
Builds production application distribution packages for Linux, macOS, and Windows.
"""

from __future__ import annotations

import argparse
import os
import shutil
import stat
import subprocess
import sys
import tarfile
import zipfile
from typing import List

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST_DIR = os.path.join(BASE_DIR, "dist")
VERSION = "1.0.0"
APP_NAME = "NIL-Studio"


def ensure_desktop_built():
    """Ensure apps/desktop/app.js is compiled via esbuild."""
    print("📦 [1/4] Building React & Three.js Desktop Application bundle...")
    cmd = ["npm", "run", "build:desktop"]
    try:
        subprocess.check_call(cmd, cwd=BASE_DIR)
        print("  ✓ apps/desktop/app.js built successfully.")
    except Exception as e:
        print(f"  ✗ Warning during build: {e}")


def stage_common_files(stage_dir: str):
    """Copy all core runtime files to staging folder."""
    os.makedirs(stage_dir, exist_ok=True)

    # 1. Apps Desktop
    dest_apps = os.path.join(stage_dir, "apps", "desktop")
    os.makedirs(dest_apps, exist_ok=True)
    shutil.copy(os.path.join(BASE_DIR, "apps", "desktop", "index.html"), dest_apps)
    shutil.copy(os.path.join(BASE_DIR, "apps", "desktop", "app.js"), dest_apps)
    for logo in ["logo.png", "logo.svg"]:
        lp = os.path.join(BASE_DIR, "apps", "desktop", logo)
        if os.path.exists(lp):
            shutil.copy(lp, dest_apps)

    # 2. Packages
    dest_packages = os.path.join(stage_dir, "packages")
    if os.path.exists(os.path.join(BASE_DIR, "packages")):
        shutil.copytree(os.path.join(BASE_DIR, "packages"), dest_packages, dirs_exist_ok=True)

    # 3. Binaries and CLI
    dest_bin = os.path.join(stage_dir, "bin")
    os.makedirs(dest_bin, exist_ok=True)
    shutil.copy(os.path.join(BASE_DIR, "bin", "nelo-studio"), dest_bin)
    # Ensure executable permissions
    os.chmod(os.path.join(dest_bin, "nelo-studio"), stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    # 4. Workspace Templates & Config
    for d in ["workspace", "agents", "scripts"]:
        src_d = os.path.join(BASE_DIR, d)
        if os.path.exists(src_d):
            shutil.copytree(src_d, os.path.join(stage_dir, d), dirs_exist_ok=True)

    # 5. Metadata
    for f in ["README.md", "package.json"]:
        src_f = os.path.join(BASE_DIR, f)
        if os.path.exists(src_f):
            shutil.copy(src_f, stage_dir)


def package_linux():
    """Build Linux distribution packages (.tar.gz and .deb staging)."""
    print("\n🐧 [2/4] Packaging for Linux (x86_64 / aarch64)...")
    stage_dir = os.path.join(DIST_DIR, "linux-stage", "nil-studio")
    if os.path.exists(stage_dir):
        shutil.rmtree(stage_dir)
    stage_common_files(stage_dir)

    # Create Linux Launcher Script
    launcher_path = os.path.join(stage_dir, "nil-studio")
    with open(launcher_path, "w") as f:
        f.write("""#!/usr/bin/env bash
# NIL Studio Desktop Launcher
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="${DIR}/packages/robotics-sdk:${DIR}/packages/digital-twin:${DIR}/packages/ai-sdk:${DIR}/packages/simulation-sdk:${DIR}/packages/validation-ci:${DIR}/packages/fleet-sdk:${DIR}/packages/control-plane-api:${DIR}/packages/compute-engine:${DIR}/packages/licensing-sdk:${PYTHONPATH}"
exec python3 "${DIR}/bin/nelo-studio" studio "$@"
""")
    os.chmod(launcher_path, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    # Create Desktop Entry
    desktop_entry_path = os.path.join(stage_dir, "nil-studio.desktop")
    with open(desktop_entry_path, "w") as f:
        f.write(f"""[Desktop Entry]
Name=NIL Studio
Comment=AI-Native Robotics Engineering Operating System
Exec=/opt/nil-studio/nil-studio %F
Icon=/opt/nil-studio/apps/desktop/logo.png
Terminal=false
Type=Application
Categories=Development;Engineering;Science;Robotics;
MimeType=application/x-rir;application/x-nil;
Keywords=robotics;ai;simulation;mujoco;cad;stacc;
""")

    # Archive as .tar.gz
    out_tar = os.path.join(DIST_DIR, f"NIL-Studio-v{VERSION}-linux-x86_64.tar.gz")
    with tarfile.open(out_tar, "w:gz") as tar:
        tar.add(stage_dir, arcname="nil-studio")
    print(f"  ✓ Created Linux Tarball: {out_tar}")

    # Build Debian Package Structure
    deb_root = os.path.join(DIST_DIR, "deb-stage", f"nil-studio_{VERSION}_amd64")
    if os.path.exists(deb_root):
        shutil.rmtree(deb_root)
    deb_opt = os.path.join(deb_root, "opt", "nil-studio")
    stage_common_files(deb_opt)
    shutil.copy(launcher_path, deb_opt)
    
    # deb /usr/bin symlink
    deb_bin = os.path.join(deb_root, "usr", "bin")
    os.makedirs(deb_bin, exist_ok=True)
    with open(os.path.join(deb_bin, "nil-studio"), "w") as f:
        f.write('#!/bin/sh\nexec /opt/nil-studio/nil-studio "$@"\n')
    os.chmod(os.path.join(deb_bin, "nil-studio"), stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    # deb applications
    deb_apps = os.path.join(deb_root, "usr", "share", "applications")
    os.makedirs(deb_apps, exist_ok=True)
    shutil.copy(desktop_entry_path, deb_apps)

    # deb DEBIAN/control
    deb_control_dir = os.path.join(deb_root, "DEBIAN")
    os.makedirs(deb_control_dir, exist_ok=True)
    with open(os.path.join(deb_control_dir, "control"), "w") as f:
        f.write(f"""Package: nil-studio
Version: {VERSION}
Section: science
Priority: optional
Architecture: amd64
Maintainer: NIL Robotics Team <team@nelostrix.com>
Description: NIL Studio — AI-Native Robotics Engineering OS
 NIL Studio is a next-generation robotics engineering workspace combining
 CADリンク sizing, 1000Hz STACC HAL, MuJoCo physics simulation, and autonomous
 multi-agent AI copilot models.
""")

    print(f"  ✓ Staged Debian Package at {deb_root}")


def package_macos():
    """Build macOS .app bundle and archive."""
    print("\n🍎 [3/4] Packaging for macOS (Apple Silicon & Intel)...")
    stage_dir = os.path.join(DIST_DIR, "macos-stage", "NIL Studio.app")
    if os.path.exists(stage_dir):
        shutil.rmtree(stage_dir)

    macos_dir = os.path.join(stage_dir, "Contents", "MacOS")
    resources_dir = os.path.join(stage_dir, "Contents", "Resources")
    app_root = os.path.join(resources_dir, "app")
    os.makedirs(macos_dir, exist_ok=True)
    os.makedirs(resources_dir, exist_ok=True)

    stage_common_files(app_root)

    # Info.plist
    info_plist = os.path.join(stage_dir, "Contents", "Info.plist")
    with open(info_plist, "w") as f:
        f.write(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>nil-studio-launcher</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>CFBundleIdentifier</key>
    <string>com.nelostrix.nil-studio</string>
    <key>CFBundleName</key>
    <string>NIL Studio</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>{VERSION}</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>LSMinimumSystemVersion</key>
    <string>11.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
""")

    # macOS Native Launcher
    launcher_file = os.path.join(macos_dir, "nil-studio-launcher")
    with open(launcher_file, "w") as f:
        f.write("""#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../Resources/app" && pwd)"
export PYTHONPATH="${DIR}/packages/robotics-sdk:${DIR}/packages/digital-twin:${DIR}/packages/ai-sdk:${DIR}/packages/simulation-sdk:${DIR}/packages/validation-ci:${DIR}/packages/fleet-sdk:${DIR}/packages/control-plane-api:${DIR}/packages/compute-engine:${DIR}/packages/licensing-sdk:${PYTHONPATH}"
exec python3 "${DIR}/bin/nelo-studio" studio "$@"
""")
    os.chmod(launcher_file, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    # Zip .app bundle
    out_zip = os.path.join(DIST_DIR, f"NIL-Studio-v{VERSION}-macos-universal.zip")
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(stage_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, os.path.dirname(stage_dir))
                zipf.write(abs_path, rel_path)

    print(f"  ✓ Created macOS Bundle: {out_zip}")


def package_windows():
    """Build Windows distribution package (.zip and NSIS setup script)."""
    print("\n🪟 [4/4] Packaging for Windows (x64)...")
    stage_dir = os.path.join(DIST_DIR, "windows-stage", "NIL-Studio")
    if os.path.exists(stage_dir):
        shutil.rmtree(stage_dir)
    stage_common_files(stage_dir)

    # Windows Batch & PowerShell Launchers
    bat_launcher = os.path.join(stage_dir, "nil-studio.bat")
    with open(bat_launcher, "w") as f:
        f.write("""@echo off
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%packages\\robotics-sdk;%DIR%packages\\digital-twin;%DIR%packages\\ai-sdk;%DIR%packages\\simulation-sdk;%DIR%packages\\validation-ci;%DIR%packages\\fleet-sdk;%DIR%packages\\control-plane-api;%DIR%packages\\compute-engine;%DIR%packages\\licensing-sdk;%PYTHONPATH%"
python "%DIR%bin\\nelo-studio" studio %*
""")

    cmd_launcher = os.path.join(stage_dir, "nil-studio.cmd")
    with open(cmd_launcher, "w") as f:
        f.write("""@echo off
"%~dp0nil-studio.bat" %*
""")

    # NSIS Installer script template
    nsis_path = os.path.join(stage_dir, "installer.nsi")
    with open(nsis_path, "w") as f:
        f.write(f"""!define APP_NAME "NIL Studio"
!define APP_VERSION "{VERSION}"
!define APP_PUBLISHER "NIL Robotics OS"
!define APP_DIR "$LOCALAPPDATA\\NIL-Studio"

Name "${{APP_NAME}}"
OutFile "NIL-Studio-Setup.exe"
InstallDir "${{APP_DIR}}"

Section "Install"
    SetOutPath "$INSTDIR"
    File /r "*.*"
    CreateShortcut "$DESKTOP\\NIL Studio.lnk" "$INSTDIR\\nil-studio.bat" "" "$INSTDIR\\apps\\desktop\\logo.png"
    CreateShortcut "$SMPROGRAMS\\NIL Studio.lnk" "$INSTDIR\\nil-studio.bat" "" "$INSTDIR\\apps\\desktop\\logo.png"
SectionEnd
""")

    # Zip Windows Bundle
    out_zip = os.path.join(DIST_DIR, f"NIL-Studio-v{VERSION}-windows-x64.zip")
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(stage_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, os.path.dirname(stage_dir))
                zipf.write(abs_path, rel_path)

    print(f"  ✓ Created Windows Package: {out_zip}")


def main():
    parser = argparse.ArgumentParser(description="Package NIL Studio for distribution")
    parser.add_argument("--platform", choices=["all", "linux", "mac", "windows"], default="all", help="Target platform to package")
    args = parser.parse_args()

    os.makedirs(DIST_DIR, exist_ok=True)
    ensure_desktop_built()

    target = args.platform
    if target in ["all", "linux"]:
        package_linux()
    if target in ["all", "mac"]:
        package_macos()
    if target in ["all", "windows"]:
        package_windows()

    print("\n🎉 Cross-Platform Packaging Complete! Output files in:")
    print(f"   {DIST_DIR}\n")


if __name__ == "__main__":
    main()
