#!/usr/bin/env bash
# ==============================================================================
# NIL Studio — Linux Single-Step System Installer
# Supports Ubuntu, Debian, Fedora, Arch, RHEL, CentOS, Linux Mint
# ==============================================================================

set -e

INSTALL_DIR="/opt/nil-studio"
BIN_LINK="/usr/local/bin/nil-studio"
DESKTOP_DIR="/usr/share/applications"
ICON_DIR="/usr/share/icons/hicolor/512x512/apps"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
RESET='\033[0m'

echo ""
echo -e "${CYAN}${BOLD}================================================================${RESET}"
echo -e "${CYAN}${BOLD}   NIL Studio — AI-Native Robotics Engineering OS Installer   ${RESET}"
echo -e "${CYAN}${BOLD}================================================================${RESET}"
echo ""

# 1. Check Root / Sudo privileges for /opt and /usr/local/bin
SUDO=""
if [ "$EUID" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        SUDO="sudo"
        echo -e " ${YELLOW}❯ Installer requires sudo privileges to install to ${INSTALL_DIR}...${RESET}"
    else
        INSTALL_DIR="${HOME}/.local/share/nil-studio"
        BIN_LINK="${HOME}/.local/bin/nil-studio"
        DESKTOP_DIR="${HOME}/.local/share/applications"
        ICON_DIR="${HOME}/.local/share/icons/hicolor/512x512/apps"
        mkdir -p "${HOME}/.local/bin" "${DESKTOP_DIR}" "${ICON_DIR}"
    fi
fi

# 2. Check Python 3
if ! command -v python3 >/dev/null 2>&1; then
    echo -e " ${RED}✗ Python 3 is required. Please install python3 (v3.9+) and re-run.${RESET}"
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e " ${GREEN}✓${RESET} Detected Python ${PY_VER}"

# 3. Copy files to INSTALL_DIR
echo -e " ${CYAN}❯ Staging NIL Studio files in ${INSTALL_DIR}...${RESET}"
$SUDO mkdir -p "${INSTALL_DIR}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
$SUDO cp -r "${SCRIPT_DIR}/apps" "${INSTALL_DIR}/"
$SUDO cp -r "${SCRIPT_DIR}/packages" "${INSTALL_DIR}/"
$SUDO cp -r "${SCRIPT_DIR}/bin" "${INSTALL_DIR}/"
$SUDO cp -r "${SCRIPT_DIR}/workspace" "${INSTALL_DIR}/" 2>/dev/null || true
$SUDO cp -r "${SCRIPT_DIR}/agents" "${INSTALL_DIR}/" 2>/dev/null || true
$SUDO cp -r "${SCRIPT_DIR}/scripts" "${INSTALL_DIR}/" 2>/dev/null || true
$SUDO cp "${SCRIPT_DIR}/package.json" "${INSTALL_DIR}/" 2>/dev/null || true
$SUDO cp "${SCRIPT_DIR}/README.md" "${INSTALL_DIR}/" 2>/dev/null || true

# 4. Create Executable Launcher
$SUDO tee "${INSTALL_DIR}/nil-studio-run" >/dev/null << 'EOF'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="${DIR}/packages/robotics-sdk:${DIR}/packages/digital-twin:${DIR}/packages/ai-sdk:${DIR}/packages/simulation-sdk:${DIR}/packages/validation-ci:${DIR}/packages/fleet-sdk:${DIR}/packages/control-plane-api:${DIR}/packages/compute-engine:${DIR}/packages/licensing-sdk:${PYTHONPATH}"
exec python3 "${DIR}/bin/nelo-studio" studio "$@"
EOF

$SUDO chmod +x "${INSTALL_DIR}/nil-studio-run"
$SUDO chmod +x "${INSTALL_DIR}/bin/nelo-studio"

# 5. Create System Symlink
$SUDO ln -sf "${INSTALL_DIR}/nil-studio-run" "${BIN_LINK}"
echo -e " ${GREEN}✓${RESET} Created CLI command: ${BOLD}${BIN_LINK}${RESET}"

# 6. Install Desktop Launcher & Icon
$SUDO mkdir -p "${DESKTOP_DIR}" "${ICON_DIR}"
if [ -f "${INSTALL_DIR}/apps/desktop/logo.png" ]; then
    $SUDO cp "${INSTALL_DIR}/apps/desktop/logo.png" "${ICON_DIR}/nil-studio.png" 2>/dev/null || true
fi

$SUDO tee "${DESKTOP_DIR}/nil-studio.desktop" >/dev/null << EOF
[Desktop Entry]
Name=NIL Studio
Comment=AI-Native Robotics Engineering Operating System
Exec=${BIN_LINK} %F
Icon=${INSTALL_DIR}/apps/desktop/logo.png
Terminal=false
Type=Application
Categories=Development;Engineering;Science;Robotics;
MimeType=application/x-rir;application/x-nil;
Keywords=robotics;ai;simulation;mujoco;cad;stacc;
StartupWMClass=NIL Studio
EOF

# Update desktop database
command -v update-desktop-database >/dev/null 2>&1 && $SUDO update-desktop-database "${DESKTOP_DIR}" || true

# 7. Hardware Fingerprint & Licensing Inspection
HW_FINGERPRINT=$(python3 -c "
import sys; sys.path.insert(0, '${INSTALL_DIR}/packages/licensing-sdk')
from nelo_license import LicenseManager
print(LicenseManager().get_machine_fingerprint())
" 2>/dev/null || echo "NIL-HW-$(date +%s)")

echo ""
echo -e " ${GREEN}✓${RESET} ${BOLD}Installation Completed Successfully!${RESET}"
echo -e "   • App Directory:       ${CYAN}${INSTALL_DIR}${RESET}"
echo -e "   • CLI Command:         ${WHITE}${BIN_LINK}${RESET}"
echo -e "   • Machine Hardware ID: ${MAGENTA}${HW_FINGERPRINT}${RESET}"
echo ""

# Prompt for License Key if provided as argument or interactive
if [ -n "$1" ]; then
    echo -e " ${CYAN}❯ Activating provided license key: $1...${RESET}"
    python3 "${INSTALL_DIR}/bin/nelo-studio" license activate "$1" || true
else
    echo -e " ${YELLOW}❯ To activate your commercial license key:${RESET}"
    echo -e "   ${WHITE}nil-studio license activate <YOUR-LICENSE-KEY>${RESET}"
fi

echo ""
echo -e " ${BOLD}To launch NIL Studio:${RESET}"
echo -e "   Run '${CYAN}nil-studio${RESET}' or open 'NIL Studio' from your Application menu."
echo ""
