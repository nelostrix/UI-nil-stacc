<#
.SYNOPSIS
    NIL Studio — Windows Application & CLI Installer (PowerShell)
.DESCRIPTION
    Installs NIL Studio into $env:LOCALAPPDATA\NIL-Studio, configures user PATH,
    creates Start Menu & Desktop shortcuts, and sets up license environment.
#>

param (
    [string]$LicenseKey = ""
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "    NIL Studio — Windows Robotics Engineering OS Installer      " -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Check Python
try {
    $pyVersion = python --version 2>&1
    Write-Host " [OK] Detected Python: $pyVersion" -ForegroundColor Green
} catch {
    Write-Host " [ERROR] Python 3 is required. Please install Python 3.9+ from python.org or Microsoft Store." -ForegroundColor Red
    exit 1
}

# 2. Define Installation Directory
$InstallDir = Join-Path $env:LOCALAPPDATA "NIL-Studio"
Write-Host " [*] Installing NIL Studio to $InstallDir..." -ForegroundColor Cyan

if (Test-Path $InstallDir) {
    Remove-Item -Recurse -Force $InstallDir
}
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

$ScriptRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Copy-Item -Recurse -Force "$ScriptRoot\apps" "$InstallDir\apps"
Copy-Item -Recurse -Force "$ScriptRoot\packages" "$InstallDir\packages"
Copy-Item -Recurse -Force "$ScriptRoot\bin" "$InstallDir\bin"
if (Test-Path "$ScriptRoot\workspace") { Copy-Item -Recurse -Force "$ScriptRoot\workspace" "$InstallDir\workspace" }
if (Test-Path "$ScriptRoot\agents") { Copy-Item -Recurse -Force "$ScriptRoot\agents" "$InstallDir\agents" }
if (Test-Path "$ScriptRoot\package.json") { Copy-Item -Force "$ScriptRoot\package.json" "$InstallDir\package.json" }

# 3. Create Windows Launchers
$BatLauncher = "$InstallDir\nil-studio.bat"
$BatContent = @"
@echo off
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%packages\robotics-sdk;%DIR%packages\digital-twin;%DIR%packages\ai-sdk;%DIR%packages\simulation-sdk;%DIR%packages\validation-ci;%DIR%packages\fleet-sdk;%DIR%packages\control-plane-api;%DIR%packages\compute-engine;%DIR%packages\licensing-sdk;%PYTHONPATH%"
python "%DIR%bin\nelo-studio" studio %*
"@
Set-Content -Path $BatLauncher -Value $BatContent

$CmdLauncher = "$InstallDir\nil-studio.cmd"
Set-Content -Path $CmdLauncher -Value "@echo off`r`n`"%~dp0nil-studio.bat`" %*"

# 4. Add to User PATH
$UserPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($UserPath -notlike "*$InstallDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$UserPath;$InstallDir", "User")
    Write-Host " [OK] Added $InstallDir to user PATH environment variable." -ForegroundColor Green
}

# 5. Create Desktop & Start Menu Shortcuts
$WshShell = New-Object -ComObject WScript.Shell

$DesktopPath = [Environment]::GetFolderPath("Desktop")
$DesktopShortcut = $WshShell.CreateShortcut("$DesktopPath\NIL Studio.lnk")
$DesktopShortcut.TargetPath = $BatLauncher
$DesktopShortcut.WorkingDirectory = $InstallDir
$DesktopShortcut.IconLocation = "$InstallDir\apps\desktop\logo.png"
$DesktopShortcut.Description = "NIL Studio — AI-Native Robotics Engineering OS"
$DesktopShortcut.Save()

$ProgramsPath = [Environment]::GetFolderPath("Programs")
$StartMenuShortcut = $WshShell.CreateShortcut("$ProgramsPath\NIL Studio.lnk")
$StartMenuShortcut.TargetPath = $BatLauncher
$StartMenuShortcut.WorkingDirectory = $InstallDir
$StartMenuShortcut.IconLocation = "$InstallDir\apps\desktop\logo.png"
$StartMenuShortcut.Description = "NIL Studio — AI-Native Robotics Engineering OS"
$StartMenuShortcut.Save()

Write-Host " [OK] Created Desktop and Start Menu shortcuts." -ForegroundColor Green

# 6. Retrieve Hardware Fingerprint
try {
    $hwFp = python -c "import sys; sys.path.insert(0, '$($InstallDir -replace '\\', '/')/packages/licensing-sdk'); from nelo_license import LicenseManager; print(LicenseManager().get_machine_fingerprint())" 2>$null
    Write-Host " [OK] Host Machine Hardware Fingerprint: $hwFp" -ForegroundColor Magenta
} catch {}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  NIL Studio Installation Completed Successfully on Windows!     " -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  Directory: $InstallDir"
Write-Host "  CLI:       nil-studio"
Write-Host ""

if ($LicenseKey) {
    Write-Host " [*] Activating license key: $LicenseKey..." -ForegroundColor Cyan
    python "$InstallDir\bin\nelo-studio" license activate "$LicenseKey"
} else {
    Write-Host " [i] To activate commercial license: nil-studio license activate <KEY>" -ForegroundColor Yellow
}

Write-Host ""
Write-Host " Launch NIL Studio by double clicking 'NIL Studio' on your Desktop or typing 'nil-studio' in PowerShell / Command Prompt."
Write-Host ""
