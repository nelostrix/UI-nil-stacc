@echo off
REM ============================================================================
REM NIL Studio — Windows Batch Installer Wrapper
REM Launches PowerShell installer with execution policy bypass
REM ============================================================================

echo.
echo Launching NIL Studio Windows Setup...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_windows.ps1" %*
pause
