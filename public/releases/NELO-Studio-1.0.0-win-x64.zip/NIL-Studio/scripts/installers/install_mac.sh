#!/usr/bin/env bash
# ==============================================================================
# NIL Studio — macOS Single-Step Application & CLI Installer
# Supports macOS Monterey, Ventura, Sonoma, Sequoia (Apple Silicon & Intel)
# ==============================================================================

set -e

APP_DIR="/Applications/NIL Studio.app"
BIN_LINK="/usr/local/bin/nil-studio"
USER_BIN="${HOME}/.local/bin/nil-studio"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
RESET='\033[0m'

echo ""
echo -e "${CYAN}${BOLD}================================================================${RESET}"
echo -e "${CYAN}${BOLD}     NIL Studio — macOS Robotics Engineering OS Installer     ${RESET}"
echo -e "${CYAN}${BOLD}================================================================${RESET}"
echo ""

# 1. Check Python 3
if ! command -v python3 >/dev/null 2>&1; then
    echo -e " ${RED}✗ Python 3 is required. Please install via Homebrew ('brew install python') or python.org.${RESET}"
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e " ${GREEN}✓${RESET} Detected Python ${PY_VER}"

# 2. Build .app Bundle Structure
echo -e " ${CYAN}❯ Creating macOS Application at ${APP_DIR}...${RESET}"
mkdir -p "${APP_DIR}/Contents/MacOS"
mkdir -p "${APP_DIR}/Contents/Resources/app"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TARGET_APP="${APP_DIR}/Contents/Resources/app"

cp -r "${SCRIPT_DIR}/apps" "${TARGET_APP}/"
cp -r "${SCRIPT_DIR}/packages" "${TARGET_APP}/"
cp -r "${SCRIPT_DIR}/bin" "${TARGET_APP}/"
cp -r "${SCRIPT_DIR}/workspace" "${TARGET_APP}/" 2>/dev/null || true
cp -r "${SCRIPT_DIR}/agents" "${TARGET_APP}/" 2>/dev/null || true
cp -r "${SCRIPT_DIR}/scripts" "${TARGET_APP}/" 2>/dev/null || true
cp "${SCRIPT_DIR}/package.json" "${TARGET_APP}/" 2>/dev/null || true
cp "${SCRIPT_DIR}/README.md" "${TARGET_APP}/" 2>/dev/null || true

# 3. Create Info.plist
cat > "${APP_DIR}/Contents/Info.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>nil-studio-launcher</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>CFBundleIdentifier</key>
    <string>com.nelostrix.nil-studio</string>
    <key>CFBundleName</key>
    <string>NIL Studio</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0.0</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>LSMinimumSystemVersion</key>
    <string>11.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
EOF

# 4. Create macOS Native Executable Launcher
cat > "${APP_DIR}/Contents/MacOS/nil-studio-launcher" << 'EOF'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../Resources/app" && pwd)"
export PYTHONPATH="${DIR}/packages/robotics-sdk:${DIR}/packages/digital-twin:${DIR}/packages/ai-sdk:${DIR}/packages/simulation-sdk:${DIR}/packages/validation-ci:${DIR}/packages/fleet-sdk:${DIR}/packages/control-plane-api:${DIR}/packages/compute-engine:${DIR}/packages/licensing-sdk:${PYTHONPATH}"
exec python3 "${DIR}/bin/nelo-studio" studio "$@"
EOF

chmod +x "${APP_DIR}/Contents/MacOS/nil-studio-launcher"
chmod +x "${TARGET_APP}/bin/nelo-studio"

# 5. Link CLI Command
if [ -w "/usr/local/bin" ]; then
    ln -sf "${APP_DIR}/Contents/MacOS/nil-studio-launcher" "${BIN_LINK}"
    echo -e " ${GREEN}✓${RESET} Linked CLI command: ${BOLD}${BIN_LINK}${RESET}"
else
    mkdir -p "${HOME}/.local/bin"
    ln -sf "${APP_DIR}/Contents/MacOS/nil-studio-launcher" "${USER_BIN}"
    echo -e " ${GREEN}✓${RESET} Linked CLI command: ${BOLD}${USER_BIN}${RESET}"
fi

# 6. Hardware Fingerprint
HW_FINGERPRINT=$(python3 -c "
import sys; sys.path.insert(0, '${TARGET_APP}/packages/licensing-sdk')
from nelo_license import LicenseManager
print(LicenseManager().get_machine_fingerprint())
" 2>/dev/null || echo "NIL-HW-MAC")

echo ""
echo -e " ${GREEN}✓${RESET} ${BOLD}macOS Installation Complete!${RESET}"
echo -e "   • Application:         ${CYAN}${APP_DIR}${RESET}"
echo -e "   • Machine Hardware ID: ${MAGENTA}${HW_FINGERPRINT}${RESET}"
echo ""

if [ -n "$1" ]; then
    echo -e " ${CYAN}❯ Activating license key: $1...${RESET}"
    python3 "${TARGET_APP}/bin/nelo-studio" license activate "$1" || true
else
    echo -e " ${YELLOW}❯ To activate license:${RESET} 'nil-studio license activate <KEY>'"
fi

echo ""
echo -e " ${BOLD}To launch:${RESET} Open 'NIL Studio' from Spotlight / Launchpad or type '${CYAN}nil-studio${RESET}' in Terminal."
echo ""
