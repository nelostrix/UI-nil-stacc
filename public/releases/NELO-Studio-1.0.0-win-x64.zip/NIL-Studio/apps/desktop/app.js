var NeloApp = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var App_exports = {};
  __export(App_exports, {
    App: () => App,
    default: () => App_default
  });
  const ReactInstance = (typeof window !== "undefined" ? window.React : null) || globalThis.React || {};
  const { useState, useEffect, useRef, useMemo, useCallback } = ReactInstance;
  const Icons = {
    Explorer: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" })),
    Robotics: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "3", y: "11", width: "18", height: "10", rx: "2" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "5", r: "2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 7v4" }), /* @__PURE__ */ window.React.createElement("line", { x1: "8", y1: "16", x2: "8.01", y2: "16" }), /* @__PURE__ */ window.React.createElement("line", { x1: "16", y1: "16", x2: "16.01", y2: "16" })),
    Hardware: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "2" }), /* @__PURE__ */ window.React.createElement("rect", { x: "9", y: "9", width: "6", height: "6" }), /* @__PURE__ */ window.React.createElement("line", { x1: "9", y1: "1", x2: "9", y2: "4" }), /* @__PURE__ */ window.React.createElement("line", { x1: "15", y1: "1", x2: "15", y2: "4" }), /* @__PURE__ */ window.React.createElement("line", { x1: "9", y1: "20", x2: "9", y2: "23" }), /* @__PURE__ */ window.React.createElement("line", { x1: "15", y1: "20", x2: "15", y2: "23" }), /* @__PURE__ */ window.React.createElement("line", { x1: "20", y1: "9", x2: "23", y2: "9" }), /* @__PURE__ */ window.React.createElement("line", { x1: "20", y1: "14", x2: "23", y2: "14" }), /* @__PURE__ */ window.React.createElement("line", { x1: "1", y1: "9", x2: "4", y2: "9" }), /* @__PURE__ */ window.React.createElement("line", { x1: "1", y1: "14", x2: "4", y2: "14" })),
    Brain: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-4.54z" }), /* @__PURE__ */ window.React.createElement("path", { d: "M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-4.54z" })),
    Telemetry: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "22 12 18 12 15 21 9 3 6 12 2 12" })),
    Twin: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polygon", { points: "12 2 2 7 12 12 22 7 12 2" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "2 17 12 22 22 17" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "2 12 12 17 22 12" })),
    Play: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "currentColor" }, /* @__PURE__ */ window.React.createElement("polygon", { points: "5 3 19 12 5 21 5 3" })),
    Stop: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "currentColor" }, /* @__PURE__ */ window.React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "2" })),
    Settings: ({ size = 16, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "3" }), /* @__PURE__ */ window.React.createElement("path", { d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" })),
    Help: ({ size = 16, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "10" }), /* @__PURE__ */ window.React.createElement("path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })),
    User: ({ size = 16, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "7", r: "4" })),
    Camera: ({ size = 15, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "13", r: "4" })),
    Grid: ({ size = 15, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "3", y: "3", width: "7", height: "7" }), /* @__PURE__ */ window.React.createElement("rect", { x: "14", y: "3", width: "7", height: "7" }), /* @__PURE__ */ window.React.createElement("rect", { x: "14", y: "14", width: "7", height: "7" }), /* @__PURE__ */ window.React.createElement("rect", { x: "3", y: "14", width: "7", height: "7" })),
    Download: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "7 10 12 15 17 10" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "15", x2: "12", y2: "3" })),
    Zap: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polygon", { points: "13 2 3 14 12 14 11 22 21 10 12 10 13 2" })),
    Database: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("ellipse", { cx: "12", cy: "5", rx: "9", ry: "3" }), /* @__PURE__ */ window.React.createElement("path", { d: "M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" }), /* @__PURE__ */ window.React.createElement("path", { d: "M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" })),
    Code: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "16 18 22 12 16 6" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "8 6 2 12 8 18" })),
    File: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "13 2 13 9 20 9" })),
    Activity: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "22 12 18 12 15 21 9 3 6 12 2 12" })),
    Network: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "5", r: "3" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "6", cy: "19", r: "3" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "18", cy: "19", r: "3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "8.59", y1: "17.06", x2: "10.41", y2: "6.94" }), /* @__PURE__ */ window.React.createElement("line", { x1: "15.41", y1: "6.94", x2: "17.25", y2: "17.06" })),
    Send: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("line", { x1: "22", y1: "2", x2: "11", y2: "13" }), /* @__PURE__ */ window.React.createElement("polygon", { points: "22 2 15 22 11 13 2 9 22 2" })),
    Bot: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "3", y: "11", width: "18", height: "10", rx: "2" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "5", r: "2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 7v4" }), /* @__PURE__ */ window.React.createElement("line", { x1: "8", y1: "16", x2: "8.01", y2: "16" }), /* @__PURE__ */ window.React.createElement("line", { x1: "16", y1: "16", x2: "16.01", y2: "16" })),
    Sparkles: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z" })),
    Copy: ({ size = 13, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2", ry: "2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })),
    Check: ({ size = 13, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "20 6 9 17 4 12" })),
    ChevronRight: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "9 18 15 12 9 6" })),
    ChevronLeft: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "15 18 9 12 15 6" })),
    ChevronDown: ({ size = 12, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "6 9 12 15 18 9" })),
    ChevronUp: ({ size = 12, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "18 15 12 9 6 15" })),
    Close: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }), /* @__PURE__ */ window.React.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })),
    Search: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "11", cy: "11", r: "8" }), /* @__PURE__ */ window.React.createElement("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" })),
    BookOpen: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" }), /* @__PURE__ */ window.React.createElement("path", { d: "M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" })),
    Sun: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "5" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "1", x2: "12", y2: "3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "21", x2: "12", y2: "23" }), /* @__PURE__ */ window.React.createElement("line", { x1: "4.22", y1: "4.22", x2: "5.64", y2: "5.64" }), /* @__PURE__ */ window.React.createElement("line", { x1: "18.36", y1: "18.36", x2: "19.78", y2: "19.78" }), /* @__PURE__ */ window.React.createElement("line", { x1: "1", y1: "12", x2: "3", y2: "12" }), /* @__PURE__ */ window.React.createElement("line", { x1: "21", y1: "12", x2: "23", y2: "12" }), /* @__PURE__ */ window.React.createElement("line", { x1: "4.22", y1: "19.78", x2: "5.64", y2: "18.36" }), /* @__PURE__ */ window.React.createElement("line", { x1: "18.36", y1: "5.64", x2: "19.78", y2: "4.22" })),
    Moon: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" })),
    Factory: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4H2z" }), /* @__PURE__ */ window.React.createElement("path", { d: "M17 18h1" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 18h1" }), /* @__PURE__ */ window.React.createElement("path", { d: "M7 18h1" })),
    Bulb: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M9 18h6" }), /* @__PURE__ */ window.React.createElement("path", { d: "M10 22h4" }), /* @__PURE__ */ window.React.createElement("path", { d: "M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5.76.76 1.23 1.52 1.41 2.5" })),
    SunMedium: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "4" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 3v1" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 20v1" }), /* @__PURE__ */ window.React.createElement("path", { d: "M3 12h1" }), /* @__PURE__ */ window.React.createElement("path", { d: "M20 12h1" }), /* @__PURE__ */ window.React.createElement("path", { d: "m18.364 5.636-.707.707" }), /* @__PURE__ */ window.React.createElement("path", { d: "m6.343 17.657-.707.707" }), /* @__PURE__ */ window.React.createElement("path", { d: "m5.636 5.636.707.707" }), /* @__PURE__ */ window.React.createElement("path", { d: "m17.657 17.657.707.707" })),
    Trash: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "3 6 5 6 21 6" }), /* @__PURE__ */ window.React.createElement("path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" })),
    Refresh: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polyline", { points: "23 4 23 10 17 10" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "1 20 1 14 7 14" }), /* @__PURE__ */ window.React.createElement("path", { d: "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" })),
    Pencil: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" })),
    Wand: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "m15 4-2 2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m15 9-2-2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m19 8-2 2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m19 13-2-2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M2 22 12 12" })),
    Target: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "10" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "6" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "2" })),
    Sliders: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("line", { x1: "4", y1: "21", x2: "4", y2: "14" }), /* @__PURE__ */ window.React.createElement("line", { x1: "4", y1: "10", x2: "4", y2: "3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "21", x2: "12", y2: "12" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "8", x2: "12", y2: "3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "20", y1: "21", x2: "20", y2: "16" }), /* @__PURE__ */ window.React.createElement("line", { x1: "20", y1: "12", x2: "20", y2: "3" }), /* @__PURE__ */ window.React.createElement("line", { x1: "1", y1: "14", x2: "7", y2: "14" }), /* @__PURE__ */ window.React.createElement("line", { x1: "9", y1: "8", x2: "15", y2: "8" }), /* @__PURE__ */ window.React.createElement("line", { x1: "17", y1: "16", x2: "23", y2: "16" })),
    Bug: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { width: "8", height: "14", x: "8", y: "6", rx: "4" }), /* @__PURE__ */ window.React.createElement("path", { d: "m19 7-3 2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m5 7 3 2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m19 19-3-2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m5 19 3-2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M20 13h-4" }), /* @__PURE__ */ window.React.createElement("path", { d: "M4 13h4" }), /* @__PURE__ */ window.React.createElement("path", { d: "m10 4 1 2" }), /* @__PURE__ */ window.React.createElement("path", { d: "m14 4-1 2" })),
    Rocket: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" }), /* @__PURE__ */ window.React.createElement("path", { d: "m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" }), /* @__PURE__ */ window.React.createElement("path", { d: "M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" })),
    Gamepad: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("line", { x1: "6", y1: "12", x2: "10", y2: "12" }), /* @__PURE__ */ window.React.createElement("line", { x1: "8", y1: "10", x2: "8", y2: "14" }), /* @__PURE__ */ window.React.createElement("line", { x1: "15", y1: "13", x2: "15.01", y2: "13" }), /* @__PURE__ */ window.React.createElement("line", { x1: "18", y1: "11", x2: "18.01", y2: "11" }), /* @__PURE__ */ window.React.createElement("rect", { x: "2", y: "6", width: "20", height: "12", rx: "2" })),
    Eye: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "3" })),
    Flask: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M10 2v7.31L4.15 19.34A2 2 0 0 0 5.85 22h12.3a2 2 0 0 0 1.7-2.66L14 9.31V2" }), /* @__PURE__ */ window.React.createElement("path", { d: "M8.5 2h7" }), /* @__PURE__ */ window.React.createElement("path", { d: "M14 9.3 17 14H7l3-4.7" })),
    Pin: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "10", r: "3" })),
    Server: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("rect", { x: "2", y: "2", width: "20", height: "8", rx: "2", ry: "2" }), /* @__PURE__ */ window.React.createElement("rect", { x: "2", y: "14", width: "20", height: "8", rx: "2", ry: "2" }), /* @__PURE__ */ window.React.createElement("line", { x1: "6", y1: "6", x2: "6.01", y2: "6" }), /* @__PURE__ */ window.React.createElement("line", { x1: "6", y1: "18", x2: "6.01", y2: "18" })),
    Globe: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "12", cy: "12", r: "10" }), /* @__PURE__ */ window.React.createElement("line", { x1: "2", y1: "12", x2: "22", y2: "12" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" })),
    Palette: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "13.5", cy: "6.5", r: ".5", fill: "currentColor" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "17.5", cy: "10.5", r: ".5", fill: "currentColor" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "8.5", cy: "7.5", r: ".5", fill: "currentColor" }), /* @__PURE__ */ window.React.createElement("circle", { cx: "6.5", cy: "12.5", r: ".5", fill: "currentColor" }), /* @__PURE__ */ window.React.createElement("path", { d: "M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" })),
    MessageSquare: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" })),
    Cad: ({ size = 18, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "3.27 6.96 12 12.01 20.73 6.96" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "22.08", x2: "12", y2: "12" })),
    Layers: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("polygon", { points: "12 2 2 7 12 12 22 7 12 2" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "2 17 12 22 22 17" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "2 12 12 17 22 12" })),
    ShieldCheck: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("path", { d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "9 12 11 14 15 10" })),
    Key: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("circle", { cx: "7.5", cy: "15.5", r: "5.5" }), /* @__PURE__ */ window.React.createElement("path", { d: "m21 2-9.6 9.6" }), /* @__PURE__ */ window.React.createElement("path", { d: "m15.5 7.5 3 3L22 7l-3-3" })),
    Package: ({ size = 14, color = "currentColor" }) => /* @__PURE__ */ window.React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: color, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, /* @__PURE__ */ window.React.createElement("line", { x1: "16.5", y1: "9.4", x2: "7.5", y2: "4.21" }), /* @__PURE__ */ window.React.createElement("path", { d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }), /* @__PURE__ */ window.React.createElement("polyline", { points: "3.27 6.96 12 12.01 20.73 6.96" }), /* @__PURE__ */ window.React.createElement("line", { x1: "12", y1: "22.08", x2: "12", y2: "12" }))
  };
  const fileDatabase = {
    "main_stacc.py": `import numpy as np
import stacc.core as stacc
import stacc.hal as hal
from nil.core import Agent, PersistentMemory

def initialize_robot(model_path="workspace/models/nelostrix_arm_6dof.rir"):
    # Initialize STACC 1000Hz Zero-Copy Shared Memory Bus
    robot = stacc.Robot.from_rir(model_path)
    hal_bus = hal.SharedMemoryBus(name="stacc_main", frequency=1000)
    
    # Initialize NIL Cognitive Agent with 7-Tier Memory Store
    memory = PersistentMemory("./agent_store")
    agent = Agent(domain="robotics_engineering", memory=memory)
    return robot, hal_bus, agent

def move_joint(robot, joint_index, target_pos, max_effort=45.0):
    robot.set_joint_target(joint_index, target_pos)
    robot.apply_impedance_control(kp=245.0, kd=35.0, max_torque=max_effort)`,
    "robot.rir": `{
  "rir_version": "1.4.0",
  "robot_id": "NELOSTRIX-ARM-6DOF",
  "dof": 6,
  "max_payload_kg": 12.5,
  "joints": [
    { "name": "base_yaw", "type": "revolute", "axis": [0, 0, 1], "range_rad": [-3.14, 3.14], "max_torque_nm": 85.0 },
    { "name": "shoulder_pitch", "type": "revolute", "axis": [0, 1, 0], "range_rad": [-2.09, 2.09], "max_torque_nm": 85.0 },
    { "name": "elbow_pitch", "type": "revolute", "axis": [0, 1, 0], "range_rad": [-2.61, 2.61], "max_torque_nm": 45.0 },
    { "name": "wrist_roll", "type": "revolute", "axis": [1, 0, 0], "range_rad": [-3.14, 3.14], "max_torque_nm": 25.0 },
    { "name": "wrist_pitch", "type": "revolute", "axis": [0, 1, 0], "range_rad": [-1.91, 1.91], "max_torque_nm": 25.0 },
    { "name": "wrist_yaw", "type": "revolute", "axis": [0, 0, 1], "range_rad": [-3.14, 3.14], "max_torque_nm": 15.0 }
  ],
  "kinematics": { "flange_offset": [0, 0, 0.12] },
  "dynamics": { "gravity_compensation": true, "coriolis_matrix": true }
}`,
    "config.json": `{
  "system": {
    "engine": "STACC-MuJoCo-1000Hz",
    "cognition": "NIL-7Tier-Memory",
    "ipc_mode": "zero_copy_shared_memory",
    "safety_limits": {
      "max_joint_velocity_rad_s": 4.5,
      "emergency_stop_decel_rad_s2": 45.0,
      "thermal_cutoff_celsius": 85.0
    }
  },
  "control": {
    "frequency_hz": 1000,
    "default_kp": 245.0,
    "default_kd": 35.0
  }
}`,
    "evolution_policy.py": `from nil.evolution.gradient_engine import GradientEngine
from nil.cognition.runner import RACEngine

def run_self_evolution_cycle(agent):
    # Execute Causal Trace Analysis & Textual Gradient Descent
    engine = GradientEngine(learning_rate=0.08)
    report = agent.pipeline.run("robotics_engineering")
    
    if report.has_skill_candidate:
        agent.memory.procedural.register(report.new_skill)
    return report.summary()`
  };
  const App = () => {
    const [theme, setTheme] = useState("light");
    const [robotColorPreset, setRobotColorPreset] = useState("orange");
    const [lightingBrightness, setLightingBrightness] = useState("bright");
    const [wireframeMode, setWireframeMode] = useState(false);
    const [showAxes, setShowAxes] = useState(true);
    const themeConfig = {
      light: {
        name: "Clean Lab / CAD",
        icon: "Sun",
        bg: "#f1f5f9",
        panelBg: "#ffffff",
        cardBg: "#f8fafc",
        sidebarBg: "#e2e8f0",
        topBarBg: "#ffffff",
        border: "rgba(0, 0, 0, 0.08)",
        borderStrong: "rgba(0, 0, 0, 0.16)",
        text: "#0f172a",
        textMuted: "#475569",
        textSubtle: "#64748b",
        accent: "#0284c7",
        accentGlow: "rgba(2, 132, 199, 0.2)",
        secondary: "#ea580c",
        success: "#16a34a",
        sceneBg: 15857145,
        tableColor: 14870768,
        gridColor: 9741240,
        gridCenter: 165063,
        editor: {
          bg: "#ffffff",
          gutterBg: "#f8fafc",
          gutterText: "#94a3b8",
          activeGutterText: "#0284c7",
          activeLineBg: "rgba(2, 132, 199, 0.05)",
          cursor: "#0284c7",
          selectionBg: "rgba(2, 132, 199, 0.2)",
          keyword: "#cf222e",
          string: "#0a3069",
          number: "#0550ae",
          comment: "#6e7781",
          function: "#8250df",
          property: "#116329",
          operator: "#cf222e",
          punctuation: "#24292f"
        }
      },
      dark: {
        name: "Onyx Dark",
        icon: "Moon",
        bg: "#08080c",
        panelBg: "#0c0c12",
        cardBg: "#14141c",
        sidebarBg: "#0c0c12",
        topBarBg: "#0c0c12",
        border: "rgba(255, 255, 255, 0.08)",
        borderStrong: "rgba(255, 255, 255, 0.16)",
        text: "#eeeef2",
        textMuted: "#9090a8",
        textSubtle: "#5a5a70",
        accent: "#00d4ff",
        accentGlow: "rgba(0, 212, 255, 0.2)",
        secondary: "#ff3d00",
        success: "#c8ff00",
        sceneBg: 592658,
        tableColor: 1316900,
        gridColor: 1975350,
        gridCenter: 54527,
        editor: {
          bg: "#090a10",
          gutterBg: "#06070a",
          gutterText: "#475569",
          activeGutterText: "#00d4ff",
          activeLineBg: "rgba(0, 212, 255, 0.06)",
          cursor: "#00d4ff",
          selectionBg: "rgba(0, 212, 255, 0.25)",
          keyword: "#ff7b72",
          string: "#a5d6ff",
          number: "#79c0ff",
          comment: "#8b949e",
          function: "#d2a8ff",
          property: "#7ee787",
          operator: "#ff7b72",
          punctuation: "#c9d1d9"
        }
      },
      industrial: {
        name: "Industrial Robotics",
        icon: "Factory",
        bg: "#161820",
        panelBg: "#1f232e",
        cardBg: "#282d3b",
        sidebarBg: "#191c25",
        topBarBg: "#1f232e",
        border: "rgba(255, 255, 255, 0.1)",
        borderStrong: "rgba(255, 255, 255, 0.2)",
        text: "#f1f3f7",
        textMuted: "#a0a7b8",
        textSubtle: "#636c80",
        accent: "#f59e0b",
        accentGlow: "rgba(245, 158, 11, 0.2)",
        secondary: "#ea580c",
        success: "#10b981",
        sceneBg: 1579556,
        tableColor: 2369589,
        gridColor: 3554382,
        gridCenter: 16096779,
        editor: {
          bg: "#181b24",
          gutterBg: "#13151c",
          gutterText: "#636c80",
          activeGutterText: "#f59e0b",
          activeLineBg: "rgba(245, 158, 11, 0.08)",
          cursor: "#f59e0b",
          selectionBg: "rgba(245, 158, 11, 0.25)",
          keyword: "#f59e0b",
          string: "#34d399",
          number: "#fbbf24",
          comment: "#9ca3af",
          function: "#38bdf8",
          property: "#f472b6",
          operator: "#fb923c",
          punctuation: "#e5e7eb"
        }
      },
      cyberpunk: {
        name: "Cyberpunk Neon",
        icon: "Zap",
        bg: "#090614",
        panelBg: "#120d26",
        cardBg: "#1b1338",
        sidebarBg: "#0f0a20",
        topBarBg: "#120d26",
        border: "rgba(236, 72, 153, 0.22)",
        borderStrong: "rgba(0, 240, 255, 0.35)",
        text: "#fdf4ff",
        textMuted: "#c084fc",
        textSubtle: "#818cf8",
        accent: "#00f0ff",
        accentGlow: "rgba(0, 240, 255, 0.3)",
        secondary: "#f43f5e",
        success: "#39ff14",
        sceneBg: 788253,
        tableColor: 1577013,
        gridColor: 3284574,
        gridCenter: 61695,
        editor: {
          bg: "#0b0717",
          gutterBg: "#070410",
          gutterText: "#6b5b95",
          activeGutterText: "#00f0ff",
          activeLineBg: "rgba(255, 0, 128, 0.12)",
          cursor: "#00f0ff",
          selectionBg: "rgba(255, 0, 128, 0.3)",
          keyword: "#ff007f",
          string: "#00f0ff",
          number: "#ffff00",
          comment: "#8b7ca8",
          function: "#00ff88",
          property: "#ff00aa",
          operator: "#00f0ff",
          punctuation: "#f0abfc"
        }
      }
    };
    const curTheme = themeConfig[theme] || themeConfig.light;
    const [activeActivity, setActiveActivity] = useState("explorer");
    const [activeEditorTab, setActiveEditorTab] = useState("main_stacc.py");
    const [activeDockTab, setActiveDockTab] = useState("terminal");
    const [codeFiles, setCodeFiles] = useState(fileDatabase);
    const [isRunning, setIsRunning] = useState(true);
    const [jointAngles, setJointAngles] = useState([0, 0.25, -0.45, 0, 0.2, 0]);
    const [j1Torque, setJ1Torque] = useState(14.2);
    const [j2Torque, setJ2Torque] = useState(8.7);
    const [cameraPreset, setCameraPreset] = useState("perspective");
    const [showGrid, setShowGrid] = useState(true);
    const [terminalInput, setTerminalInput] = useState("");
    const [terminalCwd, setTerminalCwd] = useState("~");
    const [cmdHistory, setCmdHistory] = useState([]);
    const [historyIndex, setHistoryIndex] = useState(-1);
    const [execLogs, setExecLogs] = useState([
      "[INFO] NeloStrix NIL-STACC Unified In-Device Linux Kernel online.",
      "[INFO] Direct Linux Shell & Subprocess Execution Engine Active.",
      "[INFO] STACC SharedMemoryBus 'stacc_main' bound @ 1000Hz (0.02ms latency).",
      "[INFO] NIL Cognitive Agent connected (domain: robotics_engineering, model: nil-nemotron-120b).",
      "[INFO] Loaded RIR model: workspace/models/nelostrix_arm_6dof.rir (6-DOF Manipulator).",
      "[INFO] Type 'help', 'nil status', 'stacc hal', 'ls', 'pwd', 'uname -a' or any Linux shell command."
    ]);
    const terminalBottomRef = useRef(null);
    const terminalContainerRef = useRef(null);
    const terminalInputRef = useRef(null);
    const [openMenu, setOpenMenu] = useState(null);
    const [showKernelModal, setShowKernelModal] = useState(false);
    const [notification, setNotification] = useState(null);
    const showToast = (msg) => {
      setNotification(msg);
      setTimeout(() => setNotification(null), 3e3);
    };
    const executeTerminalCmd = async (cmd) => {
      setActiveActivity("explorer");
      setActiveDockTab("terminal");
      setExecLogs((prev) => [...prev, `nelostrix@nil-stacc-kernel:${terminalCwd}$ ${cmd}`]);
      try {
        const res = await fetch("/api/terminal/exec", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ command: cmd })
        });
        const data = await res.json();
        if (data.cwd) setTerminalCwd(data.cwd);
        if (data.output && Array.isArray(data.output)) {
          if (data.output[0] === "__CLEAR__") setExecLogs([]);
          else setExecLogs((prev) => [...prev, ...data.output]);
        }
      } catch (e) {
        setExecLogs((prev) => [...prev, `[KERNEL] Executed '${cmd}'`]);
      }
    };
    useEffect(() => {
      const handleGlobalClick = (e) => {
        const target = e.target;
        if (!target.closest(".menu-dropdown-container") && !target.closest(".menu-trigger-btn")) {
          setOpenMenu(null);
        }
      };
      window.addEventListener("click", handleGlobalClick);
      return () => window.removeEventListener("click", handleGlobalClick);
    }, []);
    const [evolutionConfig, setEvolutionConfig] = useState({
      strategy: "continuous",
      gradientRate: 0.08,
      skillConfidence: 0.92,
      evalSampleSize: 50,
      cognitiveMode: "exploit"
    });
    const [cycleCount, setCycleCount] = useState(42);
    const [successRate, setSuccessRate] = useState(94.2);
    const [semanticLoss, setSemanticLoss] = useState(0.024);
    const [driftScore, setDriftScore] = useState(0.012);
    const [learnedSkills, setLearnedSkills] = useState(58);
    const [sessionTimer, setSessionTimer] = useState("04:12:45");
    const [isEvolving, setIsEvolving] = useState(false);
    const [evolutionStageLogs, setEvolutionStageLogs] = useState([
      "[STAGE 1: ANALYZE] Causal trace analysis identified 4 optimal convergence pathways.",
      "[STAGE 2: EXTRACT SKILLS] Synthesized 'stacc_impedance_convergence' (Confidence: 96.4%).",
      "[STAGE 3: TEXTUAL GRADIENT] LLM Critique generated prompt delta \u0394w (loss: 0.024).",
      "[STAGE 4: EVALUATE] Replay benchmark against 50 historical traces (p < 0.001, PASS).",
      "[STAGE 5: WORLD MODEL] POMDP transition matrix updated for 6-DOF torque limits.",
      "[STAGE 6: DRIFT CHECK] 6/6 performance signals nominal (Drift score: 0.012 - NO DRIFT)."
    ]);
    const [cartesianTarget, setCartesianTarget] = useState({ x: 0.62, y: -0.15, z: 0.48, roll: 0, pitch: 45, yaw: 90 });
    const [ikStatus, setIkStatus] = useState("CONVERGED (\u0394x: 0.0012m)");
    const handleSolveIK = () => {
      const nx = cartesianTarget.x;
      const ny = cartesianTarget.y;
      const nz = cartesianTarget.z;
      const j1 = Math.atan2(ny, nx);
      const r = Math.sqrt(nx * nx + ny * ny);
      const d = Math.sqrt(r * r + nz * nz);
      const j2 = Math.asin(Math.min(1, Math.max(-1, nz / Math.max(0.01, d)))) * 0.8;
      const j3 = -Math.acos(Math.min(1, Math.max(-1, (d * d - 0.5) / 0.5))) * 0.5;
      const newAngles = [
        parseFloat(j1.toFixed(2)),
        parseFloat(j2.toFixed(2)),
        parseFloat(j3.toFixed(2)),
        parseFloat((cartesianTarget.roll * Math.PI / 180).toFixed(2)),
        parseFloat((cartesianTarget.pitch * Math.PI / 180).toFixed(2)),
        parseFloat((cartesianTarget.yaw * Math.PI / 180).toFixed(2))
      ];
      setJointAngles(newAngles);
      setIkStatus("CONVERGED (DLS IK Solved in 0.4ms)");
      showToast("IK Solver: Updated 6-DOF joint angles");
    };
    const handleRunTrajectoryPreset = (type) => {
      if (type === "home") {
        setJointAngles([0, 0, 0, 0, 0, 0]);
        showToast("Robotics: Reset to Zero / Calibration Home Pose");
      } else if (type === "pick_place") {
        setJointAngles([0.78, 0.45, -0.65, 0, 0.35, 0.78]);
        showToast("Robotics: Executed Pick & Place Reach Trajectory");
      } else if (type === "inspect") {
        setJointAngles([-0.52, 0.6, -0.3, 0.2, 0.5, -0.4]);
        showToast("Robotics: Executed Workcell Inspection Trajectory");
      } else if (type === "wave") {
        setJointAngles([0, 0.3, -0.2, 0.75, 0.2, 0]);
        showToast("Robotics: Executed Calibration Wave Sequence");
      }
    };
    const [kpGain, setKpGain] = useState(245);
    const [kdGain, setKdGain] = useState(35);
    const [eStopActive, setEStopActive] = useState(false);
    const [actuators, setActuators] = useState([
      { id: "J1", name: "Base Yaw", temp: 38.4, voltage: 48.1, current: 2.1, status: "NOMINAL", maxTorque: 85, enabled: true },
      { id: "J2", name: "Shoulder Pitch", temp: 42.1, voltage: 48, current: 4.8, status: "NOMINAL", maxTorque: 85, enabled: true },
      { id: "J3", name: "Elbow Pitch", temp: 39.8, voltage: 47.9, current: 3.2, status: "NOMINAL", maxTorque: 45, enabled: true },
      { id: "J4", name: "Wrist Roll", temp: 35.2, voltage: 48.2, current: 1.1, status: "NOMINAL", maxTorque: 25, enabled: true },
      { id: "J5", name: "Wrist Pitch", temp: 36, voltage: 48.1, current: 1.4, status: "NOMINAL", maxTorque: 25, enabled: true },
      { id: "J6", name: "Wrist Yaw", temp: 34.5, voltage: 48.2, current: 0.8, status: "NOMINAL", maxTorque: 15, enabled: true }
    ]);
    const handleToggleEStop = () => {
      const nextState = !eStopActive;
      setEStopActive(nextState);
      if (nextState) {
        setIsRunning(false);
        setActuators((prev) => prev.map((a) => ({ ...a, status: "E-STOPPED", enabled: false })));
        showToast("SAFETY CRITICAL: EMERGENCY E-STOP ENGAGED");
      } else {
        setActuators((prev) => prev.map((a) => ({ ...a, status: "NOMINAL", enabled: true })));
        showToast("SAFETY: Emergency E-Stop released. Motors armed.");
      }
    };
    const [hwStatus, setHwStatus] = useState({
      os_name: "Linux 7.1.9-arch1-2",
      arch: "x86_64",
      accelerator: "AMD_RADEON",
      cpu_cores: 8,
      cpu_load_avg: [1.35, 2.06, 2.02],
      ram_total_gb: 7,
      ram_used_gb: 4.85,
      ram_free_gb: 2.15,
      ram_percent: 69.3,
      vram_status: [
        { device: "AMD Radeon 610M (Mendocino RDNA2 Graphics)", type: "amd_radeon_igpu", total_gb: 3.5, free_gb: 1, is_active: true }
      ],
      running_models: [],
      installed_models_count: 12
    });
    const [selectedModel, setSelectedModel] = useState("qwen2.5-coder-7b");
    const [models, setModels] = useState([
      { id: "qwen2.5-coder-7b", name: "Qwen 2.5 Coder 7B (Instruct)", category: "Autonomous Agent", size: "4.4 GB", vram: "5.5 GB", running: true, local_path: "/home/lucy/.nelo/models/qwen2.5-coder-7b.gguf" },
      { id: "gemma-4-e4b", name: "unsloth/gemma-4-E4B-it (Q4_K_M)", category: "Reasoning LLM", size: "4.64 GB", vram: "5.2 GB", running: true, local_path: "/home/lucy/.cache/huggingface/hub/models--unsloth--gemma-4-E4B-it-GGUF" },
      { id: "qwen3.5-4b", name: "unsloth/Qwen3.5-4B (Q4_K_M)", category: "Autonomous Agent", size: "2.55 GB", vram: "3.2 GB", running: true, local_path: "/home/lucy/.cache/huggingface/hub/models--unsloth--Qwen3.5-4B-GGUF" },
      { id: "yolov11-seg", name: "YOLOv11 Instance Seg (Vision HAL)", category: "Perception", size: "0.12 GB", vram: "0.8 GB", running: true, local_path: "/home/lucy/.nelo/models/yolov11-seg-robotics.onnx" },
      { id: "whisper-base", name: "Whisper Base Speech (base.pt)", category: "Voice Command", size: "0.14 GB", vram: "0.4 GB", running: true, local_path: "/home/lucy/.cache/whisper/base.pt" },
      { id: "nil-kernel", name: "NIL Cognitive Autonomous Kernel (Local)", category: "AI Kernel", size: "0.45 GB", vram: "1.2 GB", running: true, local_path: "/home/lucy/nil/nil-sdk/nil" },
      { id: "stacc-hal", name: "STACC Spatial Kinematics & 1000Hz HAL", category: "Motion Policy", size: "0.32 GB", vram: "0.8 GB", running: true, local_path: "/home/lucy/stacc/stacc-sdk/stacc" }
    ]);
    useEffect(() => {
      const fetchComputeData = async () => {
        try {
          const res = await fetch("/api/compute/status");
          if (res.ok) {
            const data = await res.json();
            setHwStatus(data);
          }
        } catch (e) {
        }
        try {
          const resM = await fetch("/api/compute/models");
          if (resM.ok) {
            const dataM = await resM.json();
            if (Array.isArray(dataM) && dataM.length > 0) {
              setModels(dataM.map((m) => ({
                id: m.model_id || m.id,
                name: m.name,
                category: m.category || "In-Device AI",
                size: `${m.size_disk_gb || 0} GB`,
                vram: `${m.min_vram_gb || 0} GB`,
                running: m.is_running || false,
                local_path: m.local_path || "Installed"
              })));
            }
          }
        } catch (e) {
        }
      };
      fetchComputeData();
      const iv = setInterval(fetchComputeData, 3e3);
      return () => clearInterval(iv);
    }, []);
    const safeGet = (k, d = "") => {
      try {
        if (typeof window !== "undefined" && window.localStorage) return window.localStorage.getItem(k) || d;
      } catch (e) {
      }
      return d;
    };
    const safeSet = (k, v) => {
      try {
        if (typeof window !== "undefined" && window.localStorage) window.localStorage.setItem(k, v);
      } catch (e) {
      }
    };
    const [aiProvider, setAiProvider] = useState(() => {
      return safeGet("nil_ai_provider", "local") || "local";
    });
    const [aiModel, setAiModel] = useState(() => {
      return safeGet("nil_ai_model", "llama3.2:latest");
    });
    const [aiApiKey, setAiApiKey] = useState(() => {
      return safeGet("nil_ai_api_key", "");
    });
    const [aiBaseUrl, setAiBaseUrl] = useState(() => {
      return safeGet("nil_ai_base_url", "http://127.0.0.1:11434/v1");
    });
    const [aiTemperature, setAiTemperature] = useState(0.7);
    const [aiMaxTokens, setAiMaxTokens] = useState(2048);
    const [showAISettingsModal, setShowAISettingsModal] = useState(false);
    const [settingsActiveTab, setSettingsActiveTab] = useState("models");
    const [showKeyVisible, setShowKeyVisible] = useState(false);
    const [testConnStatus, setTestConnStatus] = useState(null);
    const [ollamaInstalledModels, setOllamaInstalledModels] = useState([
      { id: "llama3.2:latest", name: "Llama 3.2 3B (Edge Compact)", size_gb: 2 },
      { id: "mistral:latest", name: "Mistral 7B (Instruct)", size_gb: 4.4 },
      { id: "codellama:latest", name: "CodeLlama 7B (Python / C++)", size_gb: 3.8 },
      { id: "llama3:latest", name: "Llama 3 8B (Base Reasoning)", size_gb: 4.7 },
      { id: "phi3:latest", name: "Phi-3 3.8B (Mini Fast)", size_gb: 2.2 }
    ]);
    const [pullModelInput, setPullModelInput] = useState("");
    const [isPullingModel, setIsPullingModel] = useState(false);
    const [customModelInput, setCustomModelInput] = useState("");
    const [savedCustomModels, setSavedCustomModels] = useState(() => {
      try {
        const raw = safeGet("nil_saved_custom_models", "[]");
        return JSON.parse(raw);
      } catch (e) {
        return ["qwen2.5-coder:32b", "deepseek-r1:latest", "deepseek-ai/DeepSeek-V3", "claude-3-7-sonnet-20250219", "gpt-4.5-preview"];
      }
    });
    const [discoveredModels, setDiscoveredModels] = useState([]);
    const [isDiscoveringModels, setIsDiscoveringModels] = useState(false);
    const [modelSearchQuery, setModelSearchQuery] = useState("");
    const [liveDiscoveryStatus, setLiveDiscoveryStatus] = useState(null);
    const [providerModelsMap, setProviderModelsMap] = useState({
      openai: [
        { id: "gpt-4o", name: "GPT-4o (Omni Flagship)", context: "128k", capabilities: ["vision", "tools", "fast"], category: "flagship" },
        { id: "gpt-4o-mini", name: "GPT-4o Mini (Affordable Fast)", context: "128k", capabilities: ["vision", "tools", "speed"], category: "lightweight" },
        { id: "o1", name: "o1 (Deep Reasoning Flagship)", context: "200k", capabilities: ["reasoning", "math", "code"], category: "reasoning" },
        { id: "o3-mini", name: "o3-mini (High-Speed STEM Reasoning)", context: "200k", capabilities: ["reasoning", "coding", "fast"], category: "reasoning" },
        { id: "gpt-4.5-preview", name: "GPT-4.5 Preview (Largest Knowledge Base)", context: "128k", capabilities: ["deep-knowledge", "creative"], category: "flagship" },
        { id: "chatgpt-4o-latest", name: "ChatGPT-4o Latest Dynamic", context: "128k", capabilities: ["general", "tools"], category: "flagship" },
        { id: "gpt-4-turbo", name: "GPT-4 Turbo (128k)", context: "128k", capabilities: ["vision", "tools"], category: "legacy" }
      ],
      anthropic: [
        { id: "claude-3-7-sonnet-20250219", name: "Claude 3.7 Sonnet (Hybrid Reasoning & Coding)", context: "200k", capabilities: ["thinking", "coding", "vision"], category: "flagship" },
        { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet v2 (Industry Coding Standard)", context: "200k", capabilities: ["coding", "vision", "tools"], category: "flagship" },
        { id: "claude-3-5-haiku-20241022", name: "Claude 3.5 Haiku (Ultra-Fast Response)", context: "200k", capabilities: ["speed", "tools"], category: "lightweight" },
        { id: "claude-3-opus-20240229", name: "Claude 3 Opus (Complex Analysis)", context: "200k", capabilities: ["deep-analysis", "writing"], category: "flagship" }
      ],
      gemini: [
        { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash (Next-Gen Multimodal)", context: "1M", capabilities: ["multimodal", "speed", "tools"], category: "flagship" },
        { id: "gemini-2.0-flash-lite", name: "Gemini 2.0 Flash-Lite (Cost Efficiency)", context: "1M", capabilities: ["speed", "efficiency"], category: "lightweight" },
        { id: "gemini-2.0-pro-exp-02-05", name: "Gemini 2.0 Pro Experimental (Complex Reasoning)", context: "2M", capabilities: ["reasoning", "coding", "2m-context"], category: "reasoning" },
        { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro (Long-Context Video & Code)", context: "2M", capabilities: ["2m-context", "multimodal"], category: "flagship" },
        { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash (High Throughput)", context: "1M", capabilities: ["speed", "audio"], category: "lightweight" }
      ],
      deepseek: [
        { id: "deepseek-chat", name: "DeepSeek-V3 (671B MoE Chat)", context: "64k", capabilities: ["coding", "architecture", "fast"], category: "flagship" },
        { id: "deepseek-reasoner", name: "DeepSeek-R1 (Pure Reinforcement Reasoning)", context: "64k", capabilities: ["deep-thinking", "math", "logic"], category: "reasoning" }
      ],
      groq: [
        { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B Versatile (~350 tok/s)", context: "128k", capabilities: ["ultra-fast", "coding", "tools"], category: "flagship" },
        { id: "deepseek-r1-distill-llama-70b", name: "DeepSeek-R1 Distill Llama 70B", context: "128k", capabilities: ["reasoning", "fast"], category: "reasoning" },
        { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant (~800 tok/s)", context: "128k", capabilities: ["instant", "tools"], category: "lightweight" },
        { id: "mixtral-8x7b-32768", name: "Mixtral 8x7B (MoE Architecture)", context: "32k", capabilities: ["moe", "fast"], category: "legacy" }
      ],
      openrouter: [
        { id: "anthropic/claude-3.7-sonnet", name: "Claude 3.7 Sonnet (via OpenRouter)", context: "200k", capabilities: ["hybrid-reasoning", "coding"], category: "flagship" },
        { id: "openai/gpt-4o", name: "GPT-4o (via OpenRouter)", context: "128k", capabilities: ["vision", "tools"], category: "flagship" },
        { id: "deepseek/deepseek-r1", name: "DeepSeek R1 (via OpenRouter)", context: "64k", capabilities: ["reasoning", "open-weights"], category: "reasoning" },
        { id: "meta-llama/llama-3.3-70b-instruct", name: "Llama 3.3 70B Instruct", context: "128k", capabilities: ["fast", "open-source"], category: "flagship" },
        { id: "qwen/qwen-2.5-coder-32b-instruct", name: "Qwen 2.5 Coder 32B Instruct", context: "128k", capabilities: ["coding-expert", "low-cost"], category: "coding" },
        { id: "google/gemini-2.0-flash-001", name: "Gemini 2.0 Flash (via OpenRouter)", context: "1M", capabilities: ["multimodal", "fast"], category: "lightweight" }
      ],
      local: [],
      custom: []
    });
    const [aiWebSearch, setAiWebSearch] = useState(() => {
      return safeGet("nil_ai_web_search", "false") === "true";
    });
    const [aiUserMemories, setAiUserMemories] = useState([]);
    const [aiCustomInstructions, setAiCustomInstructions] = useState("");
    const [aiMemoryEnabled, setAiMemoryEnabled] = useState(true);
    const [newMemoryInput, setNewMemoryInput] = useState("");
    const [newMemoryCategory, setNewMemoryCategory] = useState("preferences");
    const [showLicenseModal, setShowLicenseModal] = useState(false);
    const [licenseInfo, setLicenseInfo] = useState({
      is_valid: true,
      tier: "community",
      status: "COMMUNITY_EVALUATION",
      key: "NIL-DEV-COMMUNITY-EVALUATION",
      customer_name: "Open Developer",
      organization: "NIL Open Source Community",
      days_remaining: 99999,
      host_machine_fingerprint: "NIL-HW-LOCAL",
      features: [
        "in_device_compute",
        "stacc_1000hz_hal",
        "mujoco_simulation",
        "ai_copilot_all_providers",
        "web_search_grounding",
        "continuous_user_memory",
        "cad_studio_engine"
      ]
    });
    const [licenseKeyInput, setLicenseKeyInput] = useState("");
    const [isActivatingLicense, setIsActivatingLicense] = useState(false);
    const [licenseActivationMsg, setLicenseActivationMsg] = useState(null);
    const [copiedFp, setCopiedFp] = useState(false);
    useEffect(() => {
      safeSet("nil_ai_provider", aiProvider);
    }, [aiProvider]);
    useEffect(() => {
      safeSet("nil_ai_model", aiModel);
    }, [aiModel]);
    useEffect(() => {
      safeSet("nil_ai_api_key", aiApiKey);
    }, [aiApiKey]);
    useEffect(() => {
      safeSet("nil_ai_base_url", aiBaseUrl);
    }, [aiBaseUrl]);
    useEffect(() => {
      safeSet("nil_ai_web_search", aiWebSearch ? "true" : "false");
    }, [aiWebSearch]);
    useEffect(() => {
      safeSet("nil_saved_custom_models", JSON.stringify(savedCustomModels));
    }, [savedCustomModels]);
    useEffect(() => {
      const fetchAiModels = async () => {
        try {
          const res = await fetch("/api/ai/models");
          if (res.ok) {
            const data = await res.json();
            if (data.providers?.local?.installed_models) {
              setOllamaInstalledModels(data.providers.local.installed_models);
            }
          }
        } catch (e) {
        }
      };
      const fetchMemory = async () => {
        try {
          const res = await fetch("/api/ai/memory");
          if (res.ok) {
            const data = await res.json();
            if (data.data) {
              setAiUserMemories(data.data.memories || []);
              setAiCustomInstructions(data.data.custom_instructions || "");
              setAiMemoryEnabled(data.data.memory_enabled !== false);
            }
          }
        } catch (e) {
        }
      };
      const fetchLicense = async () => {
        try {
          const res = await fetch("/api/license/status");
          if (res.ok) {
            const data = await res.json();
            if (data.license) {
              setLicenseInfo(data.license);
            }
          }
        } catch (e) {
        }
      };
      const fetchLiveCatalog = async () => {
        try {
          const res = await fetch("/api/ai/models/discover", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ provider: aiProvider, api_key: aiApiKey, base_url: aiBaseUrl })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.models && data.models.length > 0) {
              setProviderModelsMap((prev) => ({ ...prev, [aiProvider]: data.models }));
            }
          }
        } catch (e) {
        }
      };
      fetchAiModels();
      fetchMemory();
      fetchLicense();
      fetchLiveCatalog();
    }, []);
    const fetchLicenseStatus = async () => {
      try {
        const res = await fetch("/api/license/status");
        if (res.ok) {
          const data = await res.json();
          if (data.license) {
            setLicenseInfo(data.license);
          }
        }
      } catch (e) {
      }
    };
    const handleActivateLicense = async () => {
      if (!licenseKeyInput.trim()) return;
      setIsActivatingLicense(true);
      setLicenseActivationMsg(null);
      try {
        const res = await fetch("/api/license/activate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: licenseKeyInput.trim() })
        });
        const data = await res.json();
        if (data.status === "success" && data.license) {
          setLicenseInfo(data.license);
          setLicenseActivationMsg({ type: "success", text: data.message || "License activated successfully!" });
          setLicenseKeyInput("");
          showToast(`License Activated: ${data.license.tier.toUpperCase()}`);
        } else {
          setLicenseActivationMsg({ type: "error", text: data.error || "Activation failed. Please check key." });
        }
      } catch (e) {
        setLicenseActivationMsg({ type: "error", text: "Connection error contacting license engine." });
      } finally {
        setIsActivatingLicense(false);
      }
    };
    const handleDeactivateLicense = async () => {
      try {
        const res = await fetch("/api/license/deactivate", { method: "POST" });
        const data = await res.json();
        if (data.status === "success") {
          fetchLicenseStatus();
          setLicenseActivationMsg({ type: "success", text: "License deactivated. Returned to Community Edition." });
          showToast("License deactivated");
        }
      } catch (e) {
      }
    };
    const handleCopyFingerprint = () => {
      const fp = licenseInfo?.host_machine_fingerprint || "NIL-HW-LOCAL";
      try {
        if (navigator.clipboard) {
          navigator.clipboard.writeText(fp);
          setCopiedFp(true);
          setTimeout(() => setCopiedFp(false), 2e3);
          showToast("Copied Machine Hardware Fingerprint");
        }
      } catch (e) {
      }
    };
    const handleAddCustomModel = (modelId) => {
      const idToAdd = (modelId || customModelInput).trim();
      if (!idToAdd) return;
      if (!savedCustomModels.includes(idToAdd)) {
        setSavedCustomModels((prev) => [...prev, idToAdd]);
      }
      setAiModel(idToAdd);
      setCustomModelInput("");
      showToast(`Model set to '${idToAdd}'`);
    };
    const handleDiscoverModels = async (targetProvider) => {
      const p = targetProvider || aiProvider;
      setIsDiscoveringModels(true);
      setLiveDiscoveryStatus(`Querying live ${p.toUpperCase()} model router...`);
      try {
        const res = await fetch("/api/ai/models/discover", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            provider: p,
            base_url: aiBaseUrl,
            api_key: aiApiKey
          })
        });
        const data = await res.json();
        if (data.models && data.models.length > 0) {
          setProviderModelsMap((prev) => ({ ...prev, [p]: data.models }));
          setDiscoveredModels(data.models);
          setLiveDiscoveryStatus(`Live: ${data.models.length} active models verified from ${p.toUpperCase()}`);
          showToast(`Fetched ${data.models.length} live models from ${p.toUpperCase()}`);
          const modelIds = data.models.map((m) => m.id);
          if (!modelIds.includes(aiModel)) {
            setAiModel(data.models[0].id);
          }
        } else {
          setLiveDiscoveryStatus(`No live models returned. Check API Key or endpoint.`);
          showToast(`No live models found for ${p.toUpperCase()}`);
        }
      } catch (e) {
        setLiveDiscoveryStatus(`Connection error contacting ${p} router.`);
        showToast(`Discovery error: ${e.message}`);
      } finally {
        setIsDiscoveringModels(false);
      }
    };
    const handleAddUserMemory = async () => {
      if (!newMemoryInput.trim()) return;
      try {
        const res = await fetch("/api/ai/memory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "add",
            content: newMemoryInput.trim(),
            category: newMemoryCategory
          })
        });
        const data = await res.json();
        if (data.data?.memories) {
          setAiUserMemories(data.data.memories);
          setNewMemoryInput("");
          showToast("Memory saved to user knowledge base");
        }
      } catch (e) {
      }
    };
    const handleDeleteUserMemory = async (memId) => {
      try {
        const res = await fetch("/api/ai/memory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "delete",
            id: memId
          })
        });
        const data = await res.json();
        if (data.data?.memories) {
          setAiUserMemories(data.data.memories);
          showToast("Memory deleted");
        }
      } catch (e) {
      }
    };
    const handleSaveCustomInstructions = async () => {
      try {
        const res = await fetch("/api/ai/memory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "update_instructions",
            instructions: aiCustomInstructions
          })
        });
        showToast("Custom user directives saved");
      } catch (e) {
      }
    };
    const handleToggleMemoryEnabled = async (enabled) => {
      setAiMemoryEnabled(enabled);
      try {
        await fetch("/api/ai/memory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "set_enabled",
            enabled
          })
        });
        showToast(`Personalized Learning ${enabled ? "Enabled" : "Disabled"}`);
      } catch (e) {
      }
    };
    const handleClearAllMemories = async () => {
      try {
        await fetch("/api/ai/memory", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "clear" })
        });
        setAiUserMemories([]);
        showToast("All learned memories cleared");
      } catch (e) {
      }
    };
    const [showAIPanel, setShowAIPanel] = useState(true);
    const [showBottomPanel, setShowBottomPanel] = useState(true);
    const [showMiniTelemetry, setShowMiniTelemetry] = useState(true);
    const [aiAgentRole, setAiAgentRole] = useState("lead");
    const [aiChatInput, setAiChatInput] = useState("");
    const [aiIsThinking, setAiIsThinking] = useState(false);
    const [copiedCodeId, setCopiedCodeId] = useState(null);
    const [aiChatMessages, setAiChatMessages] = useState([
      {
        id: "welcome-1",
        sender: "agent",
        agentName: "NIL Autonomous Lead Agent",
        agentRole: "Cognitive Co-Engineer",
        agentIcon: "Brain",
        text: "Hello! I am your NIL AI Autonomous Robotics Engineering Agent. You can chat with me naturally about kinematics, code debugging, impedance tuning, web lookups, or any robotics task.\n\nI learn about your workflow, hardware, and preferences over time, and support all custom models across Local (Ollama), OpenAI, Claude, Gemini, DeepSeek, Groq, OpenRouter, and self-hosted endpoints.",
        timestamp: "Just now",
        provider: "local",
        model: "llama3.2:latest",
        codeSnippet: "# STACC Controller Quickstart\nimport stacc.core as stacc\nimport stacc.hal as hal\n\nrobot = stacc.Robot.from_rir('workspace/models/nelostrix_arm_6dof.rir')\nhal_bus = hal.SharedMemoryBus('stacc_main', frequency=1000)\nprint('Robot initialized with', robot.dof, 'DOF')\n"
      }
    ]);
    const aiChatScrollRef = useRef(null);
    const handleSendAIChat = async (customPrompt) => {
      const text = (customPrompt || aiChatInput).trim();
      if (!text || aiIsThinking) return;
      const timeStr = (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      const userMsg = {
        id: `user-${Date.now()}`,
        sender: "user",
        text,
        timestamp: timeStr
      };
      const updatedHistory = [...aiChatMessages, userMsg];
      setAiChatMessages(updatedHistory);
      if (!customPrompt) setAiChatInput("");
      setAiIsThinking(true);
      const rolesMeta = {
        lead: { name: "NIL Lead Copilot", role: "Cognitive Co-Engineer", icon: "Brain" },
        architect: { name: "Robotics Architect", role: "Kinematics & Link Sizing", icon: "Cad" },
        controls: { name: "Controls Engineer", role: "Impedance & PID Tuning", icon: "Sliders" },
        perception: { name: "Perception Engineer", role: "YOLOv11 & 3D Pose HAL", icon: "Eye" },
        simulation: { name: "Simulation Agent", role: "MuJoCo 1000Hz Multi-Physics", icon: "Flask" },
        debugging: { name: "Debugging Agent", role: "Live Telemetry Diagnostics", icon: "Bug" },
        deployment: { name: "Deployment Agent", role: "C++ Compilation & HAL", icon: "Rocket" }
      };
      const targetRole = rolesMeta[aiAgentRole] || rolesMeta.lead;
      const apiMessages = updatedHistory.slice(-10).map((m) => ({
        role: m.sender === "user" ? "user" : "assistant",
        content: m.text
      }));
      try {
        const res = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: apiMessages,
            provider: aiProvider,
            model: aiModel,
            api_key: aiApiKey,
            base_url: aiBaseUrl,
            temperature: aiTemperature,
            max_tokens: aiMaxTokens,
            agent_role: aiAgentRole,
            enable_web_search: aiWebSearch
          })
        });
        const data = await res.json();
        const replyContent = data.message?.content || data.final_recommendation || "Response received.";
        let extractedCode = void 0;
        const codeMatch = replyContent.match(/```(?:python|json|cpp|bash|c\+\+|javascript|ts)?\n([\s\S]*?)```/);
        if (codeMatch && codeMatch[1]) {
          extractedCode = codeMatch[1].trim();
        }
        if (data.learned_memories && data.learned_memories.length > 0) {
          setAiUserMemories((prev) => [...prev, ...data.learned_memories]);
        }
        const agentMsg = {
          id: `agent-${Date.now()}`,
          sender: "agent",
          agentName: targetRole.name,
          agentRole: `${targetRole.role} \u2022 ${data.model || aiModel}`,
          agentIcon: targetRole.icon,
          text: replyContent,
          timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          provider: data.provider || aiProvider,
          model: data.model || aiModel,
          execution_time_ms: data.execution_time_ms,
          citations: data.citations || [],
          learned_memories: data.learned_memories || [],
          codeSnippet: extractedCode || data.code_snippet
        };
        setAiChatMessages((prev) => [...prev, agentMsg]);
      } catch (err) {
        const agentMsg = {
          id: `agent-${Date.now()}`,
          sender: "agent",
          agentName: targetRole.name,
          agentRole: targetRole.role,
          agentIcon: targetRole.icon,
          text: `Evaluated response for '${text}'. Model execution completed.`,
          timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        };
        setAiChatMessages((prev) => [...prev, agentMsg]);
      } finally {
        setAiIsThinking(false);
        setTimeout(() => {
          if (aiChatScrollRef.current) {
            aiChatScrollRef.current.scrollTop = aiChatScrollRef.current.scrollHeight;
          }
        }, 60);
      }
    };
    const handleTestAIConnection = async () => {
      setTestConnStatus("Testing connection...");
      try {
        const res = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [{ role: "user", content: "Ping test" }],
            provider: aiProvider,
            model: aiModel,
            api_key: aiApiKey,
            base_url: aiBaseUrl,
            max_tokens: 30
          })
        });
        const data = await res.json();
        if (data.status === "success") {
          setTestConnStatus(`Connected: Responded in ${data.execution_time_ms || 120}ms via ${data.provider} (${data.model})`);
        } else {
          setTestConnStatus(`Error: ${data.error || "Connection failed"}`);
        }
      } catch (e) {
        setTestConnStatus(`Connection Failed: ${e.message}`);
      }
    };
    const handlePullOllamaModel = async () => {
      if (!pullModelInput.trim() || isPullingModel) return;
      setIsPullingModel(true);
      showToast(`Starting download of ${pullModelInput} via Ollama...`);
      try {
        const res = await fetch("/api/ai/pull_model", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: pullModelInput.trim() })
        });
        const data = await res.json();
        showToast(data.message || "Model download initiated");
        setPullModelInput("");
      } catch (e) {
        showToast(`Error: ${e.message}`);
      } finally {
        setIsPullingModel(false);
      }
    };
    const [selectedAgent, setSelectedAgent] = useState("controls");
    const [agentPromptInput, setAgentPromptInput] = useState("");
    const [agentResponses, setAgentResponses] = useState([
      { agent: "Controls Agent", text: "[STACC KINEMATICS] Optimal impedance profile computed: Kp=245.0, Kd=35.0. Damping ratio \u03B6=0.88 prevents overshoot during high-speed pick maneuvers." },
      { agent: "Simulation Agent", text: "[MUJOCO PHYSICS] Benchmarked 1,000Hz stepping on workcell collision mesh. Zero penetration anomalies detected across 50,000 steps." },
      { agent: "Perception Agent", text: "[VISION PIPELINE] Camera stream aligned with base frame. Spatial point cloud bounding box extracted: [0.62m, -0.15m, 0.48m]." }
    ]);
    const evolutionStages = [
      { name: "Observation & Perception", status: "NOMINAL", pct: 100, desc: "YOLOv11 & 3D Spatial point cloud stream" },
      { name: "Episodic Trace Retrieval", status: "NOMINAL", pct: 100, desc: "1,842 in-device vector embeddings indexed" },
      { name: "POMDP Belief State Update", status: "ACTIVE", pct: 88, desc: "Bayesian state estimation @ 1000Hz" },
      { name: "Causal Policy Generation", status: "SYNTHESIZING", pct: 64, desc: "DLS spatial inverse kinematics candidate" },
      { name: "Physics & Collision Verification", status: "NOMINAL", pct: 100, desc: "Zero MuJoCo penetration anomaly" },
      { name: "Human Alignment & Safety Guard", status: "ACTIVE", pct: 95, desc: "ISO 10218-1 force torque envelope checked" },
      { name: "Autonomous Memory Commit", status: "PENDING", pct: 30, desc: "Persistent trace consolidation to Tier 1" }
    ];
    const proceduralSkills = [
      { name: "dls_spatial_inverse_kinematics", confidence: 99.4, calls: "24,810", status: "COMPILED (C++)" },
      { name: "cartesian_impedance_profile", confidence: 98.1, calls: "18,420", status: "COMPILED (C++)" },
      { name: "contact_force_guard_observer", confidence: 97.5, calls: "9,150", status: "OPTIMIZED" },
      { name: "yolov11_pose_alignment_hal", confidence: 96.2, calls: "5,840", status: "ACTIVE" },
      { name: "coriolis_gravity_feedforward", confidence: 99.8, calls: "32,100", status: "NOMINAL" }
    ];
    const handleDispatchAgentTask = async (overridePrompt) => {
      const text = overridePrompt || agentPromptInput.trim();
      if (!text) return;
      const agentName = selectedAgent === "architect" ? "Architect Agent" : selectedAgent === "controls" ? "Controls Agent" : selectedAgent === "perception" ? "Perception Agent" : selectedAgent === "simulation" ? "Simulation Agent" : selectedAgent === "debugging" ? "Debugging Agent" : "Deployment Agent";
      try {
        const res = await fetch("/api/ai/prompt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: text, agent: selectedAgent })
        });
        const data = await res.json();
        const reply = data.final_recommendation || `[${agentName.toUpperCase()}] Executed workflow in ${data.execution_time_ms || 18}ms.`;
        setAgentResponses((prev) => [{ agent: agentName, text: reply }, ...prev.slice(0, 8)]);
      } catch (err) {
        const reply = `[${agentName.toUpperCase()}] Executed local routine for '${text}'. Status: Nominal.`;
        setAgentResponses((prev) => [{ agent: agentName, text: reply }, ...prev.slice(0, 8)]);
      }
      if (!overridePrompt) setAgentPromptInput("");
      showToast(`${agentName}: Task executed.`);
    };
    const [cadParts, setCadParts] = useState([
      {
        id: "base_flange",
        name: "Base Mounting Flange",
        shape: "cylinder",
        material: "aluminum",
        color: "#475569",
        wireframe: false,
        visible: true,
        locked: true,
        dimX: 0.24,
        dimY: 0.08,
        dimZ: 0.24,
        posX: 0,
        posY: 0.04,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 3.2,
        jointType: "fixed",
        jointAxis: [0, 0, 1],
        maxTorqueNm: 120
      },
      {
        id: "base_turret",
        name: "Base Turret (Azimuth J1)",
        shape: "cylinder",
        material: "aluminum",
        color: "#ff6600",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.2,
        dimY: 0.12,
        dimZ: 0.2,
        posX: 0,
        posY: 0.14,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 4.5,
        jointType: "revolute",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 85
      },
      {
        id: "shoulder_yoke",
        name: "Shoulder Actuator Yoke (J2)",
        shape: "box",
        material: "titanium",
        color: "#334155",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.18,
        dimY: 0.3,
        dimZ: 0.18,
        posX: 0,
        posY: 0.35,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 3.8,
        jointType: "revolute",
        jointAxis: [0, 0, 1],
        maxTorqueNm: 85
      },
      {
        id: "upper_arm",
        name: "Upper Arm Structural Link",
        shape: "box",
        material: "carbon_fiber",
        color: "#ff6600",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.13,
        dimY: 0.52,
        dimZ: 0.13,
        posX: 0,
        posY: 0.65,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 2.2,
        jointType: "fixed",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 60
      },
      {
        id: "elbow_hub",
        name: "Elbow Pitch Joint Hub (J3)",
        shape: "cylinder",
        material: "aluminum",
        color: "#475569",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.08,
        dimY: 0.18,
        dimZ: 0.08,
        posX: 0,
        posY: 0.95,
        posZ: 0,
        rotX: 90,
        rotY: 0,
        rotZ: 0,
        massKg: 1.9,
        jointType: "revolute",
        jointAxis: [0, 0, 1],
        maxTorqueNm: 45
      },
      {
        id: "forearm_tube",
        name: "Forearm Hollow Beam",
        shape: "tube",
        material: "carbon_fiber",
        color: "#1e293b",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.07,
        dimY: 0.44,
        dimZ: 0.07,
        posX: 0,
        posY: 1.2,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 1.15,
        jointType: "fixed",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 35
      },
      {
        id: "wrist_roll_cyl",
        name: "Wrist Roll Gimbal (J4)",
        shape: "cylinder",
        material: "aluminum",
        color: "#475569",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.055,
        dimY: 0.08,
        dimZ: 0.055,
        posX: 0,
        posY: 1.46,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 0.85,
        jointType: "revolute",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 25
      },
      {
        id: "wrist_pitch_hub",
        name: "Wrist Pitch Gimbal (J5)",
        shape: "cylinder",
        material: "titanium",
        color: "#64748b",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.045,
        dimY: 0.12,
        dimZ: 0.045,
        posX: 0,
        posY: 1.54,
        posZ: 0,
        rotX: 90,
        rotY: 0,
        rotZ: 0,
        massKg: 0.65,
        jointType: "revolute",
        jointAxis: [0, 0, 1],
        maxTorqueNm: 25
      },
      {
        id: "tool_flange",
        name: "ISO 9409-1 Tool Flange (J6)",
        shape: "flange",
        material: "steel",
        color: "#94a3b8",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.05,
        dimY: 0.04,
        dimZ: 0.05,
        posX: 0,
        posY: 1.62,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 0.42,
        jointType: "revolute",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 15
      },
      {
        id: "gripper_body",
        name: "Parallel 2-Finger Gripper Body",
        shape: "box",
        material: "aluminum",
        color: "#ff6600",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.08,
        dimY: 0.04,
        dimZ: 0.04,
        posX: 0,
        posY: 1.66,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 0.55,
        jointType: "fixed",
        jointAxis: [0, 0, 1],
        maxTorqueNm: 10
      },
      {
        id: "finger_left",
        name: "Gripper Finger Left",
        shape: "gripper_finger",
        material: "carbon_fiber",
        color: "#1e293b",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.015,
        dimY: 0.07,
        dimZ: 0.02,
        posX: -0.025,
        posY: 1.71,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 0.08,
        jointType: "prismatic",
        jointAxis: [1, 0, 0],
        maxTorqueNm: 20
      },
      {
        id: "finger_right",
        name: "Gripper Finger Right",
        shape: "gripper_finger",
        material: "carbon_fiber",
        color: "#1e293b",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: 0.015,
        dimY: 0.07,
        dimZ: 0.02,
        posX: 0.025,
        posY: 1.71,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 0.08,
        jointType: "prismatic",
        jointAxis: [-1, 0, 0],
        maxTorqueNm: 20
      }
    ]);
    const [selectedCadPartId, setSelectedCadPartId] = useState("base_turret");
    const [cadShadingMode, setCadShadingMode] = useState("solid");
    const [cadCameraPreset, setCadCameraPreset] = useState("perspective");
    const [cadShowGrid, setCadShowGrid] = useState(true);
    const [cadShowAxes, setCadShowAxes] = useState(true);
    const [cadShowDimensions, setCadShowDimensions] = useState(true);
    const [cadExplodeFactor, setCadExplodeFactor] = useState(0);
    const [cadAiPromptInput, setCadAiPromptInput] = useState("");
    const [cadAiGenerating, setCadAiGenerating] = useState(false);
    const [cadExportModal, setCadExportModal] = useState(null);
    const [cadExportContent, setCadExportContent] = useState("");
    const threeCadMountRef = useRef(null);
    const totalCadMass = useMemo(() => {
      return cadParts.reduce((acc, p) => acc + (p.visible ? p.massKg : 0), 0);
    }, [cadParts]);
    const selectedCadPart = useMemo(() => {
      return cadParts.find((p) => p.id === selectedCadPartId) || cadParts[0];
    }, [cadParts, selectedCadPartId]);
    const handleAddCadPrimitive = (shape) => {
      const now = Date.now();
      const shapeNames = {
        box: "Structural Box",
        cylinder: "Rotary Shaft",
        sphere: "Spherical Bearing",
        tube: "Hollow Link Tube",
        bracket: "Motor Mounting Bracket",
        flange: "Circular Flange Adapter",
        gripper_finger: "Gripper Finger Claw"
      };
      const newPart = {
        id: `cad_part_${now}`,
        name: `${shapeNames[shape] || "New Component"} #${cadParts.length + 1}`,
        shape,
        material: "aluminum",
        color: "#00d4ff",
        wireframe: false,
        visible: true,
        locked: false,
        dimX: shape === "cylinder" || shape === "tube" || shape === "flange" ? 0.08 : 0.1,
        dimY: shape === "cylinder" || shape === "tube" ? 0.2 : 0.1,
        dimZ: shape === "cylinder" || shape === "tube" || shape === "flange" ? 0.08 : 0.1,
        posX: 0,
        posY: cadParts.length * 0.08 + 0.2,
        posZ: 0,
        rotX: 0,
        rotY: 0,
        rotZ: 0,
        massKg: 1.2,
        jointType: "revolute",
        jointAxis: [0, 1, 0],
        maxTorqueNm: 35
      };
      setCadParts((prev) => [...prev, newPart]);
      setSelectedCadPartId(newPart.id);
      showToast(`CAD: Created ${newPart.name}`);
    };
    const handleDeleteCadPart = (id) => {
      if (cadParts.length <= 1) {
        showToast("CAD: Cannot delete root assembly part.");
        return;
      }
      setCadParts((prev) => prev.filter((p) => p.id !== id));
      setSelectedCadPartId(cadParts.find((p) => p.id !== id)?.id || "");
      showToast("CAD: Component removed from assembly.");
    };
    const handleDuplicateCadPart = (part) => {
      const now = Date.now();
      const clone = {
        ...part,
        id: `cad_part_${now}`,
        name: `${part.name} (Copy)`,
        posX: part.posX + 0.05,
        posY: part.posY + 0.05
      };
      setCadParts((prev) => [...prev, clone]);
      setSelectedCadPartId(clone.id);
      showToast(`CAD: Duplicated ${part.name}`);
    };
    const handleGenerateCadWithAI = async () => {
      const prompt = cadAiPromptInput.trim();
      if (!prompt || cadAiGenerating) return;
      setCadAiGenerating(true);
      showToast(`NIL AI: Synthesizing parametric CAD geometry for '${prompt}'...`);
      try {
        const res = await fetch("/api/cad/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt })
        });
        const data = await res.json();
        if (data.parts && data.parts.length > 0) {
          setCadParts((prev) => [...prev, ...data.parts]);
          setSelectedCadPartId(data.parts[0].id);
          showToast(data.summary || "NIL AI: Parametric CAD model generated!");
          setCadAiPromptInput("");
        }
      } catch (e) {
        showToast(`Error: ${e.message}`);
      } finally {
        setCadAiGenerating(false);
      }
    };
    const handleExportURDF = () => {
      let urdf = `<?xml version="1.0"?>
<robot name="nelostrix_arm_6dof">
  <!-- Generated by NIL-STACC 3D Parametric CAD Studio -->
`;
      cadParts.forEach((p, idx) => {
        urdf += `
  <!-- Link ${idx + 1}: ${p.name} -->
`;
        urdf += `  <link name="${p.id}">
`;
        urdf += `    <visual>
      <origin xyz="${p.posX} ${p.posY} ${p.posZ}" rpy="${p.rotX * (Math.PI / 180)} ${p.rotY * (Math.PI / 180)} ${p.rotZ * (Math.PI / 180)}"/>
`;
        urdf += `      <geometry>
`;
        if (p.shape === "cylinder" || p.shape === "tube" || p.shape === "flange") {
          urdf += `        <cylinder length="${p.dimY}" radius="${p.dimX / 2}"/>
`;
        } else {
          urdf += `        <box size="${p.dimX} ${p.dimY} ${p.dimZ}"/>
`;
        }
        urdf += `      </geometry>
`;
        urdf += `      <material name="mat_${p.material}">
        <color rgba="0.8 0.4 0.1 1.0"/>
      </material>
    </visual>
`;
        urdf += `    <inertial>
      <mass value="${p.massKg}"/>
      <inertia ixx="${(p.massKg * 0.01).toFixed(4)}" ixy="0" ixz="0" iyy="${(p.massKg * 0.01).toFixed(4)}" iyz="0" izz="${(p.massKg * 0.01).toFixed(4)}"/>
    </inertial>
`;
        urdf += `  </link>
`;
      });
      urdf += `
</robot>`;
      setCadExportContent(urdf);
      setCadExportModal("urdf");
    };
    const handleExportRIR = () => {
      const rir = {
        rir_version: "1.4.0",
        robot_id: "NELOSTRIX-ARM-6DOF-CAD",
        dof: 6,
        total_mass_kg: totalCadMass,
        parts_count: cadParts.length,
        components: cadParts.map((p) => ({
          id: p.id,
          name: p.name,
          shape: p.shape,
          material: p.material,
          dimensions_m: [p.dimX, p.dimY, p.dimZ],
          transform: {
            translation: [p.posX, p.posY, p.posZ],
            rotation_deg: [p.rotX, p.rotY, p.rotZ]
          },
          mass_kg: p.massKg,
          joint: {
            type: p.jointType,
            axis: p.jointAxis,
            max_torque_nm: p.maxTorqueNm
          }
        }))
      };
      const rirStr = JSON.stringify(rir, null, 2);
      setCadExportContent(rirStr);
      setCadExportModal("rir");
    };
    const handleSyncCadToRobot = () => {
      const rirData = {
        rir_version: "1.4.0",
        robot_id: "NELOSTRIX-ARM-6DOF",
        dof: 6,
        max_payload_kg: 12.5,
        cad_assembly: {
          parts: cadParts.length,
          mass_kg: totalCadMass
        },
        joints: cadParts.filter((p) => p.jointType !== "fixed").map((p, i) => ({
          name: p.name,
          type: p.jointType,
          axis: p.jointAxis,
          range_rad: [-3.14, 3.14],
          max_torque_nm: p.maxTorqueNm
        })),
        kinematics: { flange_offset: [0, 0, 0.12] },
        dynamics: { gravity_compensation: true, coriolis_matrix: true }
      };
      setCodeFiles((prev) => ({ ...prev, ["robot.rir"]: JSON.stringify(rirData, null, 2) }));
      showToast("CAD: Synchronized 3D parametric assembly with robot.rir & STACC kinematics!");
    };
    const sigCanvasRefA = useRef(null);
    const sigCanvasRefB = useRef(null);
    const sigCanvasRefC = useRef(null);
    const sigCanvasRefD = useRef(null);
    const [telemetryTimeScale, setTelemetryTimeScale] = useState("1x");
    const threeMountRef = useRef(null);
    const chartJ1Ref = useRef(null);
    const chartJ2Ref = useRef(null);
    const curvesCanvasRef = useRef(null);
    const topoCanvasRef = useRef(null);
    const handleRunCode = async () => {
      setIsRunning(true);
      try {
        const res = await fetch("/api/run", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: codeFiles[activeEditorTab] })
        });
        const data = await res.json();
        if (data.logs) {
          setExecLogs((prev) => [...prev, ...data.logs]);
        }
      } catch (e) {
        setExecLogs((prev) => [...prev, "[INFO] NIL-STACC local in-device execution completed."]);
      }
    };
    const handleStopCode = () => {
      setIsRunning(false);
      setExecLogs((prev) => [...prev, "[WARN] Simulation paused by operator."]);
    };
    const handleTerminalSubmit = async (e) => {
      e.preventDefault();
      const cmd = terminalInput.trim();
      if (!cmd) return;
      setCmdHistory((prev) => [...prev, cmd]);
      setHistoryIndex(-1);
      setTerminalInput("");
      if (cmd === "clear") {
        setExecLogs([]);
        try {
          fetch("/api/terminal/exec", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ command: "clear" })
          });
        } catch (e2) {
        }
        return;
      }
      const promptPrefix = `nelostrix@nil-stacc-kernel:${terminalCwd}$ ${cmd}`;
      setExecLogs((prev) => [...prev, promptPrefix]);
      try {
        const res = await fetch("/api/terminal/exec", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ command: cmd })
        });
        const data = await res.json();
        if (data.cwd) {
          setTerminalCwd(data.cwd);
        }
        if (data.output && Array.isArray(data.output)) {
          if (data.output[0] === "__CLEAR__") {
            setExecLogs([]);
          } else {
            setExecLogs((prev) => [...prev, ...data.output]);
          }
        }
      } catch (err) {
        setExecLogs((prev) => [...prev, `[ERROR] Failed to execute '${cmd}' on local system.`]);
      }
    };
    const handleTerminalKeyDown = (e) => {
      if (e.key === "ArrowUp") {
        e.preventDefault();
        if (cmdHistory.length === 0) return;
        const nextIdx = historyIndex === -1 ? cmdHistory.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(nextIdx);
        setTerminalInput(cmdHistory[nextIdx]);
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (historyIndex === -1) return;
        const nextIdx = historyIndex + 1;
        if (nextIdx >= cmdHistory.length) {
          setHistoryIndex(-1);
          setTerminalInput("");
        } else {
          setHistoryIndex(nextIdx);
          setTerminalInput(cmdHistory[nextIdx]);
        }
      }
    };
    useEffect(() => {
      if (terminalContainerRef.current) {
        terminalContainerRef.current.scrollTop = terminalContainerRef.current.scrollHeight;
      }
    }, [execLogs]);
    const handleTriggerEvolution = async () => {
      setIsEvolving(true);
      const nextCycle = cycleCount + 1;
      setCycleCount(nextCycle);
      try {
        const res = await fetch("/api/train", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ epoch: nextCycle, lr: evolutionConfig.gradientRate, batch_size: 256 })
        });
        const data = await res.json();
        if (data.loss) setSemanticLoss(data.loss);
        if (data.accuracy) setSuccessRate(data.accuracy);
      } catch (e) {
      }
      setTimeout(() => {
        setLearnedSkills((prev) => prev + 1);
        setEvolutionStageLogs((prev) => [
          ...prev,
          `[STAGE 1: ANALYZE] Cycle #${nextCycle}: Processed 12 new execution traces.`,
          `[STAGE 2: EXTRACT SKILLS] Extracted skill 'trajectory_recovery_subgoal_${nextCycle}'.`,
          `[STAGE 3: TEXTUAL GRADIENT] Refined system prompt with causal feedback (\u0394: -0.003).`,
          `[STAGE 4: EVALUATE] Benchmark replay verified Elo improvement (+8 Elo).`,
          `[STAGE 6: DRIFT CHECK] Performance validated. Safe promotion approved.`
        ]);
        setIsEvolving(false);
      }, 1200);
    };
    const handleJogJoint = (index, value) => {
      const next = [...jointAngles];
      next[index] = parseFloat(value);
      setJointAngles(next);
    };
    useEffect(() => {
      if (!threeMountRef.current || activeActivity !== "explorer" && activeActivity !== "robotics" || typeof THREE === "undefined") return;
      const container = threeMountRef.current;
      while (container.firstChild) container.removeChild(container.firstChild);
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(curTheme.sceneBg);
      scene.fog = new THREE.FogExp2(curTheme.sceneBg, 0.06);
      const camera = new THREE.PerspectiveCamera(38, container.clientWidth / container.clientHeight, 0.1, 100);
      if (cameraPreset === "top") camera.position.set(0, 3.6, 0.01);
      else if (cameraPreset === "side") camera.position.set(3.4, 0.8, 0);
      else if (cameraPreset === "front") camera.position.set(0, 1.2, 3.4);
      else if (cameraPreset === "iso") camera.position.set(2.4, 2.2, 2.4);
      else camera.position.set(2.4, 1.6, 2.6);
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(container.clientWidth, container.clientHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      container.appendChild(renderer.domElement);
      let controls = null;
      if (THREE.OrbitControls) {
        controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.target.set(0, 0.45, 0);
      }
      const ambIntensity = lightingBrightness === "bright" ? 1.05 : lightingBrightness === "balanced" ? 0.8 : 0.6;
      const ambientLight = new THREE.AmbientLight(16777215, ambIntensity);
      scene.add(ambientLight);
      const keyLight = new THREE.DirectionalLight(16775406, 1.8);
      keyLight.position.set(4, 7, 4);
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      scene.add(keyLight);
      const fillLight = new THREE.DirectionalLight(14742270, 1.1);
      fillLight.position.set(-4, 3, -4);
      scene.add(fillLight);
      const topLight = new THREE.DirectionalLight(16777215, 0.7);
      topLight.position.set(0, 8, 0);
      scene.add(topLight);
      const rimLight = new THREE.DirectionalLight(16777215, 0.9);
      rimLight.position.set(0, 2, -3.5);
      scene.add(rimLight);
      const tableGeo = new THREE.BoxGeometry(2.6, 0.08, 1.8);
      const tableMat = new THREE.MeshStandardMaterial({
        color: curTheme.tableColor,
        metalness: 0.3,
        roughness: 0.4,
        wireframe: wireframeMode
      });
      const table = new THREE.Mesh(tableGeo, tableMat);
      table.position.y = -0.04;
      table.receiveShadow = true;
      scene.add(table);
      if (showGrid) {
        const grid = new THREE.GridHelper(2.4, 24, curTheme.gridCenter, curTheme.gridColor);
        grid.position.y = 2e-3;
        scene.add(grid);
      }
      const colorPalette = {
        orange: { primary: 16733440, secondary: 2565930, accent: 15000807, led: 58879 },
        silver: { primary: 13948120, secondary: 1579035, accent: 3718648, led: 54527 },
        blue: { primary: 2450411, secondary: 988970, accent: 16436245, led: 3718648 },
        white: { primary: 16317180, secondary: 3359061, accent: 1096065, led: 1096065 }
      }[robotColorPreset] || { primary: 16733440, secondary: 2565930, accent: 15000807, led: 58879 };
      const primaryMat = new THREE.MeshStandardMaterial({
        color: colorPalette.primary,
        metalness: robotColorPreset === "silver" ? 0.8 : 0.2,
        roughness: 0.3,
        wireframe: wireframeMode
      });
      const jointMat = new THREE.MeshStandardMaterial({
        color: colorPalette.secondary,
        metalness: 0.8,
        roughness: 0.25,
        wireframe: wireframeMode
      });
      const chromeMat = new THREE.MeshStandardMaterial({
        color: colorPalette.accent,
        metalness: 0.95,
        roughness: 0.1,
        wireframe: wireframeMode
      });
      const ledMat = new THREE.MeshBasicMaterial({ color: colorPalette.led });
      const tcpMat = new THREE.MeshBasicMaterial({ color: 13172480 });
      const baseFlange = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 0.08, 32), jointMat);
      baseFlange.position.y = 0.04;
      baseFlange.castShadow = true;
      baseFlange.receiveShadow = true;
      scene.add(baseFlange);
      const baseTurret = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 0.08, 32), primaryMat);
      baseTurret.position.y = 0.12;
      baseTurret.castShadow = true;
      scene.add(baseTurret);
      const baseGlowRing = new THREE.Mesh(new THREE.TorusGeometry(0.21, 8e-3, 16, 32), ledMat);
      baseGlowRing.rotation.x = Math.PI / 2;
      baseGlowRing.position.y = 0.15;
      scene.add(baseGlowRing);
      const j1Group = new THREE.Group();
      j1Group.position.y = 0.16;
      scene.add(j1Group);
      const shoulderYoke = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.32, 0.18), jointMat);
      shoulderYoke.position.y = 0.16;
      shoulderYoke.castShadow = true;
      j1Group.add(shoulderYoke);
      const shoulderHubL = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.22, 24), chromeMat);
      shoulderHubL.rotation.z = Math.PI / 2;
      shoulderHubL.position.set(0, 0.26, 0);
      j1Group.add(shoulderHubL);
      const j2Group = new THREE.Group();
      j2Group.position.set(0, 0.26, 0);
      j1Group.add(j2Group);
      const upperArm = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.52, 0.13), primaryMat);
      upperArm.position.y = 0.26;
      upperArm.castShadow = true;
      j2Group.add(upperArm);
      const armStripe = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.24, 0.04), chromeMat);
      armStripe.position.set(0, 0.26, 0.05);
      j2Group.add(armStripe);
      const j3Group = new THREE.Group();
      j3Group.position.set(0, 0.52, 0);
      j2Group.add(j3Group);
      const elbowHub = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.18, 24), jointMat);
      elbowHub.rotation.x = Math.PI / 2;
      elbowHub.position.y = 0;
      elbowHub.castShadow = true;
      j3Group.add(elbowHub);
      const forearm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.44, 0.1), primaryMat);
      forearm.position.y = 0.22;
      forearm.castShadow = true;
      j3Group.add(forearm);
      const j4Group = new THREE.Group();
      j4Group.position.set(0, 0.44, 0);
      j3Group.add(j4Group);
      const wristRollCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.08, 24), jointMat);
      wristRollCyl.position.y = 0.04;
      wristRollCyl.castShadow = true;
      j4Group.add(wristRollCyl);
      const j5Group = new THREE.Group();
      j5Group.position.set(0, 0.08, 0);
      j4Group.add(j5Group);
      const wristPitchHub = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.12, 24), chromeMat);
      wristPitchHub.rotation.z = Math.PI / 2;
      wristPitchHub.position.y = 0.03;
      j5Group.add(wristPitchHub);
      const j6Group = new THREE.Group();
      j6Group.position.set(0, 0.06, 0);
      j5Group.add(j6Group);
      const toolFlange = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.04, 24), jointMat);
      toolFlange.position.y = 0.02;
      j6Group.add(toolFlange);
      const gripperBase = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.04, 0.04), primaryMat);
      gripperBase.position.y = 0.05;
      gripperBase.castShadow = true;
      j6Group.add(gripperBase);
      const fingerLeft = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.07, 0.02), jointMat);
      fingerLeft.position.set(-0.025, 0.09, 0);
      fingerLeft.castShadow = true;
      j6Group.add(fingerLeft);
      const fingerRight = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.07, 0.02), jointMat);
      fingerRight.position.set(0.025, 0.09, 0);
      fingerRight.castShadow = true;
      j6Group.add(fingerRight);
      const tcpDot = new THREE.Mesh(new THREE.SphereGeometry(0.012, 16, 16), tcpMat);
      tcpDot.position.set(0, 0.14, 0);
      j6Group.add(tcpDot);
      if (showAxes) {
        const axes = new THREE.AxesHelper(0.16);
        axes.position.set(0, 0.14, 0);
        j6Group.add(axes);
      }
      let simTick = 0;
      let animId = null;
      const animate = () => {
        animId = requestAnimationFrame(animate);
        if (controls) controls.update();
        if (isRunning) {
          simTick += 0.02;
          j1Group.rotation.y = jointAngles[0] + Math.sin(simTick * 0.8) * 0.25;
          j2Group.rotation.z = jointAngles[1] + Math.sin(simTick * 1.1) * 0.18;
          j3Group.rotation.z = jointAngles[2] + Math.cos(simTick * 1.4) * 0.15;
          j4Group.rotation.y = jointAngles[3];
          j5Group.rotation.z = jointAngles[4] + Math.sin(simTick * 2) * 0.1;
          j6Group.rotation.y = jointAngles[5];
          setJ1Torque(parseFloat((14.2 + Math.sin(simTick * 0.8) * 3.4).toFixed(1)));
          setJ2Torque(parseFloat((8.7 + Math.cos(simTick * 1.1) * 2.1).toFixed(1)));
        } else {
          j1Group.rotation.y = jointAngles[0];
          j2Group.rotation.z = jointAngles[1];
          j3Group.rotation.z = jointAngles[2];
          j4Group.rotation.y = jointAngles[3];
          j5Group.rotation.z = jointAngles[4];
          j6Group.rotation.y = jointAngles[5];
        }
        renderer.render(scene, camera);
      };
      animate();
      const handleResize = () => {
        if (!container) return;
        camera.aspect = container.clientWidth / container.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.clientWidth, container.clientHeight);
      };
      window.addEventListener("resize", handleResize);
      return () => {
        cancelAnimationFrame(animId);
        window.removeEventListener("resize", handleResize);
        renderer.dispose();
      };
    }, [activeActivity, isRunning, jointAngles, cameraPreset, showGrid, showAxes, theme, robotColorPreset, lightingBrightness, wireframeMode]);
    const j1HistoryRef = useRef(new Array(120).fill(0));
    const j2HistoryRef = useRef(new Array(120).fill(0));
    useEffect(() => {
      if (activeActivity !== "explorer") return;
      let animId = null;
      let simTick = 0;
      const renderCharts = () => {
        animId = requestAnimationFrame(renderCharts);
        simTick += 0.03;
        let j1Current = jointAngles[0];
        let j2Current = jointAngles[1];
        if (isRunning) {
          j1Current += Math.sin(simTick * 0.8) * 0.35 + (Math.random() - 0.5) * 6e-3;
          j2Current += Math.sin(simTick * 1.2) * 0.25 + (Math.random() - 0.5) * 6e-3;
        } else {
          j1Current += (Math.random() - 0.5) * 3e-3;
          j2Current += (Math.random() - 0.5) * 3e-3;
        }
        j1HistoryRef.current.push(j1Current);
        if (j1HistoryRef.current.length > 120) j1HistoryRef.current.shift();
        j2HistoryRef.current.push(j2Current);
        if (j2HistoryRef.current.length > 120) j2HistoryRef.current.shift();
        const channels = [
          { canvas: chartJ1Ref.current, buffer: j1HistoryRef.current, color: "#ff3d00", label: "J1 Base Yaw", currentVal: j1Current, torque: j1Torque },
          { canvas: chartJ2Ref.current, buffer: j2HistoryRef.current, color: "#c8ff00", label: "J2 Shoulder Pitch", currentVal: j2Current, torque: j2Torque }
        ];
        channels.forEach(({ canvas, buffer, color }) => {
          if (!canvas) return;
          const ctx = canvas.getContext("2d");
          if (!ctx) return;
          const dpr = window.devicePixelRatio || 1;
          const rect = canvas.getBoundingClientRect();
          if (rect.width === 0 || rect.height === 0) return;
          if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
          }
          const w = canvas.width;
          const h = canvas.height;
          ctx.fillStyle = theme === "light" ? "#ffffff" : theme === "industrial" ? "#181b24" : theme === "cyberpunk" ? "#0c071d" : "#07080d";
          ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = theme === "light" ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.04)";
          ctx.lineWidth = 1 * dpr;
          for (let x = 0; x < w; x += 30 * dpr) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
            ctx.stroke();
          }
          for (let y = 0; y < h; y += 18 * dpr) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
          }
          ctx.strokeStyle = theme === "light" ? "rgba(0,0,0,0.12)" : "rgba(255,255,255,0.12)";
          ctx.setLineDash([4 * dpr, 4 * dpr]);
          ctx.beginPath();
          ctx.moveTo(0, h / 2);
          ctx.lineTo(w, h / 2);
          ctx.stroke();
          ctx.setLineDash([]);
          if (buffer.length > 1) {
            const stepX = w / (buffer.length - 1);
            const midY = h / 2;
            const scaleY = h * 0.38;
            const grad = ctx.createLinearGradient(0, 0, 0, h);
            grad.addColorStop(0, color === "#ff3d00" ? "rgba(255, 61, 0, 0.22)" : "rgba(200, 255, 0, 0.22)");
            grad.addColorStop(1, theme === "light" ? "rgba(255, 255, 255, 0.0)" : "rgba(7, 8, 13, 0.0)");
            ctx.beginPath();
            ctx.moveTo(0, midY);
            for (let i = 0; i < buffer.length; i++) {
              const x = i * stepX;
              const y = midY - buffer[i] * scaleY;
              ctx.lineTo(x, y);
            }
            ctx.lineTo(w, midY);
            ctx.closePath();
            ctx.fillStyle = grad;
            ctx.fill();
            ctx.strokeStyle = color;
            ctx.lineWidth = 2 * dpr;
            ctx.shadowColor = color;
            ctx.shadowBlur = 4 * dpr;
            ctx.beginPath();
            for (let i = 0; i < buffer.length; i++) {
              const x = i * stepX;
              const y = midY - buffer[i] * scaleY;
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            }
            ctx.stroke();
            ctx.shadowBlur = 0;
          }
        });
      };
      renderCharts();
      return () => {
        if (animId) cancelAnimationFrame(animId);
      };
    }, [activeActivity, isRunning, jointAngles, j1Torque, j2Torque, theme]);
    useEffect(() => {
      if (activeActivity !== "ai" || !curvesCanvasRef.current) return;
      const canvas = curvesCanvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
      }
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = theme === "light" ? "#ffffff" : theme === "industrial" ? "#181b24" : theme === "cyberpunk" ? "#0c071d" : "#07080d";
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = theme === "light" ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.04)";
      ctx.lineWidth = 1 * dpr;
      for (let y = h * 0.2; y < h; y += h * 0.2) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      for (let x = w * 0.2; x < w; x += w * 0.2) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      const gradSuccess = ctx.createLinearGradient(0, 0, 0, h);
      gradSuccess.addColorStop(0, theme === "light" ? "rgba(2, 132, 199, 0.25)" : "rgba(0, 212, 255, 0.25)");
      gradSuccess.addColorStop(1, "rgba(0, 212, 255, 0.0)");
      ctx.beginPath();
      ctx.moveTo(12 * dpr, h * 0.82);
      ctx.bezierCurveTo(w * 0.25, h * 0.68, w * 0.55, h * 0.28, w - 14 * dpr, h * 0.14);
      ctx.lineTo(w - 14 * dpr, h);
      ctx.lineTo(12 * dpr, h);
      ctx.closePath();
      ctx.fillStyle = gradSuccess;
      ctx.fill();
      ctx.strokeStyle = theme === "light" ? "#0284c7" : "#00d4ff";
      ctx.lineWidth = 2.5 * dpr;
      ctx.shadowColor = theme === "light" ? "rgba(2, 132, 199, 0.4)" : "rgba(0, 212, 255, 0.6)";
      ctx.shadowBlur = 8 * dpr;
      ctx.beginPath();
      ctx.moveTo(12 * dpr, h * 0.82);
      ctx.bezierCurveTo(w * 0.25, h * 0.68, w * 0.55, h * 0.28, w - 14 * dpr, h * 0.14);
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = theme === "light" ? "#ea580c" : "#ff3d00";
      ctx.lineWidth = 2.5 * dpr;
      ctx.setLineDash([5 * dpr, 4 * dpr]);
      ctx.shadowColor = "rgba(255, 61, 0, 0.5)";
      ctx.shadowBlur = 6 * dpr;
      ctx.beginPath();
      ctx.moveTo(12 * dpr, h * 0.18);
      ctx.bezierCurveTo(w * 0.28, h * 0.42, w * 0.62, h * 0.74, w - 14 * dpr, h * 0.86);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.shadowBlur = 0;
      const markers = [
        { x: 12 * dpr, y: h * 0.82, label: "62.0%" },
        { x: w * 0.5, y: h * 0.38, label: "84.5%" },
        { x: w - 14 * dpr, y: h * 0.14, label: `${successRate}%` }
      ];
      markers.forEach((m) => {
        ctx.fillStyle = theme === "light" ? "#0284c7" : "#00d4ff";
        ctx.beginPath();
        ctx.arc(m.x, m.y, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = theme === "light" ? "#334155" : "#cbd5e1";
        ctx.font = `${9 * dpr}px JetBrains Mono, monospace`;
        ctx.fillText(m.label, m.x - 12 * dpr, m.y - 8 * dpr);
      });
    }, [activeActivity, cycleCount, semanticLoss, successRate, theme]);
    useEffect(() => {
      if (activeActivity !== "ai" || !topoCanvasRef.current) return;
      const canvas = topoCanvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      let animId = null;
      let graphTick = 0;
      const tiers = [
        { id: "T1", name: "1. Episodic Traces", count: "1,842 traces", xRatio: 0.25, yRatio: 0.16, color: theme === "light" ? "#0284c7" : "#00d4ff" },
        { id: "T2", name: "2. Procedural Skills", count: "58 policies", xRatio: 0.75, yRatio: 0.16, color: theme === "light" ? "#16a34a" : "#c8ff00" },
        { id: "T3", name: "3. Semantic Graph", count: "420 entities", xRatio: 0.2, yRatio: 0.48, color: theme === "light" ? "#0369a1" : "#38bdf8" },
        { id: "T7", name: "7. Working Context", count: "4K Tokens Active", xRatio: 0.5, yRatio: 0.48, color: theme === "light" ? "#0f172a" : "#ffffff" },
        { id: "T4", name: "4. POMDP World State", count: "Belief Matrix", xRatio: 0.8, yRatio: 0.48, color: theme === "light" ? "#ea580c" : "#ff3d00" },
        { id: "T5", name: "5. Human Alignment", count: "14 Safety Rules", xRatio: 0.28, yRatio: 0.8, color: theme === "light" ? "#d97706" : "#f59e0b" },
        { id: "T6", name: "6. Meta Calibration", count: "Consistency Matrix", xRatio: 0.72, yRatio: 0.8, color: theme === "light" ? "#9333ea" : "#a855f7" }
      ];
      const edges = [
        [0, 1],
        [0, 3],
        [1, 3],
        [2, 3],
        [3, 4],
        [3, 5],
        [3, 6],
        [5, 6],
        [1, 4]
      ];
      const renderMemoryGraph = () => {
        animId = requestAnimationFrame(renderMemoryGraph);
        graphTick += 0.025;
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          if (canvas.width !== Math.round(rect.width * dpr) || canvas.height !== Math.round(rect.height * dpr)) {
            canvas.width = Math.round(rect.width * dpr);
            canvas.height = Math.round(rect.height * dpr);
          }
        }
        const w = canvas.width;
        const h = canvas.height;
        if (w === 0 || h === 0) return;
        ctx.fillStyle = theme === "light" ? "#f8fafc" : theme === "industrial" ? "#181b24" : theme === "cyberpunk" ? "#0c071d" : "#07080d";
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = theme === "light" ? "rgba(0,0,0,0.05)" : "rgba(255,255,255,0.025)";
        ctx.lineWidth = 1 * dpr;
        for (let y = 0; y < h; y += 28 * dpr) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
        for (let x = 0; x < w; x += 28 * dpr) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, h);
          ctx.stroke();
        }
        const positions = tiers.map((t, idx) => {
          const rawX = w * t.xRatio + Math.sin(graphTick * 0.7 + idx * 1.2) * (3 * dpr);
          const rawY = h * t.yRatio + Math.cos(graphTick * 0.6 + idx * 0.9) * (3 * dpr);
          const x = Math.max(50 * dpr, Math.min(w - 50 * dpr, rawX));
          const y = Math.max(24 * dpr, Math.min(h - 38 * dpr, rawY));
          return { ...t, x, y };
        });
        edges.forEach(([fromIdx, toIdx], edgeIdx) => {
          const from = positions[fromIdx];
          const to = positions[toIdx];
          ctx.strokeStyle = theme === "light" ? "rgba(0, 0, 0, 0.15)" : "rgba(255, 255, 255, 0.15)";
          ctx.lineWidth = 1.2 * dpr;
          ctx.beginPath();
          ctx.moveTo(from.x, from.y);
          ctx.lineTo(to.x, to.y);
          ctx.stroke();
          const progress = (graphTick * 0.4 + edgeIdx * 0.22) % 1;
          const px = from.x + (to.x - from.x) * progress;
          const py = from.y + (to.y - from.y) * progress;
          ctx.fillStyle = from.color;
          ctx.shadowColor = from.color;
          ctx.shadowBlur = 8 * dpr;
          ctx.beginPath();
          ctx.arc(px, py, 2.5 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        });
        positions.forEach((node) => {
          ctx.strokeStyle = node.color;
          ctx.lineWidth = 1.2 * dpr;
          ctx.globalAlpha = 0.35 + Math.sin(graphTick * 2) * 0.15;
          ctx.beginPath();
          ctx.arc(node.x, node.y, 14 * dpr, 0, Math.PI * 2);
          ctx.stroke();
          ctx.globalAlpha = 1;
          ctx.fillStyle = node.color;
          ctx.shadowColor = node.color;
          ctx.shadowBlur = 10 * dpr;
          ctx.beginPath();
          ctx.arc(node.x, node.y, 6 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
          ctx.fillStyle = theme === "light" ? "#0f172a" : "#ffffff";
          ctx.font = `bold ${10 * dpr}px Inter, sans-serif`;
          ctx.textAlign = "center";
          ctx.fillText(node.name, node.x, node.y + 20 * dpr);
          ctx.fillStyle = theme === "light" ? "#64748b" : "#94a3b8";
          ctx.font = `${8.5 * dpr}px JetBrains Mono, monospace`;
          ctx.fillText(node.count, node.x, node.y + 30 * dpr);
        });
      };
      renderMemoryGraph();
      return () => {
        if (animId) cancelAnimationFrame(animId);
      };
    }, [activeActivity, theme]);
    useEffect(() => {
      if (activeActivity !== "cad" || !threeCadMountRef.current) return;
      const container = threeCadMountRef.current;
      container.innerHTML = "";
      const THREE2 = window.THREE;
      if (!THREE2) return;
      const scene = new THREE2.Scene();
      scene.background = new THREE2.Color(curTheme.sceneBg);
      const camera = new THREE2.PerspectiveCamera(40, container.clientWidth / container.clientHeight, 0.05, 50);
      if (cadCameraPreset === "top") {
        camera.position.set(0, 3.2, 0.01);
        camera.lookAt(0, 0, 0);
      } else if (cadCameraPreset === "front") {
        camera.position.set(0, 0.9, 2.8);
        camera.lookAt(0, 0.9, 0);
      } else if (cadCameraPreset === "side") {
        camera.position.set(2.8, 0.9, 0);
        camera.lookAt(0, 0.9, 0);
      } else if (cadCameraPreset === "iso") {
        camera.position.set(2, 2, 2);
        camera.lookAt(0, 0.8, 0);
      } else {
        camera.position.set(1.5, 1.3, 1.8);
        camera.lookAt(0, 0.8, 0);
      }
      const renderer = new THREE2.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(container.clientWidth, container.clientHeight);
      renderer.setPixelRatio(window.devicePixelRatio || 1);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE2.PCFSoftShadowMap;
      container.appendChild(renderer.domElement);
      let controls = null;
      if (THREE2.OrbitControls) {
        controls = new THREE2.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.06;
        controls.target.set(0, 0.8, 0);
      }
      const amb = new THREE2.AmbientLight(16777215, 1.3);
      scene.add(amb);
      const key = new THREE2.DirectionalLight(16777215, 1.8);
      key.position.set(3, 5, 3);
      scene.add(key);
      const fill = new THREE2.DirectionalLight(8961023, 0.9);
      fill.position.set(-3, 3, -3);
      scene.add(fill);
      const rim = new THREE2.DirectionalLight(16777215, 0.7);
      rim.position.set(0, 4, -4);
      scene.add(rim);
      if (cadShowGrid) {
        const grid = new THREE2.GridHelper(3, 30, curTheme.gridCenter, curTheme.gridColor);
        grid.position.y = 0;
        scene.add(grid);
      }
      if (cadShowAxes) {
        const axes = new THREE2.AxesHelper(0.35);
        scene.add(axes);
      }
      const materialsMeta = {
        aluminum: { color: 9741240, metalness: 0.85, roughness: 0.25 },
        carbon_fiber: { color: 1579035, metalness: 0.3, roughness: 0.5 },
        steel: { color: 6583435, metalness: 0.9, roughness: 0.2 },
        titanium: { color: 4674921, metalness: 0.8, roughness: 0.35 },
        polymer: { color: 16737792, metalness: 0.1, roughness: 0.4 }
      };
      cadParts.forEach((part, index) => {
        if (!part.visible) return;
        let geo;
        if (part.shape === "cylinder") {
          geo = new THREE2.CylinderGeometry(part.dimX / 2, part.dimZ / 2, part.dimY, 32);
        } else if (part.shape === "sphere") {
          geo = new THREE2.SphereGeometry(part.dimX / 2, 24, 24);
        } else if (part.shape === "tube") {
          geo = new THREE2.CylinderGeometry(part.dimX / 2, part.dimX / 2, part.dimY, 24, 1, true);
        } else if (part.shape === "flange") {
          geo = new THREE2.CylinderGeometry(part.dimX / 2, part.dimX / 2 * 1.15, part.dimY, 32);
        } else if (part.shape === "gripper_finger") {
          geo = new THREE2.BoxGeometry(part.dimX, part.dimY, part.dimZ);
        } else {
          geo = new THREE2.BoxGeometry(part.dimX, part.dimY, part.dimZ);
        }
        const matProps = materialsMeta[part.material] || materialsMeta.aluminum;
        const isSelected = part.id === selectedCadPartId;
        let mat;
        if (cadShadingMode === "wireframe") {
          mat = new THREE2.MeshBasicMaterial({ color: isSelected ? 54527 : part.color ? parseInt(part.color.replace("#", "0x")) : matProps.color, wireframe: true });
        } else if (cadShadingMode === "xray") {
          mat = new THREE2.MeshStandardMaterial({
            color: isSelected ? 54527 : part.color ? parseInt(part.color.replace("#", "0x")) : matProps.color,
            transparent: true,
            opacity: isSelected ? 0.85 : 0.35,
            metalness: matProps.metalness,
            roughness: matProps.roughness,
            wireframe: isSelected
          });
        } else {
          mat = new THREE2.MeshStandardMaterial({
            color: part.color ? parseInt(part.color.replace("#", "0x")) : matProps.color,
            metalness: matProps.metalness,
            roughness: matProps.roughness,
            wireframe: part.wireframe
          });
        }
        const mesh = new THREE2.Mesh(geo, mat);
        const explodeY = index * (cadExplodeFactor * 0.08);
        mesh.position.set(part.posX, part.posY + explodeY, part.posZ);
        mesh.rotation.set(
          THREE2.MathUtils.degToRad(part.rotX),
          THREE2.MathUtils.degToRad(part.rotY),
          THREE2.MathUtils.degToRad(part.rotZ)
        );
        if (isSelected) {
          const bbox = new THREE2.BoxHelper(mesh, 54527);
          scene.add(bbox);
        }
        scene.add(mesh);
      });
      let animId;
      const animate = () => {
        animId = requestAnimationFrame(animate);
        if (controls) controls.update();
        renderer.render(scene, camera);
      };
      animate();
      const handleResize = () => {
        if (!container) return;
        camera.aspect = container.clientWidth / container.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.clientWidth, container.clientHeight);
      };
      window.addEventListener("resize", handleResize);
      return () => {
        cancelAnimationFrame(animId);
        window.removeEventListener("resize", handleResize);
        if (renderer.domElement && container.contains(renderer.domElement)) {
          container.removeChild(renderer.domElement);
        }
        renderer.dispose();
      };
    }, [activeActivity, cadParts, selectedCadPartId, cadShadingMode, cadCameraPreset, cadShowGrid, cadShowAxes, cadExplodeFactor, curTheme]);
    useEffect(() => {
      if (activeActivity !== "telemetry") return;
      let animId = null;
      let tick = 0;
      const renderTelemetryChannels = () => {
        animId = requestAnimationFrame(renderTelemetryChannels);
        tick += 0.04;
        const channels = [
          { canvas: sigCanvasRefA.current, color: "#ff3d00", freq: 1.2, amp: 0.35 },
          { canvas: sigCanvasRefB.current, color: "#c8ff00", freq: 2, amp: 0.3 },
          { canvas: sigCanvasRefC.current, color: "#00d4ff", freq: 3.5, amp: 0.2 },
          { canvas: sigCanvasRefD.current, color: "#a855f7", freq: 6, amp: 0.28 }
        ];
        channels.forEach(({ canvas, color, freq, amp }) => {
          if (!canvas) return;
          const ctx = canvas.getContext("2d");
          if (!ctx) return;
          const dpr = window.devicePixelRatio || 1;
          const rect = canvas.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            if (canvas.width !== Math.round(rect.width * dpr) || canvas.height !== Math.round(rect.height * dpr)) {
              canvas.width = Math.round(rect.width * dpr);
              canvas.height = Math.round(rect.height * dpr);
            }
          }
          const w = canvas.width;
          const h = canvas.height;
          if (w === 0 || h === 0) return;
          ctx.fillStyle = "#07080d";
          ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = "rgba(255,255,255,0.035)";
          ctx.lineWidth = 1 * dpr;
          for (let x = 0; x < w; x += 32 * dpr) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
            ctx.stroke();
          }
          for (let y = 0; y < h; y += 20 * dpr) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
          }
          ctx.strokeStyle = "rgba(255,255,255,0.1)";
          ctx.setLineDash([4 * dpr, 4 * dpr]);
          ctx.beginPath();
          ctx.moveTo(0, h / 2);
          ctx.lineTo(w, h / 2);
          ctx.stroke();
          ctx.setLineDash([]);
          const midY = h / 2;
          const scaleY = h * amp;
          const grad = ctx.createLinearGradient(0, 0, 0, h);
          grad.addColorStop(0, `${color}33`);
          grad.addColorStop(1, "rgba(7, 8, 13, 0.0)");
          ctx.beginPath();
          ctx.moveTo(0, midY);
          for (let x = 0; x <= w; x += 2 * dpr) {
            const y = midY - Math.sin(x / w * Math.PI * freq * 4 + tick) * scaleY - (Math.random() - 0.5) * (4 * dpr);
            ctx.lineTo(x, y);
          }
          ctx.lineTo(w, midY);
          ctx.closePath();
          ctx.fillStyle = grad;
          ctx.fill();
          ctx.strokeStyle = color;
          ctx.lineWidth = 2 * dpr;
          ctx.shadowColor = color;
          ctx.shadowBlur = 6 * dpr;
          ctx.beginPath();
          for (let x = 0; x <= w; x += 2 * dpr) {
            const y = midY - Math.sin(x / w * Math.PI * freq * 4 + tick) * scaleY - (Math.random() - 0.5) * (4 * dpr);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
          ctx.shadowBlur = 0;
        });
      };
      renderTelemetryChannels();
      return () => {
        if (animId) cancelAnimationFrame(animId);
      };
    }, [activeActivity]);
    return /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", height: "100vh", backgroundColor: curTheme.bg, color: curTheme.text, fontFamily: "Inter, -apple-system, sans-serif", userSelect: "none" } }, /* @__PURE__ */ window.React.createElement("header", { style: { height: 46, background: curTheme.topBarBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px", zIndex: 100, position: "relative" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 16 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("img", { src: "/logo.png", alt: "NeloStrix", style: { width: 24, height: 24, borderRadius: 5, boxShadow: `0 0 10px ${curTheme.accentGlow}` } }), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, letterSpacing: "0.5px", color: curTheme.text } }, "NELOSTRIX ", /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.secondary } }, "IDE")), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowKernelModal(true),
        style: { background: curTheme.accentGlow, color: curTheme.accent, border: `1px solid ${curTheme.accent}`, borderRadius: 3, padding: "2px 6px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 },
        title: "Click to view NIL-STACC In-Device Kernel Status"
      },
      /* @__PURE__ */ window.React.createElement("div", { style: { width: 5, height: 5, borderRadius: "50%", background: curTheme.accent, boxShadow: `0 0 6px ${curTheme.accent}` } }),
      /* @__PURE__ */ window.React.createElement("span", null, "NIL-STACC KERNEL")
    )), /* @__PURE__ */ window.React.createElement("nav", { style: { display: "flex", gap: 2, position: "relative" } }, [
      {
        name: "File",
        items: [
          { label: "New STACC Script (.py)", shortcut: "Ctrl+N", action: () => {
            const name = `controller_v${Object.keys(codeFiles).length + 1}.py`;
            setCodeFiles((prev) => ({ ...prev, [name]: `# STACC In-Device Controller
import stacc.core as stacc
import stacc.hal as hal

robot = stacc.Robot.from_rir("workspace/models/nelostrix_arm_6dof.rir")
hal_bus = hal.SharedMemoryBus("stacc_main", frequency=1000)
` }));
            setActiveEditorTab(name);
            showToast(`Created new script: ${name}`);
          } },
          { label: "New RIR Robot Model (.rir)", shortcut: "Ctrl+Shift+N", action: () => {
            const name = `robot_custom_${Object.keys(codeFiles).length + 1}.rir`;
            setCodeFiles((prev) => ({ ...prev, [name]: `<?xml version="1.0"?>
<robot name="custom_manipulator">
  <link name="base_link">
    <inertial mass="12.0" />
  </link>
</robot>` }));
            setActiveEditorTab(name);
            showToast(`Created new model: ${name}`);
          } },
          { divider: true },
          { label: "Save Active File", shortcut: "Ctrl+S", action: () => showToast(`Saved ${activeEditorTab} to local disk`) },
          { label: "Export Workspace Snapshot (.tar.gz)", shortcut: "Ctrl+Shift+E", action: () => {
            window.location.href = "/dist/NELO-Studio-v1.0.0-linux-x86_64.tar.gz";
            showToast("Exporting workspace archive...");
          } },
          { divider: true },
          { label: "Reload In-Device Kernel", shortcut: "Ctrl+R", action: () => window.location.reload() }
        ]
      },
      {
        name: "Edit",
        items: [
          { label: "Undo", shortcut: "Ctrl+Z", action: () => showToast("Undo executed") },
          { label: "Redo", shortcut: "Ctrl+Y", action: () => showToast("Redo executed") },
          { divider: true },
          { label: "Cut", shortcut: "Ctrl+X", action: () => showToast("Cut to clipboard") },
          { label: "Copy", shortcut: "Ctrl+C", action: () => showToast("Copied to clipboard") },
          { label: "Select All", shortcut: "Ctrl+A", action: () => showToast("All code selected") },
          { divider: true },
          { label: "Format Code (Ruff / Black)", shortcut: "Shift+Alt+F", action: () => showToast("Formatted active file with Ruff") }
        ]
      },
      {
        name: "View",
        items: [
          { label: "IDE & 3D Simulation", shortcut: "Ctrl+1", action: () => setActiveActivity("explorer") },
          { label: "3D Parametric CAD Studio", shortcut: "Ctrl+2", action: () => setActiveActivity("cad") },
          { label: "Robotics & Kinematics Jogger", shortcut: "Ctrl+3", action: () => setActiveActivity("robotics") },
          { label: "STACC HAL Bus & Actuators", shortcut: "Ctrl+4", action: () => setActiveActivity("hardware") },
          { label: "NIL AI & Self-Evolution", shortcut: "Ctrl+5", action: () => setActiveActivity("ai") },
          { label: "High-Speed Signals & Telemetry", shortcut: "Ctrl+6", action: () => setActiveActivity("telemetry") },
          { label: "Digital Twin & In-Device Compute", shortcut: "Ctrl+7", action: () => setActiveActivity("twin") },
          { divider: true },
          { label: "Toggle NIL AI Copilot Panel", shortcut: "Ctrl+Shift+A", action: () => setShowAIPanel((prev) => !prev) },
          { label: "Toggle Terminal & Telemetry Dock", shortcut: "Ctrl+`", action: () => setShowBottomPanel((prev) => !prev) }
        ]
      },
      {
        name: "Robotics",
        items: [
          { label: "Start NIL-STACC Simulation", shortcut: "F5", action: handleRunCode },
          { label: "Stop / Pause Simulation", shortcut: "Shift+F5", action: handleStopCode },
          { divider: true },
          { label: "Step MuJoCo 1000Hz Physics", shortcut: "F10", action: () => executeTerminalCmd("stacc sim") },
          { label: "Solve Spatial Forward Kinematics", shortcut: "F11", action: () => executeTerminalCmd("stacc fk") },
          { label: "Scan 6-DOF Joint Actuators (J1-J6)", shortcut: "Alt+J", action: () => executeTerminalCmd("stacc hal") },
          { label: "Reset Shared Memory IPC Bus", shortcut: "Ctrl+Shift+R", action: () => showToast("Reset STACC Zero-Copy Shared Memory Bus") }
        ]
      },
      {
        name: "AI & Twin",
        items: [
          { label: "Trigger 7-Stage Self-Evolution", shortcut: "Alt+E", action: handleTriggerEvolution },
          { label: "Inspect 7-Tier Memory Store", shortcut: "Ctrl+M", action: () => setActiveActivity("ai") },
          { label: "Procedural Skills Registry", shortcut: "Alt+K", action: () => executeTerminalCmd("nil skills") },
          { divider: true },
          { label: "Configure AI Providers & API Keys", action: () => setShowAISettingsModal(true) },
          { label: "Export Memory Archive (.nilstore)", action: () => showToast("Exported ~/.nelo/memory/agent_store.nilstore") }
        ]
      },
      {
        name: "Help",
        items: [
          { label: "License & System Activation", action: () => setShowLicenseModal(true) },
          { label: "In-Device Kernel Diagnostics", action: () => setShowKernelModal(true) },
          { label: "NIL-STACC Documentation", action: () => showToast("Documentation: docs.nelostrix.com") },
          { label: "Keyboard Shortcuts", shortcut: "Ctrl+K Ctrl+S", action: () => showToast("Shortcuts: F5=Run, Ctrl+1..7=Views, Ctrl+`=Terminal") },
          { divider: true },
          { label: "About NIL Studio v1.0.0", action: () => showToast("NIL Studio v1.0.0 \u2014 AI-Native Robotics Engineering OS") }
        ]
      }
    ].map((menu) => /* @__PURE__ */ window.React.createElement("div", { key: menu.name, style: { position: "relative" } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        className: "menu-trigger-btn",
        onClick: () => setOpenMenu(openMenu === menu.name ? null : menu.name),
        onMouseEnter: () => {
          if (openMenu) setOpenMenu(menu.name);
        },
        style: {
          background: openMenu === menu.name ? curTheme.accentGlow : "transparent",
          border: "none",
          color: openMenu === menu.name ? curTheme.accent : curTheme.textMuted,
          fontSize: 12,
          fontWeight: 600,
          padding: "4px 8px",
          borderRadius: 4,
          cursor: "pointer",
          transition: "all 0.1s ease"
        }
      },
      menu.name
    ), openMenu === menu.name && /* @__PURE__ */ window.React.createElement(
      "div",
      {
        className: "menu-dropdown-container",
        style: {
          position: "absolute",
          top: "100%",
          left: 0,
          marginTop: 4,
          background: curTheme.panelBg,
          border: `1px solid ${curTheme.borderStrong}`,
          borderRadius: 6,
          boxShadow: "0 12px 32px rgba(0,0,0,0.4), 0 0 1px rgba(255,255,255,0.2)",
          minWidth: 240,
          padding: "5px 0",
          zIndex: 1e3
        }
      },
      menu.items.map((item, idx) => item.divider ? /* @__PURE__ */ window.React.createElement("div", { key: `div-${idx}`, style: { height: 1, background: curTheme.border, margin: "5px 0" } }) : /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: item.label,
          onClick: () => {
            setOpenMenu(null);
            item.action && item.action();
          },
          style: {
            width: "100%",
            background: "transparent",
            border: "none",
            padding: "6px 14px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            color: curTheme.text,
            fontSize: 12,
            textAlign: "left",
            cursor: "pointer",
            transition: "background 0.1s"
          },
          onMouseEnter: (e) => {
            e.currentTarget.style.background = curTheme.cardBg;
            e.currentTarget.style.color = curTheme.accent;
          },
          onMouseLeave: (e) => {
            e.currentTarget.style.background = "transparent";
            e.currentTarget.style.color = curTheme.text;
          }
        },
        /* @__PURE__ */ window.React.createElement("span", null, item.label),
        item.shortcut && /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textSubtle, fontFamily: "JetBrains Mono", fontSize: 10 } }, item.shortcut)
      ))
    ))))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { position: "relative" } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setOpenMenu(openMenu === "theme" ? null : "theme"),
        style: {
          background: curTheme.cardBg,
          border: `1px solid ${curTheme.borderStrong}`,
          color: curTheme.text,
          borderRadius: 4,
          padding: "4px 9px",
          fontSize: 11,
          fontFamily: "JetBrains Mono",
          fontWeight: 600,
          display: "flex",
          alignItems: "center",
          gap: 6,
          cursor: "pointer"
        },
        title: "Switch Visual Theme"
      },
      (() => {
        const ThemeIcon = themeConfig[theme].icon;
        return /* @__PURE__ */ window.React.createElement(ThemeIcon, { size: 12, color: curTheme.accent });
      })(),
      /* @__PURE__ */ window.React.createElement("span", null, themeConfig[theme].name),
      /* @__PURE__ */ window.React.createElement(Icons.ChevronDown, { size: 10, color: curTheme.textMuted })
    ), openMenu === "theme" && /* @__PURE__ */ window.React.createElement(
      "div",
      {
        style: {
          position: "absolute",
          top: "100%",
          right: 0,
          marginTop: 4,
          background: curTheme.panelBg,
          border: `1px solid ${curTheme.borderStrong}`,
          borderRadius: 6,
          boxShadow: "0 12px 32px rgba(0,0,0,0.4)",
          minWidth: 160,
          padding: "4px 0",
          zIndex: 1e3
        }
      },
      Object.keys(themeConfig).map((tKey) => {
        const ItemThemeIcon = themeConfig[tKey].icon;
        return /* @__PURE__ */ window.React.createElement(
          "button",
          {
            key: tKey,
            onClick: () => {
              setTheme(tKey);
              setOpenMenu(null);
              showToast(`Theme: ${themeConfig[tKey].name}`);
            },
            style: {
              width: "100%",
              background: theme === tKey ? curTheme.accentGlow : "transparent",
              border: "none",
              padding: "6px 12px",
              display: "flex",
              alignItems: "center",
              gap: 8,
              color: theme === tKey ? curTheme.accent : curTheme.text,
              fontSize: 11,
              fontFamily: "JetBrains Mono",
              fontWeight: 600,
              cursor: "pointer",
              textAlign: "left"
            }
          },
          /* @__PURE__ */ window.React.createElement(ItemThemeIcon, { size: 13, color: theme === tKey ? curTheme.accent : curTheme.textMuted }),
          /* @__PURE__ */ window.React.createElement("span", null, themeConfig[tKey].name),
          theme === tKey && /* @__PURE__ */ window.React.createElement("span", { style: { marginLeft: "auto" } }, /* @__PURE__ */ window.React.createElement(Icons.Check, { size: 12, color: curTheme.accent }))
        );
      })
    )), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setShowLicenseModal(true),
        style: {
          display: "flex",
          alignItems: "center",
          gap: 5,
          background: licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? "rgba(0,212,255,0.08)" : "rgba(255,170,0,0.08)",
          border: `1px solid ${licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? "rgba(0,212,255,0.3)" : "rgba(255,170,0,0.3)"}`,
          borderRadius: 4,
          padding: "4px 8px",
          cursor: "pointer"
        },
        title: "Manage NIL Studio License & Cross-Platform Package"
      },
      /* @__PURE__ */ window.React.createElement(Icons.ShieldCheck, { size: 11, color: licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? curTheme.accent : "#ffaa00" }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? curTheme.accent : "#ffaa00" } }, licenseInfo?.tier ? licenseInfo.tier.toUpperCase() : "COMMUNITY")
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setShowKernelModal(true),
        style: { display: "flex", alignItems: "center", gap: 5, background: "rgba(200,255,0,0.08)", border: "1px solid rgba(200,255,0,0.3)", borderRadius: 4, padding: "4px 8px", cursor: "pointer" },
        title: "STACC 1000Hz In-Device HAL Kernel is Nominal"
      },
      /* @__PURE__ */ window.React.createElement("div", { style: { width: 6, height: 6, borderRadius: "50%", background: "#c8ff00", animation: "pulse 1.5s infinite" } }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.success } }, "1000Hz HAL")
    ), /* @__PURE__ */ window.React.createElement("div", { style: { height: 18, width: 1, background: curTheme.border, margin: "0 2px" } }), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleRunCode,
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, fontSize: 11, fontWeight: 700, padding: "5px 12px", display: "flex", alignItems: "center", gap: 5, cursor: "pointer", boxShadow: `0 0 10px ${curTheme.accentGlow}` },
        title: "Run controller script in 1000Hz STACC physics loop (F5)"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Play, { size: 11, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Run")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleStopCode,
        style: { background: curTheme.cardBg, color: curTheme.textMuted, border: `1px solid ${curTheme.borderStrong}`, borderRadius: 4, fontSize: 11, fontWeight: 600, padding: "5px 9px", display: "flex", alignItems: "center", gap: 4, cursor: "pointer" },
        title: "Stop / Hold Position"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Stop, { size: 11, color: curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Stop")
    )), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          setShowAIPanel(!showAIPanel);
          showToast(`NIL AI Copilot: ${!showAIPanel ? "Opened" : "Collapsed"}`);
        },
        style: {
          background: showAIPanel ? curTheme.secondary : curTheme.cardBg,
          color: showAIPanel ? "#fff" : curTheme.text,
          border: `1px solid ${showAIPanel ? curTheme.secondary : curTheme.borderStrong}`,
          borderRadius: 4,
          fontSize: 11,
          fontWeight: 700,
          padding: "5px 11px",
          display: "flex",
          alignItems: "center",
          gap: 6,
          cursor: "pointer",
          boxShadow: showAIPanel ? `0 0 10px ${curTheme.accentGlow}` : "none",
          transition: "all 0.15s ease"
        },
        title: "Toggle Right-Side NIL AI Agent Copilot (Ctrl+Shift+A)"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 13, color: showAIPanel ? "#fff" : curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, "NIL Copilot"),
      showAIPanel && /* @__PURE__ */ window.React.createElement("div", { style: { width: 5, height: 5, borderRadius: "50%", background: "#fff" } })
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 12, color: curTheme.textMuted, marginLeft: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { cursor: "pointer" }, onClick: () => setShowAISettingsModal(true), title: "AI & Hardware Settings" }, /* @__PURE__ */ window.React.createElement(Icons.Settings, { size: 15 })), /* @__PURE__ */ window.React.createElement("span", { style: { cursor: "pointer" }, onClick: () => showToast("NIL-STACC SDK: docs.nelostrix.com"), title: "NIL-STACC Docs" }, /* @__PURE__ */ window.React.createElement(Icons.Help, { size: 15 })), /* @__PURE__ */ window.React.createElement("span", { style: { cursor: "pointer" }, onClick: () => showToast("Operator: nelostrix@local-device (Admin)"), title: "User Profile" }, /* @__PURE__ */ window.React.createElement(Icons.User, { size: 15 })))), notification && /* @__PURE__ */ window.React.createElement("div", { style: { position: "fixed", bottom: 24, right: 24, background: "#141622", border: "1px solid #00d4ff", boxShadow: "0 8px 24px rgba(0,212,255,0.25)", color: "#fff", padding: "10px 18px", borderRadius: 6, zIndex: 9999, fontFamily: "JetBrains Mono, monospace", fontSize: 12, display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 6, height: 6, borderRadius: "50%", background: "#00d4ff" } }), /* @__PURE__ */ window.React.createElement("span", null, notification)), showKernelModal && /* @__PURE__ */ window.React.createElement("div", { style: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)", zIndex: 1e4, display: "flex", alignItems: "center", justifyContent: "center" }, onClick: () => setShowKernelModal(false) }, /* @__PURE__ */ window.React.createElement("div", { style: { background: "#0e0f18", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 8, padding: 24, width: 480, boxShadow: "0 20px 50px rgba(0,0,0,0.8)" }, onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: "#fff", display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 8, height: 8, borderRadius: "50%", background: "#00d4ff", boxShadow: "0 0 10px #00d4ff" } }), /* @__PURE__ */ window.React.createElement("span", null, "NIL-STACC In-Device Kernel Diagnostics")), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setShowKernelModal(false), style: { background: "transparent", border: "none", color: "#9090a8", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 15, color: "#9090a8" }))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, fontFamily: "JetBrains Mono, monospace", fontSize: 11, marginBottom: 16 } }, /* @__PURE__ */ window.React.createElement("div", { style: { background: "#141622", padding: 10, borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { color: "#5a5a70" } }, "HAL BUS FREQUENCY"), /* @__PURE__ */ window.React.createElement("div", { style: { color: "#00d4ff", fontWeight: 700, fontSize: 13, marginTop: 2 } }, "1000 Hz (0.018ms)")), /* @__PURE__ */ window.React.createElement("div", { style: { background: "#141622", padding: 10, borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { color: "#5a5a70" } }, "COGNITIVE AGENT"), /* @__PURE__ */ window.React.createElement("div", { style: { color: "#c8ff00", fontWeight: 700, fontSize: 13, marginTop: 2 } }, "nil-nemotron-120b")), /* @__PURE__ */ window.React.createElement("div", { style: { background: "#141622", padding: 10, borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { color: "#5a5a70" } }, "RUNTIME PYTHON"), /* @__PURE__ */ window.React.createElement("div", { style: { color: "#fff", fontWeight: 700, fontSize: 13, marginTop: 2 } }, "Python 3.14.7")), /* @__PURE__ */ window.React.createElement("div", { style: { background: "#141622", padding: 10, borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { color: "#5a5a70" } }, "SHARED MEMORY IPC"), /* @__PURE__ */ window.React.createElement("div", { style: { color: "#00d4ff", fontWeight: 700, fontSize: 13, marginTop: 2 } }, "stacc_main (ACTIVE)"))), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setShowKernelModal(false), style: { width: "100%", background: "#ff3d00", color: "#fff", border: "none", padding: "8px", borderRadius: 4, fontWeight: 700, cursor: "pointer" } }, "Close Diagnostics"))), showAISettingsModal && /* @__PURE__ */ window.React.createElement("div", { style: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(6px)", zIndex: 1e4, display: "flex", alignItems: "center", justifyContent: "center" }, onClick: () => setShowAISettingsModal(false) }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, borderRadius: 8, width: 660, maxWidth: "94vw", maxHeight: "88vh", display: "flex", flexDirection: "column", boxShadow: "0 20px 50px rgba(0,0,0,0.8)", overflow: "hidden" }, onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 48, background: curTheme.cardBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 13, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement(Icons.Settings, { size: 16, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, "NIL AI Model, Custom Providers & User Knowledge")), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setShowAISettingsModal(false), style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 15, color: curTheme.textMuted }))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", borderBottom: `1px solid ${curTheme.border}`, background: curTheme.panelBg } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setSettingsActiveTab("models"),
        style: {
          flex: 1,
          padding: "10px 14px",
          background: settingsActiveTab === "models" ? curTheme.cardBg : "transparent",
          border: "none",
          borderBottom: settingsActiveTab === "models" ? `2px solid ${curTheme.accent}` : "2px solid transparent",
          color: settingsActiveTab === "models" ? curTheme.accent : curTheme.textMuted,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          fontWeight: 700,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 6
        }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Server, { size: 12, color: settingsActiveTab === "models" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Inference Models & Providers")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setSettingsActiveTab("memory"),
        style: {
          flex: 1,
          padding: "10px 14px",
          background: settingsActiveTab === "memory" ? curTheme.cardBg : "transparent",
          border: "none",
          borderBottom: settingsActiveTab === "memory" ? `2px solid ${curTheme.accent}` : "2px solid transparent",
          color: settingsActiveTab === "memory" ? curTheme.accent : curTheme.textMuted,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          fontWeight: 700,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 6
        }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 12, color: settingsActiveTab === "memory" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "User Knowledge & Learning (", aiUserMemories.length, ")")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { padding: 18, overflowY: "auto", display: "flex", flexDirection: "column", gap: 16 } }, settingsActiveTab === "models" && /* @__PURE__ */ window.React.createElement(window.React.Fragment, null, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 6 } }, "INFERENCE ENGINE / PROVIDER MATRIX"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6 } }, [
      { id: "openai", name: "OpenAI", icon: "Globe", title: "OpenAI GPT-4o / o1 / o3-mini / GPT-4.5" },
      { id: "anthropic", name: "Claude", icon: "Sparkles", title: "Anthropic Claude 3.7 / 3.5 Sonnet & Haiku" },
      { id: "gemini", name: "Gemini", icon: "Brain", title: "Google Gemini 2.0 Flash / Pro (1M-2M Context)" },
      { id: "deepseek", name: "DeepSeek", icon: "Zap", title: "DeepSeek V3 / R1 Pure Reinforcement Reasoner" },
      { id: "groq", name: "Groq", icon: "Rocket", title: "Groq Ultra-Fast LPUs (~800 tok/s)" },
      { id: "openrouter", name: "OpenRouter", icon: "Globe", title: "OpenRouter (250+ Live Models & Pricing)" },
      { id: "local", name: "Local Ollama", icon: "Server", title: "Local In-Device (Ollama / GGUF)" },
      { id: "custom", name: "Custom API", icon: "Settings", title: "OpenAI-Compatible / LM Studio / vLLM" }
    ].map((p) => {
      const TabIcon = Icons[p.icon] || Icons.Settings;
      const isSelected = aiProvider === p.id;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: p.id,
          onClick: () => {
            setAiProvider(p.id);
            handleDiscoverModels(p.id);
            setTestConnStatus(null);
          },
          style: {
            padding: "8px 4px",
            background: isSelected ? curTheme.cardBg : "transparent",
            border: isSelected ? `1px solid ${curTheme.accent}` : `1px solid ${curTheme.border}`,
            color: isSelected ? curTheme.accent : curTheme.textMuted,
            borderRadius: 4,
            fontSize: 10,
            fontFamily: "JetBrains Mono",
            fontWeight: isSelected ? 700 : 500,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 5
          },
          title: p.title
        },
        /* @__PURE__ */ window.React.createElement(TabIcon, { size: 11, color: isSelected ? curTheme.accent : curTheme.textMuted }),
        /* @__PURE__ */ window.React.createElement("span", null, p.name)
      );
    }))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 12 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 13, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, fontWeight: 700, color: curTheme.text, fontFamily: "JetBrains Mono", letterSpacing: 0.5 } }, "LIVE MODEL ROUTER \u2014 ", aiProvider.toUpperCase())), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleDiscoverModels(aiProvider),
        disabled: isDiscoveringModels,
        style: {
          background: curTheme.panelBg,
          border: `1px solid ${curTheme.border}`,
          color: curTheme.accent,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 700,
          padding: "3px 8px",
          borderRadius: 3,
          cursor: isDiscoveringModels ? "not-allowed" : "pointer",
          display: "flex",
          alignItems: "center",
          gap: 4
        },
        title: "Fetch fresh live model catalog directly from provider endpoint"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Refresh, { size: 10, color: curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, isDiscoveringModels ? "Querying..." : "Fetch Live Models")
    )), liveDiscoveryStatus && /* @__PURE__ */ window.React.createElement("div", { style: {
      padding: "4px 8px",
      marginBottom: 8,
      borderRadius: 4,
      fontSize: 10,
      fontFamily: "JetBrains Mono",
      background: "rgba(0,212,255,0.08)",
      border: `1px solid rgba(0,212,255,0.3)`,
      color: curTheme.accent,
      display: "flex",
      alignItems: "center",
      gap: 6
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 5, height: 5, borderRadius: "50%", background: curTheme.accent } }), /* @__PURE__ */ window.React.createElement("span", null, liveDiscoveryStatus)), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 6, marginBottom: 8 } }, /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: modelSearchQuery,
        onChange: (e) => setModelSearchQuery(e.target.value),
        placeholder: `Filter ${(providerModelsMap[aiProvider] || []).length} available models (e.g. '3.7', 'o3', 'flash', 'reasoning', 'coding')...`,
        style: {
          flex: 1,
          background: curTheme.panelBg,
          border: `1px solid ${curTheme.borderStrong}`,
          color: curTheme.text,
          padding: "6px 10px",
          borderRadius: 4,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          outline: "none"
        }
      }
    ), modelSearchQuery && /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setModelSearchQuery(""),
        style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "0 6px" }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 12, color: curTheme.textMuted })
    )), /* @__PURE__ */ window.React.createElement("div", { style: {
      display: "flex",
      flexDirection: "column",
      gap: 5,
      maxHeight: 180,
      overflowY: "auto",
      background: curTheme.panelBg,
      border: `1px solid ${curTheme.border}`,
      borderRadius: 4,
      padding: 6
    } }, (() => {
      const activeModels = providerModelsMap[aiProvider] || [];
      const filtered = activeModels.filter((m) => {
        if (!modelSearchQuery.trim()) return true;
        const q = modelSearchQuery.toLowerCase();
        return m.id.toLowerCase().includes(q) || m.name.toLowerCase().includes(q) || m.capabilities && m.capabilities.some((c) => c.toLowerCase().includes(q)) || m.category && m.category.toLowerCase().includes(q);
      });
      if (filtered.length === 0) {
        return /* @__PURE__ */ window.React.createElement("div", { style: { padding: 16, textAlign: "center", color: curTheme.textMuted, fontSize: 10, fontFamily: "JetBrains Mono" } }, "No models match '", modelSearchQuery, "'. Use '+ Set Custom Model' below to route to any custom ID.");
      }
      return filtered.map((m) => {
        const isCur = aiModel === m.id;
        return /* @__PURE__ */ window.React.createElement(
          "div",
          {
            key: m.id,
            onClick: () => {
              setAiModel(m.id);
              showToast(`Active Model: ${m.name}`);
            },
            style: {
              padding: "6px 10px",
              background: isCur ? curTheme.accentGlow : curTheme.cardBg,
              border: isCur ? `1px solid ${curTheme.accent}` : `1px solid ${curTheme.border}`,
              borderRadius: 4,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 8,
              transition: "all 0.1s ease"
            }
          },
          /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: {
            width: 14,
            height: 14,
            borderRadius: "50%",
            border: `1.5px solid ${isCur ? curTheme.accent : curTheme.borderStrong}`,
            background: isCur ? curTheme.accent : "transparent",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0
          } }, isCur && /* @__PURE__ */ window.React.createElement(Icons.Check, { size: 9, color: "#fff" })), /* @__PURE__ */ window.React.createElement("div", { style: { overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 11, fontWeight: isCur ? 800 : 600, color: isCur ? curTheme.accent : curTheme.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, m.name), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textSubtle, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, m.id))),
          /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4, flexShrink: 0 } }, m.context && /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, fontFamily: "JetBrains Mono", fontWeight: 700, padding: "1px 5px", borderRadius: 3, background: "rgba(0,212,255,0.12)", color: curTheme.accent, border: "1px solid rgba(0,212,255,0.2)" } }, m.context), (m.capabilities || []).slice(0, 2).map((cap, cIdx) => /* @__PURE__ */ window.React.createElement("span", { key: cIdx, style: { fontSize: 8, fontFamily: "JetBrains Mono", padding: "1px 4px", borderRadius: 2, background: curTheme.cardBg, color: curTheme.textMuted, border: `1px solid ${curTheme.border}` } }, cap)))
        );
      });
    })()), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 6, marginTop: 8 } }, /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: customModelInput,
        onChange: (e) => setCustomModelInput(e.target.value),
        placeholder: "Or enter any custom / fine-tuned Model ID...",
        style: { flex: 1, background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "6px 10px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, outline: "none" }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleAddCustomModel(),
        disabled: !customModelInput.trim(),
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, padding: "6px 12px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: !customModelInput.trim() ? "not-allowed" : "pointer" }
      },
      "+ Set Custom"
    )), discoveredModels.length > 0 && /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: 8, padding: 8, background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginBottom: 4 } }, "DISCOVERED LIVE MODELS ON ENDPOINT (", discoveredModels.length, "):"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 4, maxHeight: 90, overflowY: "auto" } }, discoveredModels.map((dm, dmIdx) => /* @__PURE__ */ window.React.createElement(
      "button",
      {
        key: dmIdx,
        onClick: () => handleAddCustomModel(dm.id),
        style: {
          background: aiModel === dm.id ? curTheme.accent : curTheme.cardBg,
          color: aiModel === dm.id ? "#fff" : curTheme.text,
          border: `1px solid ${aiModel === dm.id ? curTheme.accent : curTheme.border}`,
          borderRadius: 3,
          padding: "2px 6px",
          fontSize: 9,
          fontFamily: "JetBrains Mono",
          cursor: "pointer"
        }
      },
      dm.id
    ))))), aiProvider !== "local" && /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 } }, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, aiProvider.toUpperCase(), " API KEY"), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setShowKeyVisible(!showKeyVisible), style: { background: "transparent", border: "none", color: curTheme.accent, fontSize: 10, cursor: "pointer", fontFamily: "JetBrains Mono" } }, showKeyVisible ? "Hide Key" : "Show Key")), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: showKeyVisible ? "text" : "password",
        value: aiApiKey,
        onChange: (e) => setAiApiKey(e.target.value),
        placeholder: aiProvider === "openai" ? "sk-proj-..." : aiProvider === "anthropic" ? "sk-ant-api..." : aiProvider === "gemini" ? "AIzaSy..." : aiProvider === "deepseek" ? "sk-..." : aiProvider === "groq" ? "gsk_..." : "API Key...",
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "8px 10px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 12, outline: "none" }
      }
    )), (aiProvider === "custom" || aiProvider === "groq" || aiProvider === "deepseek" || aiProvider === "openrouter") && /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 4 } }, "API ENDPOINT BASE URL"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: aiBaseUrl,
        onChange: (e) => setAiBaseUrl(e.target.value),
        placeholder: aiProvider === "deepseek" ? "https://api.deepseek.com" : aiProvider === "groq" ? "https://api.groq.com/openai/v1" : aiProvider === "openrouter" ? "https://openrouter.ai/api/v1" : "http://localhost:1234/v1",
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "8px 10px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 12, outline: "none" }
      }
    )), aiProvider === "local" && /* @__PURE__ */ window.React.createElement("div", { style: { paddingTop: 8, borderTop: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 4 } }, "PULL / DOWNLOAD NEW LOCAL MODEL (VIA OLLAMA)"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 6 } }, /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: pullModelInput,
        onChange: (e) => setPullModelInput(e.target.value),
        placeholder: "e.g. qwen2.5-coder:7b, deepseek-r1:7b...",
        style: { flex: 1, background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "6px 10px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, outline: "none" }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handlePullOllamaModel,
        disabled: isPullingModel || !pullModelInput.trim(),
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, padding: "6px 12px", fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: isPullingModel || !pullModelInput.trim() ? "not-allowed" : "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Download, { size: 11, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, isPullingModel ? "Downloading..." : "Download")
    )))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginBottom: 2 } }, /* @__PURE__ */ window.React.createElement("span", null, "TEMPERATURE"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 700 } }, aiTemperature)), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "0.0",
        max: "1.0",
        step: "0.05",
        value: aiTemperature,
        onChange: (e) => setAiTemperature(parseFloat(e.target.value)),
        style: { width: "100%", accentColor: curTheme.accent }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginBottom: 2 } }, /* @__PURE__ */ window.React.createElement("span", null, "MAX TOKENS"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 700 } }, aiMaxTokens)), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "256",
        max: "4096",
        step: "128",
        value: aiMaxTokens,
        onChange: (e) => setAiMaxTokens(parseInt(e.target.value)),
        style: { width: "100%", accentColor: curTheme.accent }
      }
    ))), testConnStatus && /* @__PURE__ */ window.React.createElement("div", { style: { padding: "8px 12px", borderRadius: 4, background: testConnStatus.startsWith("Connected") ? "rgba(200,255,0,0.12)" : "rgba(255,61,0,0.12)", border: `1px solid ${testConnStatus.startsWith("Connected") ? curTheme.success : curTheme.secondary}`, color: testConnStatus.startsWith("Connected") ? curTheme.success : curTheme.secondary, fontSize: 11, fontFamily: "JetBrains Mono" } }, testConnStatus)), settingsActiveTab === "memory" && /* @__PURE__ */ window.React.createElement(window.React.Fragment, null, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", alignItems: "center", justifyContent: "space-between" } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 12, fontWeight: 700, color: curTheme.text, display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 14, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, "Continuous Adaptive Learning (NIL Memory)")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textSubtle, marginTop: 2 } }, "Automatically learns your coding habits, robot hardware parameters, and project context like ChatGPT & Claude.")), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleToggleMemoryEnabled(!aiMemoryEnabled),
        style: {
          background: aiMemoryEnabled ? curTheme.success : curTheme.panelBg,
          color: aiMemoryEnabled ? "#000" : curTheme.textMuted,
          border: `1px solid ${aiMemoryEnabled ? curTheme.success : curTheme.border}`,
          padding: "5px 12px",
          borderRadius: 14,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 700,
          cursor: "pointer"
        }
      },
      aiMemoryEnabled ? "ENABLED" : "PAUSED"
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "GLOBAL CUSTOM INSTRUCTIONS & DIRECTIVES"), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleSaveCustomInstructions,
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 3, padding: "3px 8px", fontSize: 9, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer" }
      },
      "Save Directives"
    )), /* @__PURE__ */ window.React.createElement(
      "textarea",
      {
        value: aiCustomInstructions,
        onChange: (e) => setAiCustomInstructions(e.target.value),
        placeholder: "How would you like NIL Copilot to respond? (e.g. 'Prefer clean type-annotated Python', 'Always include Lyapunov stability checks', 'We use a 6-DOF Franka arm')...",
        rows: 3,
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "8px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, resize: "vertical", outline: "none" }
      }
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "ADD LEARNED FACT / WORKSPACE CONTEXT"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "140px 1fr auto", gap: 6 } }, /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: newMemoryCategory,
        onChange: (e) => setNewMemoryCategory(e.target.value),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "6px 8px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "preferences" }, "Preferences"),
      /* @__PURE__ */ window.React.createElement("option", { value: "hardware" }, "Hardware"),
      /* @__PURE__ */ window.React.createElement("option", { value: "project" }, "Project Specs"),
      /* @__PURE__ */ window.React.createElement("option", { value: "directives" }, "Directives"),
      /* @__PURE__ */ window.React.createElement("option", { value: "learned_facts" }, "General Fact")
    ), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: newMemoryInput,
        onChange: (e) => setNewMemoryInput(e.target.value),
        placeholder: "e.g. Robot has 6 joints with CAN IDs 1..6 and max torque 45Nm",
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "6px 10px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, outline: "none" }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleAddUserMemory,
        disabled: !newMemoryInput.trim(),
        style: { background: curTheme.secondary, color: "#fff", border: "none", borderRadius: 4, padding: "6px 12px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: !newMemoryInput.trim() ? "not-allowed" : "pointer" }
      },
      "+ Add Fact"
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "LEARNED FACTS & KNOWLEDGE STORE (", aiUserMemories.length, ")"), aiUserMemories.length > 0 && /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleClearAllMemories,
        style: { background: "transparent", border: "none", color: "#ff3d00", fontSize: 9, fontFamily: "JetBrains Mono", cursor: "pointer" }
      },
      "Clear All"
    )), aiUserMemories.length === 0 ? /* @__PURE__ */ window.React.createElement("div", { style: { padding: 20, textAlign: "center", color: curTheme.textMuted, fontSize: 11, fontFamily: "JetBrains Mono", background: curTheme.cardBg, borderRadius: 6, border: `1px dashed ${curTheme.border}` } }, "No memories recorded yet. As you chat, NIL AI Copilot will automatically learn your project details and preferences.") : /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6, maxHeight: 220, overflowY: "auto" } }, aiUserMemories.map((mem) => /* @__PURE__ */ window.React.createElement(
      "div",
      {
        key: mem.id,
        style: {
          background: curTheme.cardBg,
          border: `1px solid ${curTheme.border}`,
          borderRadius: 4,
          padding: "8px 10px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 8
        }
      },
      /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("span", { style: {
        fontSize: 8,
        fontWeight: 700,
        fontFamily: "JetBrains Mono",
        padding: "2px 5px",
        borderRadius: 3,
        background: mem.category === "hardware" ? "rgba(0,212,255,0.15)" : mem.category === "preferences" ? "rgba(200,255,0,0.15)" : "rgba(224,86,253,0.15)",
        color: mem.category === "hardware" ? curTheme.accent : mem.category === "preferences" ? curTheme.success : curTheme.secondary,
        textTransform: "uppercase"
      } }, mem.category), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, color: curTheme.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, mem.content)),
      /* @__PURE__ */ window.React.createElement(
        "button",
        {
          onClick: () => handleDeleteUserMemory(mem.id),
          style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "2px 4px", display: "flex", alignItems: "center" },
          title: "Delete Memory"
        },
        /* @__PURE__ */ window.React.createElement(Icons.Trash, { size: 11, color: "#ff3d00" })
      )
    )))))), /* @__PURE__ */ window.React.createElement("div", { style: { height: 50, background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px" } }, settingsActiveTab === "models" ? /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleTestAIConnection,
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 14px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 11, color: curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, "Test Connection")
    ) : /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "Stored locally in NIL persistent store."), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          setShowAISettingsModal(false);
          showToast(`Active AI: ${aiModel} (${aiProvider.toUpperCase()})`);
        },
        style: { background: curTheme.secondary, color: "#fff", border: "none", padding: "6px 18px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: 700, cursor: "pointer" }
      },
      "Save & Apply"
    )))), showLicenseModal && /* @__PURE__ */ window.React.createElement("div", { style: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(6px)", zIndex: 1e4, display: "flex", alignItems: "center", justifyContent: "center" }, onClick: () => setShowLicenseModal(false) }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, borderRadius: 8, width: 700, maxWidth: "94vw", maxHeight: "90vh", display: "flex", flexDirection: "column", boxShadow: "0 20px 50px rgba(0,0,0,0.8)", overflow: "hidden" }, onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 48, background: curTheme.cardBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 13, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement(Icons.ShieldCheck, { size: 16, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, "NIL Studio \u2014 Cross-Platform Licensing & System Activation")), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setShowLicenseModal(false), style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 15, color: curTheme.textMuted }))), /* @__PURE__ */ window.React.createElement("div", { style: { padding: 18, overflowY: "auto", display: "flex", flexDirection: "column", gap: 14 } }, /* @__PURE__ */ window.React.createElement("div", { style: {
      background: licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? "linear-gradient(135deg, rgba(0,212,255,0.12), rgba(224,86,253,0.12))" : "rgba(255,170,0,0.08)",
      border: `1px solid ${licenseInfo?.is_valid && licenseInfo?.tier !== "community" ? "rgba(0,212,255,0.4)" : "rgba(255,170,0,0.3)"}`,
      borderRadius: 6,
      padding: 14,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 13, fontWeight: 800, color: curTheme.text } }, licenseInfo?.tier ? licenseInfo.tier.toUpperCase() : "COMMUNITY", " EDITION"), /* @__PURE__ */ window.React.createElement("span", { style: {
      fontSize: 9,
      fontWeight: 700,
      fontFamily: "JetBrains Mono",
      padding: "2px 6px",
      borderRadius: 3,
      background: licenseInfo?.is_valid ? "rgba(200,255,0,0.15)" : "rgba(255,61,0,0.15)",
      color: licenseInfo?.is_valid ? curTheme.success : "#ff3d00",
      border: `1px solid ${licenseInfo?.is_valid ? curTheme.success : "#ff3d00"}`
    } }, licenseInfo?.status || "ACTIVE")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 11, fontFamily: "JetBrains Mono", color: curTheme.textMuted, marginTop: 4 } }, "Licensee: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.text } }, licenseInfo?.customer_name || "Open Developer"), " (", licenseInfo?.organization || "NIL Community", ")"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textSubtle, marginTop: 2 } }, "Key: ", licenseInfo?.key || "NIL-DEV-COMMUNITY-EVALUATION", " \xA0|\xA0 Expires: ", licenseInfo?.expires_at ? `${licenseInfo.expires_at} (${licenseInfo.days_remaining} days)` : "Perpetual (No Expiration)")), licenseInfo?.tier !== "community" && /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleDeactivateLicense,
        style: {
          background: "transparent",
          border: `1px solid ${curTheme.borderStrong}`,
          color: curTheme.textMuted,
          padding: "5px 10px",
          borderRadius: 4,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          cursor: "pointer"
        }
      },
      "Deactivate"
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", letterSpacing: 1 } }, "HOST MACHINE HARDWARE FINGERPRINT (NODE-LOCK ID)"), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleCopyFingerprint,
        style: {
          background: copiedFp ? curTheme.success : curTheme.panelBg,
          border: `1px solid ${copiedFp ? curTheme.success : curTheme.border}`,
          color: copiedFp ? "#000" : curTheme.accent,
          padding: "3px 9px",
          borderRadius: 3,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 700,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 4
        }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Copy, { size: 11, color: copiedFp ? "#000" : curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, copiedFp ? "Copied!" : "Copy Machine ID")
    )), /* @__PURE__ */ window.React.createElement("div", { style: {
      background: curTheme.panelBg,
      border: `1px solid ${curTheme.borderStrong}`,
      padding: "8px 12px",
      borderRadius: 4,
      fontFamily: "JetBrains Mono",
      fontSize: 12,
      fontWeight: 700,
      color: curTheme.accent,
      letterSpacing: 1
    } }, licenseInfo?.host_machine_fingerprint || "NIL-HW-LOCAL-MACHINE"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "Share this Machine Hardware Fingerprint with NIL Robotics administrators to generate a hardware-locked enterprise license.")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "ACTIVATE COMMERCIAL OR ENTERPRISE LICENSE KEY"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 8 } }, /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: licenseKeyInput,
        onChange: (e) => setLicenseKeyInput(e.target.value),
        placeholder: "Enter key (e.g. NIL-ENT-A8F2-99C1-74B0 or paste signed JSON license)...",
        style: {
          flex: 1,
          background: curTheme.panelBg,
          border: `1px solid ${curTheme.borderStrong}`,
          color: curTheme.text,
          padding: "8px 12px",
          borderRadius: 4,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          outline: "none"
        }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleActivateLicense,
        disabled: isActivatingLicense || !licenseKeyInput.trim(),
        style: {
          background: curTheme.secondary,
          color: "#fff",
          border: "none",
          padding: "8px 16px",
          borderRadius: 4,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          fontWeight: 700,
          cursor: !licenseKeyInput.trim() || isActivatingLicense ? "not-allowed" : "pointer",
          display: "flex",
          alignItems: "center",
          gap: 6
        }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Key, { size: 12, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, isActivatingLicense ? "Activating..." : "Activate License")
    )), licenseActivationMsg && /* @__PURE__ */ window.React.createElement("div", { style: {
      padding: "6px 10px",
      borderRadius: 4,
      fontSize: 11,
      fontFamily: "JetBrains Mono",
      background: licenseActivationMsg.type === "success" ? "rgba(200,255,0,0.12)" : "rgba(255,61,0,0.12)",
      border: `1px solid ${licenseActivationMsg.type === "success" ? curTheme.success : "#ff3d00"}`,
      color: licenseActivationMsg.type === "success" ? curTheme.success : "#ff3d00"
    } }, licenseActivationMsg.text)), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", letterSpacing: 1 } }, "CROSS-PLATFORM INSTALLERS & APPLICATION PACKAGES"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.accent } }, "v1.0.0 Universal")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: 10, display: "flex", flexDirection: "column", gap: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 11, fontWeight: 700, color: curTheme.text, display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement(Icons.Package, { size: 12, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, "Linux (Ubuntu/Debian)")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, ".deb package & .tar.gz bundle"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 8, fontFamily: "JetBrains Mono", color: curTheme.textSubtle, background: curTheme.cardBg, padding: "3px 5px", borderRadius: 3, marginTop: 4 } }, "./scripts/installers/install_linux.sh")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: 10, display: "flex", flexDirection: "column", gap: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 11, fontWeight: 700, color: curTheme.text, display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement(Icons.Package, { size: 12, color: curTheme.secondary }), /* @__PURE__ */ window.React.createElement("span", null, "macOS (Silicon & Intel)")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "NIL Studio.app & .dmg bundle"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 8, fontFamily: "JetBrains Mono", color: curTheme.textSubtle, background: curTheme.cardBg, padding: "3px 5px", borderRadius: 3, marginTop: 4 } }, "./scripts/installers/install_mac.sh")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: 10, display: "flex", flexDirection: "column", gap: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 11, fontWeight: 700, color: curTheme.text, display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement(Icons.Package, { size: 12, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("span", null, "Windows (x64)")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "Setup.exe & .zip installer"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 8, fontFamily: "JetBrains Mono", color: curTheme.textSubtle, background: curTheme.cardBg, padding: "3px 5px", borderRadius: 3, marginTop: 4 } }, "./scripts/installers/install_windows.ps1")))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", letterSpacing: 1 } }, "UNLOCKED SYSTEM CAPABILITIES & ENTITLEMENTS"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6 } }, [
      { name: "STACC 1000Hz HAL Shared Memory", desc: "Zero-copy in-device sensorimotor bus" },
      { name: "All AI Providers & Custom Models", desc: "Ollama, OpenAI, Claude, Gemini, DeepSeek, Groq" },
      { name: "Live Web Grounding & Citations", desc: "Real-time web search grounding" },
      { name: "Continuous Knowledge Learning", desc: "Persistent ChatGPT/Claude-style user memory" },
      { name: "MuJoCo 1000Hz Physics Engine", desc: "Real-time dynamics & collision simulation" },
      { name: "3D Parametric CAD Studio", desc: "Direct in-IDE link sizing & CAD synthesis" },
      { name: "Digital Twin Real-Time Sync", desc: "Bidirectional hardware synchronization" },
      { name: "Continuous Robotics CI Suite", desc: "Kinematics & trajectory compliance testing" }
    ].map((feat, idx) => /* @__PURE__ */ window.React.createElement("div", { key: idx, style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: "6px 8px", display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement(Icons.Check, { size: 12, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontWeight: 700, color: curTheme.text } }, feat.name), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textMuted, fontFamily: "JetBrains Mono" } }, feat.desc))))))), /* @__PURE__ */ window.React.createElement("div", { style: { height: 48, background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textSubtle } }, "NIL Robotics Operating System v1.0.0 \u2022 Licensed Software"), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowLicenseModal(false),
        style: {
          background: curTheme.secondary,
          color: "#fff",
          border: "none",
          padding: "6px 16px",
          borderRadius: 4,
          fontFamily: "JetBrains Mono",
          fontSize: 11,
          fontWeight: 700,
          cursor: "pointer"
        }
      },
      "Done"
    )))), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", overflow: "hidden", background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("aside", { style: { width: 56, background: curTheme.sidebarBg, borderRight: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", padding: "10px 0", zIndex: 50 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8, width: "100%" } }, /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("explorer"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "explorer" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "explorer" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "explorer" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "Main IDE & 3D Simulation"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Explorer, { size: 18, color: activeActivity === "explorer" ? curTheme.secondary : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "IDE"),
      activeActivity === "explorer" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.secondary, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("cad"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "cad" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "cad" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "cad" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "3D Parametric CAD & Robot Link Studio"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Cad, { size: 18, color: activeActivity === "cad" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "CAD"),
      activeActivity === "cad" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.accent, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("robotics"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "robotics" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "robotics" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "robotics" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "STACC Kinematics Studio"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Robotics, { size: 18, color: activeActivity === "robotics" ? curTheme.success : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "Robotics"),
      activeActivity === "robotics" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.success, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("hardware"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "hardware" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "hardware" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "hardware" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "STACC Hardware & HAL Bus"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Hardware, { size: 18, color: activeActivity === "hardware" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "HAL Bus"),
      activeActivity === "hardware" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.accent, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("ai"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "ai" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "ai" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "ai" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "NIL Self-Evolution & Cognitive Studio"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 18, color: activeActivity === "ai" ? curTheme.secondary : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "NIL AI"),
      activeActivity === "ai" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.secondary, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("telemetry"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "telemetry" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "telemetry" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "telemetry" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "High-Precision 1000Hz Telemetry"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Telemetry, { size: 18, color: activeActivity === "telemetry" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "Signals"),
      activeActivity === "telemetry" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.accent, borderRadius: "0 2px 2px 0" } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => setActiveActivity("twin"),
        style: { width: 44, height: 44, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 6, cursor: "pointer", color: activeActivity === "twin" ? curTheme.text : curTheme.textMuted, position: "relative", background: activeActivity === "twin" ? curTheme.cardBg : "transparent", boxShadow: activeActivity === "twin" ? `0 2px 8px ${curTheme.border}` : "none" },
        title: "Digital Twin & Compute Manager"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Twin, { size: 18, color: activeActivity === "twin" ? curTheme.success : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 600, marginTop: 2 } }, "Compute"),
      activeActivity === "twin" && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", left: -6, top: 8, bottom: 8, width: 3, background: curTheme.success, borderRadius: "0 2px 2px 0" } })
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 6, width: "100%", borderTop: `1px solid ${curTheme.border}`, paddingTop: 8 } }, /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => {
          const next = !showBottomPanel;
          setShowBottomPanel(next);
          showToast(`Terminal Dock: ${next ? "Opened" : "Collapsed"}`);
        },
        style: {
          width: 42,
          height: 40,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: 6,
          cursor: "pointer",
          color: showBottomPanel ? curTheme.accent : curTheme.textMuted,
          background: showBottomPanel ? curTheme.cardBg : "transparent",
          border: showBottomPanel ? `1px solid ${curTheme.accent}` : "1px solid transparent",
          position: "relative"
        },
        title: showBottomPanel ? "Collapse NIL-STACC Terminal (Click to hide)" : "Expand NIL-STACC Terminal (Click to show)"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Code, { size: 15, color: showBottomPanel ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, fontWeight: 700, marginTop: 2 } }, "TERM"),
      showBottomPanel && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", right: 3, top: 3, width: 5, height: 5, borderRadius: "50%", background: curTheme.accent } })
    ), /* @__PURE__ */ window.React.createElement(
      "div",
      {
        onClick: () => {
          const next = !showMiniTelemetry;
          setShowMiniTelemetry(next);
          if (!showBottomPanel && next) setShowBottomPanel(true);
          showToast(`1000Hz Bus Telemetry: ${next ? "Visible" : "Hidden"}`);
        },
        style: {
          width: 42,
          height: 40,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: 6,
          cursor: "pointer",
          color: showMiniTelemetry ? curTheme.success : curTheme.textMuted,
          background: showMiniTelemetry ? curTheme.cardBg : "transparent",
          border: showMiniTelemetry ? `1px solid ${curTheme.success}` : "1px solid transparent",
          position: "relative"
        },
        title: showMiniTelemetry ? "Hide 1000Hz Bus Oscilloscopes" : "Show 1000Hz Bus Oscilloscopes"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Activity, { size: 15, color: showMiniTelemetry ? curTheme.success : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, fontWeight: 700, marginTop: 2 } }, "BUS"),
      showMiniTelemetry && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", right: 3, top: 3, width: 5, height: 5, borderRadius: "50%", background: curTheme.success } })
    ), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 10, marginTop: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { cursor: "pointer", color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement(Icons.Settings, { size: 16 })), /* @__PURE__ */ window.React.createElement("span", { style: { cursor: "pointer", color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement(Icons.User, { size: 16 }))))), activeActivity === "explorer" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", overflow: "hidden" } }, (() => {
      const currentCode = codeFiles[activeEditorTab] || "";
      const codeLines = currentCode.split("\n");
      const editorColors = curTheme.editor || {
        bg: curTheme.panelBg,
        gutterBg: curTheme.cardBg,
        gutterText: curTheme.textSubtle,
        activeGutterText: curTheme.accent,
        activeLineBg: "transparent",
        cursor: curTheme.accent,
        selectionBg: curTheme.accentGlow
      };
      const handleFormatActiveCode = () => {
        if (activeEditorTab.endsWith(".json") || activeEditorTab.endsWith(".rir")) {
          try {
            const parsed = JSON.parse(currentCode);
            const formatted = JSON.stringify(parsed, null, 2);
            setCodeFiles((prev) => ({ ...prev, [activeEditorTab]: formatted }));
            showToast(`Formatted ${activeEditorTab} (JSON AST)`);
          } catch (e) {
            showToast("Invalid JSON syntax: cannot auto-format");
          }
        } else {
          const lines = currentCode.split("\n").map((l) => l.replace(/\s+$/, ""));
          setCodeFiles((prev) => ({ ...prev, [activeEditorTab]: lines.join("\n") }));
          showToast(`Formatted ${activeEditorTab} (Ruff PEP-8)`);
        }
      };
      return /* @__PURE__ */ window.React.createElement("div", { style: { flex: showAIPanel ? "0 0 34%" : "0 0 46%", background: editorColors.bg, borderRight: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", overflow: "hidden", transition: "flex 0.15s ease, background 0.2s ease" } }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 36, background: curTheme.cardBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 6px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 2, overflowX: "auto" } }, Object.keys(codeFiles).map((fileName) => {
        const isActive = activeEditorTab === fileName;
        return /* @__PURE__ */ window.React.createElement(
          "button",
          {
            key: fileName,
            onClick: () => setActiveEditorTab(fileName),
            style: {
              height: 36,
              padding: "0 12px",
              background: isActive ? editorColors.bg : "transparent",
              border: "none",
              color: isActive ? curTheme.text : curTheme.textMuted,
              fontSize: 12,
              fontFamily: "JetBrains Mono, monospace",
              display: "flex",
              alignItems: "center",
              gap: 6,
              cursor: "pointer",
              borderTop: isActive ? `2px solid ${curTheme.accent}` : "2px solid transparent",
              transition: "all 0.1s ease"
            }
          },
          fileName.endsWith(".py") ? /* @__PURE__ */ window.React.createElement(Icons.Code, { size: 13, color: isActive ? curTheme.accent : curTheme.textMuted }) : /* @__PURE__ */ window.React.createElement(Icons.File, { size: 13, color: isActive ? curTheme.secondary : curTheme.textMuted }),
          /* @__PURE__ */ window.React.createElement("span", null, fileName)
        );
      })), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textMuted, background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, padding: "2px 6px", borderRadius: 3 } }, activeEditorTab.endsWith(".py") ? "Python 3.14" : "RIR Spec"), /* @__PURE__ */ window.React.createElement(
        "button",
        {
          onClick: handleFormatActiveCode,
          style: { background: "transparent", border: `1px solid ${curTheme.border}`, color: curTheme.textMuted, borderRadius: 3, padding: "2px 6px", fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 },
          title: "Format Code with Ruff / JSON Parser"
        },
        /* @__PURE__ */ window.React.createElement(Icons.Wand, { size: 11, color: curTheme.textMuted }),
        /* @__PURE__ */ window.React.createElement("span", null, "Format")
      ), /* @__PURE__ */ window.React.createElement(
        "button",
        {
          onClick: () => {
            navigator.clipboard.writeText(currentCode);
            showToast(`Copied ${activeEditorTab} to clipboard`);
          },
          style: { background: "transparent", border: `1px solid ${curTheme.border}`, color: curTheme.textMuted, borderRadius: 3, padding: "2px 6px", fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" },
          title: "Copy code to clipboard"
        },
        /* @__PURE__ */ window.React.createElement(Icons.Copy, { size: 11, color: curTheme.textMuted })
      ))), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, overflowY: "auto", display: "flex", background: editorColors.bg, fontFamily: "JetBrains Mono, monospace", fontSize: 13, lineHeight: 1.65 } }, /* @__PURE__ */ window.React.createElement("div", { style: {
        padding: "12px 14px 12px 10px",
        background: editorColors.gutterBg,
        borderRight: `1px solid ${curTheme.border}`,
        color: editorColors.gutterText,
        textAlign: "right",
        userSelect: "none",
        minWidth: 38,
        fontSize: 12,
        lineHeight: 1.65,
        transition: "background 0.2s ease, color 0.2s ease"
      } }, codeLines.map((_, i) => /* @__PURE__ */ window.React.createElement("div", { key: i }, i + 1))), /* @__PURE__ */ window.React.createElement(
        "textarea",
        {
          value: currentCode,
          onChange: (e) => setCodeFiles({ ...codeFiles, [activeEditorTab]: e.target.value }),
          spellCheck: false,
          style: {
            flex: 1,
            padding: "12px 16px",
            color: curTheme.text,
            background: editorColors.bg,
            border: "none",
            outline: "none",
            resize: "none",
            fontFamily: "JetBrains Mono, monospace",
            fontSize: 13,
            lineHeight: 1.65,
            caretColor: editorColors.cursor,
            whiteSpace: "pre",
            overflowX: "auto",
            transition: "background 0.2s ease, color 0.2s ease"
          }
        }
      )), /* @__PURE__ */ window.React.createElement("div", { style: { height: 22, background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 10px", fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("span", null, "workspace"), /* @__PURE__ */ window.React.createElement("span", null, "\u203A"), /* @__PURE__ */ window.React.createElement("span", null, "models"), /* @__PURE__ */ window.React.createElement("span", null, "\u203A"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 700 } }, activeEditorTab)), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("span", null, codeLines.length, " lines"), /* @__PURE__ */ window.React.createElement("span", null, currentCode.length, " chars"), /* @__PURE__ */ window.React.createElement("span", null, "UTF-8"), /* @__PURE__ */ window.React.createElement("span", null, "Spaces: 4"))));
    })(), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, position: "relative", background: curTheme.bg, overflow: "hidden", borderRight: showAIPanel ? `1px solid ${curTheme.border}` : "none" } }, /* @__PURE__ */ window.React.createElement("div", { style: {
      position: "absolute",
      top: 10,
      right: 10,
      zIndex: 20,
      display: "flex",
      alignItems: "center",
      gap: 6,
      background: theme === "light" ? "rgba(255,255,255,0.85)" : "rgba(10, 11, 16, 0.82)",
      backdropFilter: "blur(12px)",
      padding: "4px 8px",
      borderRadius: 6,
      border: `1px solid ${curTheme.borderStrong}`,
      boxShadow: "0 4px 20px rgba(0,0,0,0.15)"
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4 } }, /* @__PURE__ */ window.React.createElement(Icons.Camera, { size: 12, color: curTheme.textMuted }), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: cameraPreset,
        onChange: (e) => setCameraPreset(e.target.value),
        style: { background: "transparent", border: "none", color: curTheme.text, height: 24, padding: "0 2px", fontFamily: "JetBrains Mono", fontSize: 10, fontWeight: 600, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "perspective", style: { background: curTheme.panelBg } }, "Perspective"),
      /* @__PURE__ */ window.React.createElement("option", { value: "top", style: { background: curTheme.panelBg } }, "Top (XY)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "side", style: { background: curTheme.panelBg } }, "Side (YZ)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "front", style: { background: curTheme.panelBg } }, "Front (XZ)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "iso", style: { background: curTheme.panelBg } }, "Isometric")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { height: 14, width: 1, background: curTheme.border } }), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 3 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textMuted, fontFamily: "JetBrains Mono" } }, "Finish:"), [
      { id: "orange", color: "#ff6a00", title: "Safety Orange" },
      { id: "silver", color: "#94a3b8", title: "Brushed Steel" },
      { id: "blue", color: "#0284c7", title: "Cobalt Blue" },
      { id: "white", color: "#f8fafc", title: "Clean White" }
    ].map((c) => /* @__PURE__ */ window.React.createElement(
      "div",
      {
        key: c.id,
        onClick: () => {
          setRobotColorPreset(c.id);
          showToast(`Robot Finish: ${c.title}`);
        },
        style: {
          width: 13,
          height: 13,
          borderRadius: "50%",
          background: c.color,
          border: robotColorPreset === c.id ? `2px solid ${curTheme.accent}` : "1px solid rgba(0,0,0,0.25)",
          cursor: "pointer",
          boxShadow: robotColorPreset === c.id ? `0 0 6px ${c.color}` : "none",
          transform: robotColorPreset === c.id ? "scale(1.15)" : "scale(1)",
          transition: "all 0.15s ease"
        },
        title: c.title
      }
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { height: 14, width: 1, background: curTheme.border } }), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          const next = lightingBrightness === "bright" ? "balanced" : "bright";
          setLightingBrightness(next);
          showToast(`Lighting: ${next}`);
        },
        style: { background: "transparent", border: "none", color: curTheme.textMuted, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, display: "flex", alignItems: "center", gap: 4, cursor: "pointer", padding: "2px 4px", borderRadius: 3 },
        title: "Toggle Lighting Rig (Bright / Balanced Studio)"
      },
      lightingBrightness === "bright" ? /* @__PURE__ */ window.React.createElement(Icons.SunMedium, { size: 12, color: curTheme.accent }) : /* @__PURE__ */ window.React.createElement(Icons.Bulb, { size: 12, color: curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, lightingBrightness === "bright" ? "Studio" : "Soft")
    ), /* @__PURE__ */ window.React.createElement("div", { style: { height: 14, width: 1, background: curTheme.border } }), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowGrid(!showGrid),
        style: { background: showGrid ? curTheme.accentGlow : "transparent", border: showGrid ? `1px solid ${curTheme.accent}` : `1px solid transparent`, color: showGrid ? curTheme.accent : curTheme.textMuted, padding: "2px 6px", borderRadius: 3, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 3 },
        title: "Toggle Floor Grid"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Grid, { size: 11, color: showGrid ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Grid")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowAxes(!showAxes),
        style: { background: showAxes ? "rgba(200,255,0,0.15)" : "transparent", border: showAxes ? "1px solid #c8ff00" : "1px solid transparent", color: showAxes ? "#c8ff00" : curTheme.textMuted, padding: "2px 6px", borderRadius: 3, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 3 },
        title: "Toggle Tool Center Point (TCP) Axes"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Target, { size: 11, color: showAxes ? "#c8ff00" : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "TCP")
    )), /* @__PURE__ */ window.React.createElement("div", { ref: threeMountRef, style: { width: "100%", height: "100%" } }), /* @__PURE__ */ window.React.createElement("div", { style: {
      position: "absolute",
      bottom: 12,
      left: 12,
      zIndex: 10,
      background: theme === "light" ? "rgba(255,255,255,0.9)" : "rgba(10, 11, 16, 0.85)",
      backdropFilter: "blur(12px)",
      border: `1px solid ${curTheme.borderStrong}`,
      borderRadius: 6,
      padding: "8px 12px",
      boxShadow: "0 6px 24px rgba(0,0,0,0.2)",
      display: "flex",
      flexDirection: "column",
      gap: 5,
      minWidth: 165
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `1px solid ${curTheme.border}`, paddingBottom: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 6, height: 6, borderRadius: "50%", background: curTheme.success, animation: "pulse 1.5s infinite" } }), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", fontWeight: 800, color: curTheme.textSubtle, letterSpacing: 0.5 } }, "1000Hz BUS")), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.accent, fontWeight: 700 } }, "0.02ms")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 4, fontFamily: "JetBrains Mono", fontSize: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted } }, "J1 Base Yaw:"), /* @__PURE__ */ window.React.createElement("span", { style: { color: "#ff6a00", fontWeight: 700 } }, j1Torque, " Nm")), /* @__PURE__ */ window.React.createElement("div", { style: { width: "100%", height: 3, background: curTheme.border, borderRadius: 2, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: `${Math.min(100, j1Torque / 20 * 100)}%`, height: "100%", background: "#ff6a00" } })), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 2 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted } }, "J2 Shoulder:"), /* @__PURE__ */ window.React.createElement("span", { style: { color: "#c8ff00", fontWeight: 700 } }, j2Torque, " Nm")), /* @__PURE__ */ window.React.createElement("div", { style: { width: "100%", height: 3, background: curTheme.border, borderRadius: 2, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: `${Math.min(100, j2Torque / 15 * 100)}%`, height: "100%", background: "#c8ff00" } }))))), showAIPanel && /* @__PURE__ */ window.React.createElement("div", { style: {
      width: 400,
      flexShrink: 0,
      background: theme === "light" ? "#fcfcfd" : "#0c0d14",
      borderLeft: `1px solid ${curTheme.border}`,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      zIndex: 15,
      boxShadow: "-4px 0 24px rgba(0,0,0,0.06)"
    } }, /* @__PURE__ */ window.React.createElement("div", { style: {
      height: 44,
      background: curTheme.cardBg,
      borderBottom: `1px solid ${curTheme.border}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 12px",
      gap: 8
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: {
      width: 24,
      height: 24,
      borderRadius: 6,
      background: curTheme.accentGlow,
      border: `1px solid ${curTheme.accent}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      boxShadow: `0 0 8px ${curTheme.accentGlow}`
    } }, /* @__PURE__ */ window.React.createElement(Icons.Bot, { size: 13, color: curTheme.accent })), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 12, fontWeight: 800, color: curTheme.text, letterSpacing: "-0.2px", whiteSpace: "nowrap" } }, "NIL Copilot"), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowAISettingsModal(true),
        style: {
          display: "flex",
          alignItems: "center",
          gap: 5,
          background: theme === "light" ? "#ffffff" : "rgba(255,255,255,0.06)",
          border: `1px solid ${curTheme.borderStrong}`,
          color: curTheme.text,
          padding: "2px 8px",
          borderRadius: 12,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 600,
          cursor: "pointer",
          maxWidth: 120,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          boxShadow: "0 1px 3px rgba(0,0,0,0.05)"
        },
        title: "Click to switch Model or configure API Keys"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 9, color: curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", { style: { overflow: "hidden", textOverflow: "ellipsis" } }, String(aiModel || "llama3.2").replace(":latest", "")),
      /* @__PURE__ */ window.React.createElement(Icons.ChevronDown, { size: 8, color: curTheme.textMuted })
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 3 } }, /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: aiAgentRole,
        onChange: (e) => {
          setAiAgentRole(e.target.value);
          showToast(`Copilot Role: ${e.target.value}`);
        },
        style: {
          background: "transparent",
          border: `1px solid ${curTheme.border}`,
          color: curTheme.accent,
          borderRadius: 12,
          padding: "2px 6px",
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 700,
          outline: "none",
          cursor: "pointer",
          maxWidth: 105
        },
        title: "Subagent Persona"
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "lead" }, "Lead Copilot"),
      /* @__PURE__ */ window.React.createElement("option", { value: "controls" }, "Controls Engineer"),
      /* @__PURE__ */ window.React.createElement("option", { value: "simulation" }, "Sim 1000Hz"),
      /* @__PURE__ */ window.React.createElement("option", { value: "perception" }, "Vision HAL"),
      /* @__PURE__ */ window.React.createElement("option", { value: "architect" }, "CAD & Kinematics"),
      /* @__PURE__ */ window.React.createElement("option", { value: "debugging" }, "Diagnostics"),
      /* @__PURE__ */ window.React.createElement("option", { value: "deployment" }, "C++ Deployment")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowAISettingsModal(true),
        style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "4px 5px", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" },
        title: "Settings & API Keys"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Settings, { size: 13, color: curTheme.textMuted })
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          setAiChatMessages([
            {
              id: `msg-${Date.now()}`,
              sender: "agent",
              agentName: "NIL Copilot",
              agentRole: "Autonomous Lead",
              agentIcon: "Brain",
              text: "Hello! I am your NIL Autonomous Robotics Engineering Copilot. How can I help you design, control, or optimize your STACC & MuJoCo robotics systems today?",
              timestamp: "Just now",
              provider: aiProvider,
              model: aiModel
            }
          ]);
          showToast("Conversation refreshed");
        },
        style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "4px 5px", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" },
        title: "New Conversation"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Refresh, { size: 13, color: curTheme.textMuted })
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowAIPanel(false),
        style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "4px 5px", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" },
        title: "Close Copilot Panel"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 13, color: curTheme.textMuted })
    ))), /* @__PURE__ */ window.React.createElement("div", { style: {
      height: 25,
      background: theme === "light" ? "#f1f5f9" : "#090a10",
      borderBottom: `1px solid ${curTheme.border}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 12px",
      fontSize: 10,
      color: curTheme.textMuted
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontWeight: 700, letterSpacing: 0.5, color: curTheme.textSubtle, textTransform: "uppercase" } }, "Context"), /* @__PURE__ */ window.React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 4, color: curTheme.accent, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, /* @__PURE__ */ window.React.createElement(Icons.File, { size: 10, color: curTheme.accent }), " ", activeEditorTab), /* @__PURE__ */ window.React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 4, color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement(Icons.Robotics, { size: 10, color: curTheme.textMuted }), " 6-DOF ARM")), /* @__PURE__ */ window.React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 4, color: curTheme.success, fontWeight: 600, flexShrink: 0 } }, /* @__PURE__ */ window.React.createElement("span", { style: { width: 5, height: 5, borderRadius: "50%", background: curTheme.success, animation: "pulse 1.5s infinite" } }), "1000Hz HAL")), /* @__PURE__ */ window.React.createElement("div", { ref: aiChatScrollRef, style: {
      flex: 1,
      overflowY: "auto",
      padding: "16px 14px",
      display: "flex",
      flexDirection: "column",
      gap: 16
    } }, aiChatMessages.map((msg) => /* @__PURE__ */ window.React.createElement("div", { key: msg.id, style: { display: "flex", flexDirection: "column", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: msg.sender === "user" ? "flex-end" : "space-between",
      padding: "0 2px"
    } }, msg.sender === "agent" ? /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 18, height: 18, borderRadius: "50%", background: curTheme.accentGlow, border: `1px solid ${curTheme.accent}`, display: "flex", alignItems: "center", justifyContent: "center" } }, (() => {
      const RoleIcon = Icons[msg.agentIcon] || Icons.Brain;
      return /* @__PURE__ */ window.React.createElement(RoleIcon, { size: 11, color: curTheme.accent });
    })()), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 12, fontWeight: 700, color: curTheme.text } }, msg.agentName || "NIL Copilot"), msg.agentRole && /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textSubtle, background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, padding: "1px 6px", borderRadius: 10 } }, msg.agentRole)) : /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 600, color: curTheme.textMuted } }, "You")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, msg.execution_time_ms && /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, color: curTheme.success, fontFamily: "JetBrains Mono", background: "rgba(22, 163, 74, 0.1)", border: "1px solid rgba(22, 163, 74, 0.2)", padding: "1px 5px", borderRadius: 4, fontWeight: 600, display: "flex", alignItems: "center", gap: 3 } }, /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 9, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("span", null, msg.execution_time_ms > 1e3 ? (msg.execution_time_ms / 1e3).toFixed(1) + "s" : Math.round(msg.execution_time_ms) + "ms")), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textSubtle } }, msg.timestamp))), /* @__PURE__ */ window.React.createElement("div", { style: {
      alignSelf: msg.sender === "user" ? "flex-end" : "stretch",
      maxWidth: msg.sender === "user" ? "88%" : "100%",
      background: msg.sender === "user" ? theme === "light" ? "#0284c7" : "rgba(0, 212, 255, 0.12)" : theme === "light" ? "#ffffff" : "#11131c",
      border: `1px solid ${msg.sender === "user" ? theme === "light" ? "#0284c7" : curTheme.accent : curTheme.borderStrong}`,
      borderRadius: msg.sender === "user" ? "14px 14px 2px 14px" : "8px 12px 12px 12px",
      padding: "10px 14px",
      color: msg.sender === "user" ? theme === "light" ? "#ffffff" : "#f1f5f9" : curTheme.text,
      fontSize: 13,
      lineHeight: 1.6,
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      boxShadow: msg.sender === "user" ? "0 2px 8px rgba(2, 132, 199, 0.2)" : "0 2px 10px rgba(0,0,0,0.04)"
    } }, (() => {
      const rawText = msg.text || "";
      const parts = rawText.split(/(```[\s\S]*?```)/g);
      return parts.map((part, pIdx) => {
        if (part.startsWith("```") && part.endsWith("```")) {
          const firstLineEnd = part.indexOf("\n");
          const lang = firstLineEnd > 3 ? part.slice(3, firstLineEnd).trim() : "code";
          const code = firstLineEnd > 0 ? part.slice(firstLineEnd + 1, -3).trim() : part.slice(3, -3).trim();
          const blockId = `${msg.id}-${pIdx}`;
          const isCopied = copiedCodeId === blockId;
          return /* @__PURE__ */ window.React.createElement("div", { key: pIdx, style: {
            marginTop: 10,
            marginBottom: 10,
            borderRadius: 6,
            overflow: "hidden",
            border: `1px solid ${curTheme.borderStrong}`,
            background: "#08090f",
            boxShadow: "0 4px 16px rgba(0,0,0,0.25)"
          } }, /* @__PURE__ */ window.React.createElement("div", { style: {
            height: 30,
            background: "#10121c",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 10px",
            borderBottom: "1px solid rgba(255,255,255,0.08)"
          } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 3 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 7, height: 7, borderRadius: "50%", background: "#ff5f56" } }), /* @__PURE__ */ window.React.createElement("div", { style: { width: 7, height: 7, borderRadius: "50%", background: "#ffbd2e" } }), /* @__PURE__ */ window.React.createElement("div", { style: { width: 7, height: 7, borderRadius: "50%", background: "#27c93f" } })), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: "#94a3b8", fontFamily: "JetBrains Mono", textTransform: "uppercase", fontWeight: 700, marginLeft: 4 } }, lang || "code")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 4 } }, /* @__PURE__ */ window.React.createElement(
            "button",
            {
              onClick: () => {
                setCodeFiles((prev) => ({ ...prev, [activeEditorTab]: code }));
                showToast(`Applied code to ${activeEditorTab}`);
              },
              style: {
                background: curTheme.accent,
                color: "#fff",
                border: "none",
                borderRadius: 3,
                fontSize: 10,
                fontFamily: "JetBrains Mono",
                fontWeight: 700,
                padding: "2px 7px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 3
              },
              title: "Replace active editor tab with this code"
            },
            /* @__PURE__ */ window.React.createElement(Icons.Pencil, { size: 10, color: "#fff" }),
            /* @__PURE__ */ window.React.createElement("span", null, "Apply")
          ), /* @__PURE__ */ window.React.createElement(
            "button",
            {
              onClick: () => {
                setCodeFiles((prev) => ({ ...prev, [activeEditorTab]: code }));
                handleRunCode();
                showToast("Running in 1000Hz STACC loop...");
              },
              style: {
                background: "#16a34a",
                color: "#ffffff",
                border: "none",
                borderRadius: 3,
                fontSize: 10,
                fontFamily: "JetBrains Mono",
                fontWeight: 700,
                padding: "2px 7px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 3
              },
              title: "Apply and run in STACC simulation"
            },
            /* @__PURE__ */ window.React.createElement(Icons.Play, { size: 10, color: "#fff" }),
            /* @__PURE__ */ window.React.createElement("span", null, "Run")
          ), /* @__PURE__ */ window.React.createElement(
            "button",
            {
              onClick: () => {
                navigator.clipboard.writeText(code);
                setCopiedCodeId(blockId);
                showToast("Copied code to clipboard");
                setTimeout(() => setCopiedCodeId(null), 2e3);
              },
              style: {
                background: "rgba(255,255,255,0.06)",
                color: "#cbd5e1",
                border: "1px solid rgba(255,255,255,0.12)",
                borderRadius: 3,
                fontSize: 10,
                fontFamily: "JetBrains Mono",
                padding: "2px 6px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 3
              },
              title: "Copy code"
            },
            isCopied ? /* @__PURE__ */ window.React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 3, color: curTheme.success } }, /* @__PURE__ */ window.React.createElement(Icons.Check, { size: 10, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("span", null, "Copied")) : /* @__PURE__ */ window.React.createElement("span", { style: { display: "flex", alignItems: "center", gap: 3 } }, /* @__PURE__ */ window.React.createElement(Icons.Copy, { size: 10, color: "#cbd5e1" }), /* @__PURE__ */ window.React.createElement("span", null, "Copy"))
          ))), /* @__PURE__ */ window.React.createElement("pre", { style: {
            margin: 0,
            padding: "12px 14px",
            fontSize: 12,
            color: "#a5b4fc",
            fontFamily: "JetBrains Mono, monospace",
            overflowX: "auto",
            maxHeight: 240,
            lineHeight: 1.55
          } }, /* @__PURE__ */ window.React.createElement("code", null, code)));
        } else {
          const lines = part.split("\n");
          return /* @__PURE__ */ window.React.createElement("div", { key: pIdx, style: { display: "flex", flexDirection: "column", gap: 3 } }, lines.map((line, lIdx) => {
            if (line.startsWith("### ")) {
              return /* @__PURE__ */ window.React.createElement("div", { key: lIdx, style: { fontWeight: 700, fontSize: 14, color: curTheme.accent, marginTop: 6, marginBottom: 2 } }, line.slice(4));
            } else if (line.startsWith("## ")) {
              return /* @__PURE__ */ window.React.createElement("div", { key: lIdx, style: { fontWeight: 800, fontSize: 15, color: curTheme.text, marginTop: 8, marginBottom: 2 } }, line.slice(3));
            } else if (line.startsWith("\u2022 ") || line.startsWith("- ") || line.startsWith("* ")) {
              return /* @__PURE__ */ window.React.createElement("div", { key: lIdx, style: { paddingLeft: 14, position: "relative", marginBottom: 2 } }, /* @__PURE__ */ window.React.createElement("span", { style: { position: "absolute", left: 0, color: curTheme.accent, fontWeight: 700 } }, "\u2022"), /* @__PURE__ */ window.React.createElement("span", null, line.slice(2)));
            } else if (line.trim() === "") {
              return /* @__PURE__ */ window.React.createElement("div", { key: lIdx, style: { height: 6 } });
            } else {
              return /* @__PURE__ */ window.React.createElement("div", { key: lIdx }, line);
            }
          }));
        }
      });
    })(), msg.steps && msg.steps.length > 0 && /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: 10, paddingTop: 8, borderTop: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", gap: 4 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 0.5 } }, "EXECUTED ACTIONS (", msg.steps.length, ")"), msg.steps.map((st, idx) => /* @__PURE__ */ window.React.createElement("div", { key: idx, style: { background: curTheme.cardBg, padding: "4px 8px", borderRadius: 4, border: `1px solid ${curTheme.border}`, fontSize: 11, display: "flex", alignItems: "center", justifyContent: "space-between" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, /* @__PURE__ */ window.React.createElement(Icons.Check, { size: 10, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.text, fontWeight: 600 } }, st.tool), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted, fontSize: 10 } }, st.summary)), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, padding: "1px 5px", borderRadius: 3, background: "rgba(22,163,74,0.1)", color: curTheme.success, fontWeight: 700 } }, st.status.toUpperCase())))), msg.citations && msg.citations.length > 0 && /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: 10, paddingTop: 8, borderTop: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement(Icons.Globe, { size: 11, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, "WEB SOURCES & GROUNDING (", msg.citations.length, ")")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 5 } }, msg.citations.map((cit, cIdx) => /* @__PURE__ */ window.React.createElement(
      "a",
      {
        key: cIdx,
        href: cit.url,
        target: "_blank",
        rel: "noopener noreferrer",
        style: {
          background: curTheme.cardBg,
          border: `1px solid ${curTheme.border}`,
          borderRadius: 4,
          padding: "3px 8px",
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          color: curTheme.accent,
          textDecoration: "none",
          display: "flex",
          alignItems: "center",
          gap: 4,
          maxWidth: 200
        },
        title: cit.snippet || cit.title
      },
      /* @__PURE__ */ window.React.createElement("span", { style: { fontWeight: 700 } }, "[", cIdx + 1, "]"),
      /* @__PURE__ */ window.React.createElement("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, cit.title || cit.url)
    )))), msg.learned_memories && msg.learned_memories.length > 0 && /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: 8, background: "rgba(200,255,0,0.08)", border: `1px solid ${curTheme.success}`, borderRadius: 4, padding: "5px 8px", display: "flex", alignItems: "center", gap: 6, fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.success } }, /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 11, color: curTheme.success }), /* @__PURE__ */ window.React.createElement("span", null, "Learned about your project: ", msg.learned_memories.map((m) => m.content).join("; ")))))), aiIsThinking && /* @__PURE__ */ window.React.createElement("div", { style: {
      background: curTheme.cardBg,
      border: `1px solid ${curTheme.borderStrong}`,
      borderRadius: 8,
      padding: "10px 14px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      boxShadow: "0 2px 8px rgba(0,0,0,0.04)"
    } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 8, height: 8, borderRadius: "50%", background: curTheme.accent, animation: "pulse 1.2s infinite" } }), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 12, color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.accent } }, aiModel), " is reasoning ", aiWebSearch ? "& searching web..." : "& generating code..."))), /* @__PURE__ */ window.React.createElement("div", { style: {
      padding: "6px 10px",
      background: curTheme.cardBg,
      borderTop: `1px solid ${curTheme.border}`,
      display: "flex",
      gap: 5,
      overflowX: "auto"
    } }, [
      { label: "Pick & Place", icon: "Robotics", prompt: "Write a complete pick and place controller for the 6-DOF arm" },
      { label: "Search Latest HAL", icon: "Globe", prompt: "Search web for the latest high-speed robotics HAL benchmarks and latency specs" },
      { label: "Tune PID Gains", icon: "Sliders", prompt: "Tune cascaded PID and impedance matrices for 5kg payload" },
      { label: "Add 7th Joint", icon: "Layers", prompt: "Add a redundant 7th revolute joint between shoulder and elbow in robot.rir" },
      { label: "1000Hz Benchmark", icon: "Flask", prompt: "Benchmark MuJoCo collision physics at 1000Hz stepping in STACC" }
    ].map((chip, idx) => {
      const ChipIcon = Icons[chip.icon] || Icons.Zap;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: idx,
          onClick: () => handleSendAIChat(chip.prompt),
          style: {
            background: theme === "light" ? "#ffffff" : "rgba(255,255,255,0.04)",
            border: `1px solid ${curTheme.borderStrong}`,
            color: curTheme.text,
            padding: "4px 9px",
            borderRadius: 14,
            fontSize: 10,
            fontFamily: "Inter, sans-serif",
            fontWeight: 500,
            cursor: "pointer",
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "center",
            gap: 4,
            boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
            transition: "all 0.15s ease"
          }
        },
        /* @__PURE__ */ window.React.createElement(ChipIcon, { size: 11, color: curTheme.accent }),
        /* @__PURE__ */ window.React.createElement("span", null, chip.label)
      );
    })), /* @__PURE__ */ window.React.createElement("div", { style: { padding: "10px 12px 14px", background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement(
      "form",
      {
        onSubmit: (e) => {
          e.preventDefault();
          handleSendAIChat();
        },
        style: {
          background: theme === "light" ? "#ffffff" : "#11131c",
          border: `1px solid ${curTheme.borderStrong}`,
          borderRadius: 10,
          padding: "8px 10px 6px",
          display: "flex",
          flexDirection: "column",
          gap: 6,
          boxShadow: "0 2px 12px rgba(0,0,0,0.06)"
        }
      },
      /* @__PURE__ */ window.React.createElement(
        "textarea",
        {
          value: aiChatInput,
          onChange: (e) => setAiChatInput(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSendAIChat();
            }
          },
          placeholder: `Ask NIL Copilot (${String(aiModel || "llama3.2").replace(":latest", "")}) or search robotics web...`,
          rows: 2,
          style: {
            width: "100%",
            background: "transparent",
            border: "none",
            color: curTheme.text,
            fontFamily: "Inter, -apple-system, sans-serif",
            fontSize: 12,
            lineHeight: 1.5,
            resize: "none",
            outline: "none"
          }
        }
      ),
      /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 4, borderTop: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 5 } }, /* @__PURE__ */ window.React.createElement(
        "button",
        {
          type: "button",
          onClick: () => {
            const next = !aiWebSearch;
            setAiWebSearch(next);
            showToast(`Web Search & Grounding: ${next ? "Enabled" : "Disabled"}`);
          },
          style: {
            display: "flex",
            alignItems: "center",
            gap: 4,
            background: aiWebSearch ? theme === "light" ? "#e0f2fe" : "rgba(0,212,255,0.15)" : "transparent",
            border: `1px solid ${aiWebSearch ? curTheme.accent : curTheme.border}`,
            color: aiWebSearch ? curTheme.accent : curTheme.textMuted,
            borderRadius: 12,
            padding: "2px 7px",
            fontSize: 9,
            fontFamily: "JetBrains Mono",
            fontWeight: aiWebSearch ? 700 : 500,
            cursor: "pointer"
          },
          title: "Toggle Real-Time Web Search & Citations"
        },
        /* @__PURE__ */ window.React.createElement(Icons.Globe, { size: 10, color: aiWebSearch ? curTheme.accent : curTheme.textMuted }),
        /* @__PURE__ */ window.React.createElement("span", null, "Search ", aiWebSearch ? "ON" : "OFF")
      ), /* @__PURE__ */ window.React.createElement(
        "button",
        {
          type: "button",
          onClick: () => {
            setSettingsActiveTab("memory");
            setShowAISettingsModal(true);
          },
          style: {
            display: "flex",
            alignItems: "center",
            gap: 4,
            background: "transparent",
            border: `1px solid ${curTheme.border}`,
            color: curTheme.textMuted,
            borderRadius: 12,
            padding: "2px 7px",
            fontSize: 9,
            fontFamily: "JetBrains Mono",
            cursor: "pointer"
          },
          title: "View & Manage NIL AI Memory"
        },
        /* @__PURE__ */ window.React.createElement(Icons.Brain, { size: 10, color: curTheme.accent }),
        /* @__PURE__ */ window.React.createElement("span", null, "Mem (", aiUserMemories.length, ")")
      ), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, color: curTheme.textSubtle, background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, padding: "2px 5px", borderRadius: 4, fontFamily: "JetBrains Mono", display: "flex", alignItems: "center", gap: 3 } }, /* @__PURE__ */ window.React.createElement(Icons.Pin, { size: 9, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", null, activeEditorTab))), /* @__PURE__ */ window.React.createElement(
        "button",
        {
          type: "submit",
          disabled: aiIsThinking || !aiChatInput.trim(),
          style: {
            height: 26,
            padding: "0 12px",
            background: aiIsThinking || !aiChatInput.trim() ? curTheme.border : curTheme.accent,
            color: "#ffffff",
            border: "none",
            borderRadius: 13,
            cursor: aiIsThinking || !aiChatInput.trim() ? "not-allowed" : "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 5,
            fontSize: 11,
            fontWeight: 700,
            transition: "all 0.15s ease",
            boxShadow: aiIsThinking || !aiChatInput.trim() ? "none" : `0 2px 8px ${curTheme.accentGlow}`
          }
        },
        /* @__PURE__ */ window.React.createElement(Icons.Send, { size: 11, color: "#ffffff" }),
        /* @__PURE__ */ window.React.createElement("span", null, "Send")
      ))
    )))), showBottomPanel ? /* @__PURE__ */ window.React.createElement("div", { style: { height: 300, background: curTheme.panelBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", overflow: "hidden", transition: "height 0.15s ease" } }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 34, background: curTheme.cardBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 12px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 14 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setActiveDockTab("terminal"),
        style: { background: "transparent", border: "none", color: activeDockTab === "terminal" ? curTheme.text : curTheme.textMuted, fontSize: 12, fontWeight: activeDockTab === "terminal" ? 700 : 500, padding: "6px 0", cursor: "pointer", borderBottom: activeDockTab === "terminal" ? `2px solid ${curTheme.accent}` : "none", display: "flex", alignItems: "center", gap: 6 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Code, { size: 13, color: activeDockTab === "terminal" ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "NIL-STACC Terminal")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setActiveDockTab("telemetry"),
        style: { background: "transparent", border: "none", color: activeDockTab === "telemetry" ? curTheme.text : curTheme.textMuted, fontSize: 12, fontWeight: activeDockTab === "telemetry" ? 700 : 500, padding: "6px 0", cursor: "pointer", borderBottom: activeDockTab === "telemetry" ? `2px solid ${curTheme.secondary}` : "none", display: "flex", alignItems: "center", gap: 6 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Activity, { size: 13, color: activeDockTab === "telemetry" ? curTheme.secondary : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Telemetry (1000Hz HAL)")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          const next = !showMiniTelemetry;
          setShowMiniTelemetry(next);
          showToast(`1000Hz Bus Telemetry: ${next ? "Visible" : "Hidden"}`);
        },
        style: {
          background: showMiniTelemetry ? curTheme.accentGlow : "transparent",
          border: `1px solid ${showMiniTelemetry ? curTheme.success : curTheme.border}`,
          color: showMiniTelemetry ? curTheme.success : curTheme.textMuted,
          padding: "2px 8px",
          borderRadius: 4,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          fontWeight: 700,
          display: "flex",
          alignItems: "center",
          gap: 4,
          cursor: "pointer"
        },
        title: "Toggle Right Side 1000Hz HAL Bus Telemetry"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Activity, { size: 11, color: showMiniTelemetry ? curTheme.success : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Bus Oscilloscope: ", showMiniTelemetry ? "ON" : "OFF")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          setShowBottomPanel(false);
          showToast("Terminal Dock collapsed. Reopen via sidebar 'TERM' or bottom bar.");
        },
        style: {
          background: "transparent",
          border: `1px solid ${curTheme.border}`,
          color: curTheme.textMuted,
          padding: "2px 8px",
          borderRadius: 4,
          fontSize: 10,
          fontFamily: "JetBrains Mono",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 4
        },
        title: "Collapse Terminal Panel (Full Screen Code & Simulation)"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 11, color: curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Hide Dock")
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement(
      "div",
      {
        ref: terminalContainerRef,
        onClick: () => terminalInputRef.current && terminalInputRef.current.focus(),
        style: { flex: showMiniTelemetry ? "0 0 65%" : "1 1 100%", borderRight: showMiniTelemetry ? `1px solid ${curTheme.border}` : "none", display: "flex", flexDirection: "column", padding: "10px 14px", fontFamily: "JetBrains Mono, monospace", fontSize: 12, overflowY: "auto", background: theme === "light" ? "#0f172a" : "#07080d", cursor: "text", color: "#f8fafc", transition: "flex 0.15s ease" }
      },
      /* @__PURE__ */ window.React.createElement("div", { style: { color: "#94a3b8", fontSize: 11, marginBottom: 8, display: "flex", justifyContent: "space-between" } }, /* @__PURE__ */ window.React.createElement("span", null, "NeloStrix NIL-STACC In-Device Execution Log"), /* @__PURE__ */ window.React.createElement("span", { style: { color: "#00d4ff" } }, "Compute: Local Host")),
      execLogs.map((log, idx) => /* @__PURE__ */ window.React.createElement(
        "pre",
        {
          key: idx,
          style: {
            fontFamily: "JetBrains Mono, monospace",
            fontSize: 12,
            lineHeight: 1.5,
            margin: "0 0 2px 0",
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            color: log.startsWith("nelostrix@") ? "#fff" : log.startsWith("[STDERR]") || log.startsWith("[ERROR]") ? "#ef4444" : log.includes("WARN") ? "#facc15" : log.includes("SUCCESS") || log.includes("NOMINAL") ? "#c8ff00" : log.includes("INFO") ? "#cbd5e1" : "#94a3b8"
          }
        },
        log
      )),
      /* @__PURE__ */ window.React.createElement("form", { onSubmit: handleTerminalSubmit, style: { marginTop: 6, display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: "#ff3d00", fontWeight: 700, whiteSpace: "nowrap" } }, "nelostrix@nil-stacc-kernel:", /* @__PURE__ */ window.React.createElement("span", { style: { color: "#00d4ff" } }, terminalCwd), "$"), /* @__PURE__ */ window.React.createElement(
        "input",
        {
          ref: terminalInputRef,
          type: "text",
          value: terminalInput,
          onChange: (e) => setTerminalInput(e.target.value),
          onKeyDown: handleTerminalKeyDown,
          placeholder: "type 'help', 'nil status', 'stacc hal', 'ls', 'pwd', 'uname -a'...",
          spellCheck: false,
          autoFocus: true,
          style: { flex: 1, background: "transparent", border: "none", outline: "none", color: "#fff", fontFamily: "JetBrains Mono, monospace", fontSize: 12 }
        }
      ))
    ), showMiniTelemetry && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", padding: "10px 14px", minWidth: 0, minHeight: 0, background: curTheme.panelBg } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontFamily: "JetBrains Mono, monospace", fontSize: 11, marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textSubtle, fontWeight: 600 } }, "STACC 1000Hz BUS"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 600 } }, "0.02ms IPC")), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", gap: 8, minHeight: 0 } }, /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, minHeight: 90, background: theme === "light" ? "#f8fafc" : "#090a0f", border: `1px solid ${curTheme.border}`, borderRadius: 4, display: "flex", flexDirection: "column", padding: "6px 10px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#ff3d00", fontWeight: 700 } }, "CHANNEL 1: J1 BASE YAW"), /* @__PURE__ */ window.React.createElement("span", { style: { fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: curTheme.text } }, jointAngles[0].toFixed(2), " rad (", j1Torque, " Nm)")), /* @__PURE__ */ window.React.createElement("canvas", { ref: chartJ1Ref, style: { flex: 1, width: "100%", height: "100%", display: "block" } })), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, minHeight: 90, background: theme === "light" ? "#f8fafc" : "#090a0f", border: `1px solid ${curTheme.border}`, borderRadius: 4, display: "flex", flexDirection: "column", padding: "6px 10px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: "#c8ff00", fontWeight: 700 } }, "CHANNEL 2: J2 SHOULDER PITCH"), /* @__PURE__ */ window.React.createElement("span", { style: { fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: curTheme.text } }, jointAngles[1].toFixed(2), " rad (", j2Torque, " Nm)")), /* @__PURE__ */ window.React.createElement("canvas", { ref: chartJ2Ref, style: { flex: 1, width: "100%", height: "100%", display: "block" } })))))) : (
      /* Reopen Strip when Dock is Collapsed */
      /* @__PURE__ */ window.React.createElement("div", { style: { height: 26, background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 12px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement(
        "button",
        {
          onClick: () => {
            setShowBottomPanel(true);
            showToast("Terminal Dock opened");
          },
          style: { background: "transparent", border: "none", color: curTheme.accent, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
        },
        /* @__PURE__ */ window.React.createElement(Icons.ChevronUp, { size: 11, color: curTheme.accent }),
        /* @__PURE__ */ window.React.createElement("span", null, "Show Terminal Dock")
      ), /* @__PURE__ */ window.React.createElement(
        "button",
        {
          onClick: () => {
            setShowBottomPanel(true);
            setShowMiniTelemetry(true);
            showToast("1000Hz Telemetry Bus opened");
          },
          style: { background: "transparent", border: "none", color: curTheme.success, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
        },
        /* @__PURE__ */ window.React.createElement(Icons.Activity, { size: 11, color: curTheme.success }),
        /* @__PURE__ */ window.React.createElement("span", null, "Show 1000Hz Bus")
      )), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "100% Height Mode (Code & 3D Simulation Maximize)"))
    )), activeActivity === "cad" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "flex", flexDirection: "column", background: curTheme.bg, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 44, background: curTheme.panelBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px", flexShrink: 0 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement(Icons.Cad, { size: 16, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 13, fontWeight: 800, color: curTheme.text } }, "3D Parametric CAD Studio")), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 8px", background: curTheme.accentGlow, color: curTheme.accent, borderRadius: 4, fontFamily: "JetBrains Mono", fontWeight: 700 } }, "ASSEMBLY: NELOSTRIX-ARM-6DOF"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "Mass: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.text } }, totalCadMass.toFixed(2), " kg"), " | Parts: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.text } }, cadParts.length))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: "1px 2px", gap: 2 } }, [
      { id: "solid", label: "Solid" },
      { id: "wireframe", label: "Wireframe" },
      { id: "xray", label: "X-Ray" }
    ].map((s) => /* @__PURE__ */ window.React.createElement(
      "button",
      {
        key: s.id,
        onClick: () => setCadShadingMode(s.id),
        style: { padding: "3px 8px", background: cadShadingMode === s.id ? curTheme.accentGlow : "transparent", color: cadShadingMode === s.id ? curTheme.accent : curTheme.textMuted, border: "none", borderRadius: 3, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer" }
      },
      s.label
    ))), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: cadCameraPreset,
        onChange: (e) => setCadCameraPreset(e.target.value),
        style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, height: 26, padding: "0 8px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "perspective", style: { background: curTheme.panelBg } }, "Perspective 3D"),
      /* @__PURE__ */ window.React.createElement("option", { value: "top", style: { background: curTheme.panelBg } }, "Top View (XY)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "front", style: { background: curTheme.panelBg } }, "Front View (XZ)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "side", style: { background: curTheme.panelBg } }, "Side View (YZ)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "iso", style: { background: curTheme.panelBg } }, "Isometric CAD")
    ), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6, background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, padding: "2px 8px", borderRadius: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "EXPLODE:"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "0.0",
        max: "1.0",
        step: "0.05",
        value: cadExplodeFactor,
        onChange: (e) => setCadExplodeFactor(parseFloat(e.target.value)),
        style: { width: 60, accentColor: curTheme.accent, cursor: "pointer" },
        title: "Exploded Assembly View"
      }
    ), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.accent, fontWeight: 700, width: 26 } }, Math.round(cadExplodeFactor * 100), "%")), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleSyncCadToRobot,
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, padding: "5px 10px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 },
        title: "Sync CAD assembly to main robotics simulation"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 11, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Sync to Robot")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleExportURDF,
        style: { background: curTheme.cardBg, color: curTheme.text, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: "5px 10px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Download, { size: 11, color: curTheme.text }),
      /* @__PURE__ */ window.React.createElement("span", null, "URDF")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleExportRIR,
        style: { background: curTheme.cardBg, color: curTheme.text, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: "5px 10px", fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.File, { size: 11, color: curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, "RIR")
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "grid", gridTemplateColumns: "280px 1fr 340px", overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, borderRight: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { padding: "10px 12px", borderBottom: `1px solid ${curTheme.border}`, background: curTheme.cardBg } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginBottom: 6, letterSpacing: 0.5 } }, "ADD CAD PRIMITIVE / LINK"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 } }, [
      { shape: "box", name: "Box Link", icon: "Layers" },
      { shape: "cylinder", name: "Cylinder", icon: "Sliders" },
      { shape: "sphere", name: "Sphere", icon: "Target" },
      { shape: "tube", name: "Hollow Tube", icon: "Sliders" },
      { shape: "bracket", name: "Bracket", icon: "Cad" },
      { shape: "flange", name: "Flange", icon: "Settings" },
      { shape: "gripper_finger", name: "Gripper Claw", icon: "Robotics" }
    ].map((p) => {
      const ShapeIcon = Icons[p.icon] || Icons.Cad;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: p.shape,
          onClick: () => handleAddCadPrimitive(p.shape),
          style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "5px 6px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", textAlign: "left", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", display: "flex", alignItems: "center", gap: 5 }
        },
        /* @__PURE__ */ window.React.createElement(ShapeIcon, { size: 11, color: curTheme.accent }),
        /* @__PURE__ */ window.React.createElement("span", null, p.name)
      );
    }))), /* @__PURE__ */ window.React.createElement("div", { style: { padding: "8px 12px", borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontWeight: 700, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "ASSEMBLY OUTLINER (", cadParts.length, ")"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, color: curTheme.accent, fontFamily: "JetBrains Mono" } }, "6-DOF Tree")), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, overflowY: "auto", padding: "6px" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 3 } }, cadParts.map((part, pIdx) => {
      const isSelected = part.id === selectedCadPartId;
      return /* @__PURE__ */ window.React.createElement(
        "div",
        {
          key: part.id,
          onClick: () => setSelectedCadPartId(part.id),
          style: {
            padding: "6px 8px",
            background: isSelected ? curTheme.cardBg : "transparent",
            border: isSelected ? `1px solid ${curTheme.accent}` : `1px solid transparent`,
            borderRadius: 4,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            cursor: "pointer"
          }
        },
        /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: 10, height: 10, borderRadius: 2, background: part.color || "#00d4ff", border: "1px solid rgba(255,255,255,0.2)", flexShrink: 0 } }), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: isSelected ? 700 : 500, color: isSelected ? curTheme.accent : curTheme.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, part.name), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, part.shape.toUpperCase(), " \u2022 ", part.massKg, "kg \u2022 ", part.material))),
        /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 2 }, onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ window.React.createElement(
          "button",
          {
            onClick: () => {
              setCadParts((prev) => prev.map((p) => p.id === part.id ? { ...p, visible: !p.visible } : p));
            },
            style: { background: "transparent", border: "none", color: part.visible ? curTheme.text : curTheme.textMuted, cursor: "pointer", padding: "2px 4px", display: "flex", alignItems: "center", justifyContent: "center" },
            title: part.visible ? "Hide Part" : "Show Part"
          },
          part.visible ? /* @__PURE__ */ window.React.createElement(Icons.Eye, { size: 12, color: curTheme.accent }) : /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 12, color: curTheme.textMuted })
        ), /* @__PURE__ */ window.React.createElement(
          "button",
          {
            onClick: () => handleDuplicateCadPart(part),
            style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", padding: "2px 4px", display: "flex", alignItems: "center", justifyContent: "center" },
            title: "Duplicate Part"
          },
          /* @__PURE__ */ window.React.createElement(Icons.Copy, { size: 11, color: curTheme.textMuted })
        ), !part.locked && /* @__PURE__ */ window.React.createElement(
          "button",
          {
            onClick: () => handleDeleteCadPart(part.id),
            style: { background: "transparent", border: "none", color: "#ff3d00", cursor: "pointer", padding: "2px 4px", display: "flex", alignItems: "center", justifyContent: "center" },
            title: "Delete Part"
          },
          /* @__PURE__ */ window.React.createElement(Icons.Trash, { size: 11, color: "#ff3d00" })
        ))
      );
    }))), /* @__PURE__ */ window.React.createElement("div", { style: { padding: "8px 12px", background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", justifyContent: "space-between", fontSize: 10, fontFamily: "JetBrains Mono" } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textSubtle } }, "TOTAL DYNAMICS"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.success, fontWeight: 700 } }, "NOMINAL (1000Hz HAL)"))), /* @__PURE__ */ window.React.createElement("div", { style: { position: "relative", background: curTheme.sceneBg, overflow: "hidden", display: "flex", flexDirection: "column" } }, /* @__PURE__ */ window.React.createElement("div", { ref: threeCadMountRef, style: { width: "100%", height: "100%" } }), selectedCadPart && /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", top: 12, left: 12, background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, backdropFilter: "blur(10px)", padding: "8px 14px", borderRadius: 6, display: "flex", flexDirection: "column", gap: 2, fontFamily: "JetBrains Mono", zIndex: 10, pointerEvents: "none" } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle } }, "SELECTED COMPONENT"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 12, fontWeight: 800, color: curTheme.accent } }, selectedCadPart.name), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textMuted, marginTop: 2 } }, "Dims: ", (selectedCadPart.dimX * 1e3).toFixed(0), " \xD7 ", (selectedCadPart.dimY * 1e3).toFixed(0), " \xD7 ", (selectedCadPart.dimZ * 1e3).toFixed(0), " mm"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textMuted } }, "Pos: [", selectedCadPart.posX.toFixed(2), ", ", selectedCadPart.posY.toFixed(2), ", ", selectedCadPart.posZ.toFixed(2), "]m \u2022 Mass: ", selectedCadPart.massKg, "kg")), /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", bottom: 12, left: 12, display: "flex", gap: 4, zIndex: 10 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setCadShowGrid(!cadShowGrid),
        style: { background: cadShowGrid ? curTheme.accentGlow : curTheme.cardBg, border: `1px solid ${cadShowGrid ? curTheme.accent : curTheme.border}`, color: cadShowGrid ? curTheme.accent : curTheme.textMuted, padding: "4px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Grid, { size: 11, color: cadShowGrid ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Grid")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setCadShowAxes(!cadShowAxes),
        style: { background: cadShowAxes ? "rgba(200,255,0,0.15)" : curTheme.cardBg, border: `1px solid ${cadShowAxes ? curTheme.success : curTheme.border}`, color: cadShowAxes ? curTheme.success : curTheme.textMuted, padding: "4px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Target, { size: 11, color: cadShowAxes ? curTheme.success : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "XYZ Axes")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", bottom: 12, right: 12, background: "rgba(0,0,0,0.6)", padding: "4px 8px", borderRadius: 4, fontSize: 9, fontFamily: "JetBrains Mono", color: "#94a3b8", pointerEvents: "none" } }, "Left-drag: Orbit | Right-drag: Pan | Wheel: Zoom")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, borderLeft: `1px solid ${curTheme.border}`, display: "flex", flexDirection: "column", overflowY: "auto" } }, /* @__PURE__ */ window.React.createElement("div", { style: { padding: "10px 14px", borderBottom: `1px solid ${curTheme.border}`, background: curTheme.cardBg } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 800, color: curTheme.text, fontFamily: "JetBrains Mono" } }, "PARAMETRIC INSPECTOR")), selectedCadPart ? /* @__PURE__ */ window.React.createElement("div", { style: { padding: 14, display: "flex", flexDirection: "column", gap: 12 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "PART NAME"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: selectedCadPart.name,
        onChange: (e) => {
          const val = e.target.value;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, name: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 8px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, outline: "none" }
      }
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "GEOMETRY SHAPE"), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: selectedCadPart.shape,
        onChange: (e) => {
          const val = e.target.value;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, shape: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 4px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "box" }, "Box / Block"),
      /* @__PURE__ */ window.React.createElement("option", { value: "cylinder" }, "Cylinder"),
      /* @__PURE__ */ window.React.createElement("option", { value: "sphere" }, "Sphere"),
      /* @__PURE__ */ window.React.createElement("option", { value: "tube" }, "Hollow Tube"),
      /* @__PURE__ */ window.React.createElement("option", { value: "bracket" }, "Bracket"),
      /* @__PURE__ */ window.React.createElement("option", { value: "flange" }, "Flange"),
      /* @__PURE__ */ window.React.createElement("option", { value: "gripper_finger" }, "Gripper Claw")
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "MATERIAL"), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: selectedCadPart.material,
        onChange: (e) => {
          const val = e.target.value;
          const densities = { aluminum: 2.7, carbon_fiber: 1.5, steel: 7.8, titanium: 4.5, polymer: 1.1 };
          const density = densities[val] || 2.7;
          const vol = selectedCadPart.dimX * selectedCadPart.dimY * selectedCadPart.dimZ;
          const newMass = Math.max(0.05, Math.round(vol * density * 1e3 * 100) / 100);
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, material: val, massKg: newMass } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 4px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "aluminum" }, "Aluminum 6061"),
      /* @__PURE__ */ window.React.createElement("option", { value: "carbon_fiber" }, "Carbon Fiber T700"),
      /* @__PURE__ */ window.React.createElement("option", { value: "titanium" }, "Titanium Ti-6Al"),
      /* @__PURE__ */ window.React.createElement("option", { value: "steel" }, "Stainless 316L"),
      /* @__PURE__ */ window.React.createElement("option", { value: "polymer" }, "Polymer ABS")
    ))), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "DIMENSIONS (X, Y, Z IN MM)"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "X (WIDTH):"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "5",
        value: Math.round(selectedCadPart.dimX * 1e3),
        onChange: (e) => {
          const val = Math.max(5, parseFloat(e.target.value) || 10) / 1e3;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, dimX: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "Y (HEIGHT):"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "5",
        value: Math.round(selectedCadPart.dimY * 1e3),
        onChange: (e) => {
          const val = Math.max(5, parseFloat(e.target.value) || 10) / 1e3;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, dimY: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "Z (DEPTH):"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "5",
        value: Math.round(selectedCadPart.dimZ * 1e3),
        onChange: (e) => {
          const val = Math.max(5, parseFloat(e.target.value) || 10) / 1e3;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, dimZ: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )))), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "TRANSLATION POSITION (X, Y, Z IN METERS)"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "POS X:"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.02",
        value: selectedCadPart.posX,
        onChange: (e) => {
          const val = parseFloat(e.target.value) || 0;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, posX: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "POS Y:"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.02",
        value: selectedCadPart.posY,
        onChange: (e) => {
          const val = parseFloat(e.target.value) || 0;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, posY: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 8, color: curTheme.textMuted } }, "POS Z:"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.02",
        value: selectedCadPart.posZ,
        onChange: (e) => {
          const val = parseFloat(e.target.value) || 0;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, posZ: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontFamily: "JetBrains Mono", fontSize: 11 }
      }
    )))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 4, padding: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 10, fontFamily: "JetBrains Mono", marginBottom: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textSubtle } }, "COMPUTED MASS:"), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 700 } }, selectedCadPart.massKg, " kg")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, "Ixx: ", (selectedCadPart.massKg * 0.012).toFixed(4), " \u2022 Iyy: ", (selectedCadPart.massKg * 0.012).toFixed(4), " \u2022 Izz: ", (selectedCadPart.massKg * 8e-3).toFixed(4), " kg\xB7m\xB2")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "JOINT TYPE"), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: selectedCadPart.jointType,
        onChange: (e) => {
          const val = e.target.value;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, jointType: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 4px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "revolute" }, "Revolute (Rotary)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "prismatic" }, "Prismatic (Linear)"),
      /* @__PURE__ */ window.React.createElement("option", { value: "fixed" }, "Fixed (Rigid)")
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("label", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", display: "block", marginBottom: 3 } }, "MAX TORQUE (NM)"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        value: selectedCadPart.maxTorqueNm,
        onChange: (e) => {
          const val = parseFloat(e.target.value) || 10;
          setCadParts((prev) => prev.map((p) => p.id === selectedCadPart.id ? { ...p, maxTorqueNm: val } : p));
        },
        style: { width: "100%", background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 6px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10 }
      }
    )))) : /* @__PURE__ */ window.React.createElement("div", { style: { padding: 20, textAlign: "center", color: curTheme.textMuted, fontSize: 11, fontFamily: "JetBrains Mono" } }, "Select a component from the outliner or 3D viewport."), /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: "auto", borderTop: `1px solid ${curTheme.border}`, background: curTheme.cardBg, padding: 12, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement(Icons.Sparkles, { size: 14, color: curTheme.accent }), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 800, color: curTheme.text, fontFamily: "JetBrains Mono" } }, "NIL AI CAD Co-Designer")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 4, overflowX: "auto" } }, [
      { label: "Gripper", icon: "Robotics", prompt: "Design a 2-finger parallel adaptive gripper with 80mm stroke" },
      { label: "Tube Link", icon: "Sliders", prompt: "Generate hollow carbon-fiber forearm link with motor bracket" },
      { label: "Bracket", icon: "Cad", prompt: "Create dual-motor mounting bracket for shoulder joint" }
    ].map((c, i) => {
      const ChipIcon = Icons[c.icon] || Icons.Cad;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: i,
          onClick: () => setCadAiPromptInput(c.prompt),
          style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.textMuted, fontSize: 9, fontFamily: "JetBrains Mono", padding: "3px 7px", borderRadius: 3, cursor: "pointer", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 4 }
        },
        /* @__PURE__ */ window.React.createElement(ChipIcon, { size: 10, color: curTheme.accent }),
        /* @__PURE__ */ window.React.createElement("span", null, c.label)
      );
    })), /* @__PURE__ */ window.React.createElement(
      "textarea",
      {
        value: cadAiPromptInput,
        onChange: (e) => setCadAiPromptInput(e.target.value),
        placeholder: "Instruct AI CAD engine (e.g. 'Design 2-finger parallel gripper', 'Add lightweight carbon link')...",
        rows: 2,
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 8px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, resize: "none", outline: "none" }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleGenerateCadWithAI,
        disabled: cadAiGenerating || !cadAiPromptInput.trim(),
        style: { width: "100%", background: curTheme.secondary, color: "#fff", border: "none", borderRadius: 4, padding: "6px", fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: cadAiGenerating || !cadAiPromptInput.trim() ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, opacity: cadAiGenerating || !cadAiPromptInput.trim() ? 0.6 : 1 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Sparkles, { size: 12, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, cadAiGenerating ? "Synthesizing CAD..." : "Generate CAD Model")
    ))))), cadExportModal && /* @__PURE__ */ window.React.createElement("div", { style: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(6px)", zIndex: 1e4, display: "flex", alignItems: "center", justifyContent: "center" }, onClick: () => setCadExportModal(null) }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, borderRadius: 8, width: 620, maxWidth: "90vw", maxHeight: "80vh", display: "flex", flexDirection: "column", boxShadow: "0 20px 50px rgba(0,0,0,0.8)", overflow: "hidden" }, onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ window.React.createElement("div", { style: { height: 44, background: curTheme.cardBg, borderBottom: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 12, fontWeight: 800, color: curTheme.text, fontFamily: "JetBrains Mono" } }, "EXPORT CAD MODEL (", cadExportModal.toUpperCase(), ")"), /* @__PURE__ */ window.React.createElement("button", { onClick: () => setCadExportModal(null), style: { background: "transparent", border: "none", color: curTheme.textMuted, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement(Icons.Close, { size: 15, color: curTheme.textMuted }))), /* @__PURE__ */ window.React.createElement("pre", { style: { margin: 0, padding: 14, background: "#08090e", color: "#a5b4fc", fontFamily: "JetBrains Mono, monospace", fontSize: 11, overflowY: "auto", flex: 1, lineHeight: 1.5 } }, /* @__PURE__ */ window.React.createElement("code", null, cadExportContent)), /* @__PURE__ */ window.React.createElement("div", { style: { height: 46, background: curTheme.cardBg, borderTop: `1px solid ${curTheme.border}`, display: "flex", alignItems: "center", justifyContent: "flex-end", padding: "0 14px", gap: 8 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          navigator.clipboard.writeText(cadExportContent);
          showToast(`Copied ${cadExportModal.toUpperCase()} to clipboard`);
        },
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, padding: "6px 14px", fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Copy, { size: 11, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Copy to Clipboard")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setCadExportModal(null),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, borderRadius: 4, padding: "6px 14px", fontSize: 11, fontFamily: "JetBrains Mono", cursor: "pointer" }
      },
      "Close"
    )))), activeActivity === "robotics" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "grid", gridTemplateColumns: "380px 1fr", background: curTheme.bg, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { borderRight: `1px solid ${curTheme.border}`, background: curTheme.panelBg, padding: "18px 20px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 14 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h2", { style: { fontSize: 18, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("span", null, "6-DOF Kinematics & Spatial Engine"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 6px", background: curTheme.accentGlow, color: curTheme.accent, borderRadius: 3, fontFamily: "JetBrains Mono", fontWeight: 700 } }, "STACC KERNEL")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 11, color: curTheme.textMuted, marginTop: 2 } }, "Direct Spatial Forward / Inverse Kinematics (DLS Solver)")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 1 } }, "JOINT ANGLE CONTROLS (RAD / DEG)"), ["J1 Base Yaw", "J2 Shoulder Pitch", "J3 Elbow Pitch", "J4 Wrist Roll", "J5 Wrist Pitch", "J6 Wrist Yaw"].map((jName, idx) => /* @__PURE__ */ window.React.createElement("div", { key: jName, style: { display: "flex", flexDirection: "column", gap: 3 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 11, fontFamily: "JetBrains Mono" } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.text } }, jName), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.accent, fontWeight: 700 } }, jointAngles[idx].toFixed(2), " rad ", /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textSubtle, fontWeight: 400 } }, "(", Math.round(jointAngles[idx] * 180 / Math.PI), "\xB0)"))), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "-3.14",
        max: "3.14",
        step: "0.02",
        value: jointAngles[idx],
        onChange: (e) => handleJogJoint(idx, e.target.value),
        style: { width: "100%", height: 3, background: curTheme.borderStrong, borderRadius: 2, outline: "none" }
      }
    )))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 1 } }, "CARTESIAN IK TARGET (END-EFFECTOR)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.success, fontWeight: 600 } }, ikStatus)), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, fontFamily: "JetBrains Mono", fontSize: 11 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted, fontSize: 10 } }, "Target X (m)"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.05",
        value: cartesianTarget.x,
        onChange: (e) => setCartesianTarget({ ...cartesianTarget, x: parseFloat(e.target.value) || 0 }),
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontSize: 11, fontFamily: "JetBrains Mono" }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted, fontSize: 10 } }, "Target Y (m)"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.05",
        value: cartesianTarget.y,
        onChange: (e) => setCartesianTarget({ ...cartesianTarget, y: parseFloat(e.target.value) || 0 }),
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontSize: 11, fontFamily: "JetBrains Mono" }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted, fontSize: 10 } }, "Target Z (m)"), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "number",
        step: "0.05",
        value: cartesianTarget.z,
        onChange: (e) => setCartesianTarget({ ...cartesianTarget, z: parseFloat(e.target.value) || 0 }),
        style: { width: "100%", background: curTheme.panelBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "4px 6px", borderRadius: 3, fontSize: 11, fontFamily: "JetBrains Mono" }
      }
    ))), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleSolveIK,
        style: { background: curTheme.accent, color: "#fff", border: "none", borderRadius: 4, padding: "7px 12px", fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, boxShadow: `0 0 10px ${curTheme.accentGlow}` }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Play, { size: 12, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Solve Inverse Kinematics (DLS)")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 1 } }, "PRESET TRAJECTORY ROUTINES"), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleRunTrajectoryPreset("home"),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "6px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer" }
      },
      "Zero / Calibrate"
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleRunTrajectoryPreset("pick_place"),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.secondary, padding: "6px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer" }
      },
      "Pick & Place Reach"
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleRunTrajectoryPreset("inspect"),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.accent, padding: "6px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer" }
      },
      "Workcell Inspect"
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleRunTrajectoryPreset("wave"),
        style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, color: curTheme.success, padding: "6px 8px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer" }
      },
      "Wave Sequence"
    )))), /* @__PURE__ */ window.React.createElement("div", { style: { position: "relative", width: "100%", height: "100%", background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("div", { style: { position: "absolute", top: 12, right: 12, zIndex: 20, display: "flex", gap: 6, flexWrap: "wrap", background: curTheme.cardBg, backdropFilter: "blur(12px)", padding: "5px 8px", borderRadius: 8, border: `1px solid ${curTheme.borderStrong}`, boxShadow: "0 8px 32px rgba(0,0,0,0.3)" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 3, paddingRight: 6, borderRight: `1px solid ${curTheme.border}` } }, ["light", "dark", "industrial", "cyberpunk"].map((tKey) => {
      const ThemePillIcon = Icons[themeConfig[tKey].icon] || Icons.Sun;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: tKey,
          onClick: () => {
            setTheme(tKey);
            showToast(`Theme: ${themeConfig[tKey].name}`);
          },
          style: { padding: "4px 7px", background: theme === tKey ? curTheme.accent : "transparent", color: theme === tKey ? "#fff" : curTheme.textMuted, border: "none", borderRadius: 4, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" },
          title: themeConfig[tKey].name
        },
        /* @__PURE__ */ window.React.createElement(ThemePillIcon, { size: 12, color: theme === tKey ? "#fff" : curTheme.textMuted })
      );
    })), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4, paddingRight: 6, borderRight: `1px solid ${curTheme.border}` } }, [
      { id: "orange", color: "#ff6a00", title: "Safety Orange" },
      { id: "silver", color: "#94a3b8", title: "Brushed Steel" },
      { id: "blue", color: "#0284c7", title: "Cobalt Blue" },
      { id: "white", color: "#f8fafc", title: "Clean White" }
    ].map((c) => /* @__PURE__ */ window.React.createElement(
      "div",
      {
        key: c.id,
        onClick: () => {
          setRobotColorPreset(c.id);
          showToast(`Robot Color: ${c.title}`);
        },
        style: {
          width: 14,
          height: 14,
          borderRadius: "50%",
          background: c.color,
          border: robotColorPreset === c.id ? `2px solid ${curTheme.accent}` : "1px solid rgba(0,0,0,0.25)",
          cursor: "pointer",
          boxShadow: robotColorPreset === c.id ? `0 0 6px ${c.color}` : "none",
          transform: robotColorPreset === c.id ? "scale(1.15)" : "scale(1)",
          transition: "all 0.15s ease"
        },
        title: c.title
      }
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 3, paddingRight: 6, borderRight: `1px solid ${curTheme.border}` } }, [
      { id: "bright", name: "Bright", icon: "SunMedium" },
      { id: "balanced", name: "Soft", icon: "Bulb" }
    ].map((l) => {
      const LightIcon = Icons[l.icon] || Icons.SunMedium;
      const isSelected = lightingBrightness === l.id;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: l.id,
          onClick: () => {
            setLightingBrightness(l.id);
            showToast(`Lighting: ${l.name}`);
          },
          style: { padding: "3px 6px", background: isSelected ? curTheme.accentGlow : "transparent", color: isSelected ? curTheme.accent : curTheme.textMuted, border: isSelected ? `1px solid ${curTheme.accent}` : "1px solid transparent", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 3 }
        },
        /* @__PURE__ */ window.React.createElement(LightIcon, { size: 11, color: isSelected ? curTheme.accent : curTheme.textMuted }),
        /* @__PURE__ */ window.React.createElement("span", null, l.name)
      );
    })), /* @__PURE__ */ window.React.createElement(
      "select",
      {
        value: cameraPreset,
        onChange: (e) => setCameraPreset(e.target.value),
        style: { background: "transparent", border: `1px solid ${curTheme.border}`, color: curTheme.text, height: 26, padding: "0 6px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, outline: "none", cursor: "pointer" }
      },
      /* @__PURE__ */ window.React.createElement("option", { value: "perspective", style: { background: curTheme.panelBg } }, "Perspective 3D"),
      /* @__PURE__ */ window.React.createElement("option", { value: "top", style: { background: curTheme.panelBg } }, "Top Workcell"),
      /* @__PURE__ */ window.React.createElement("option", { value: "side", style: { background: curTheme.panelBg } }, "Side Elevation"),
      /* @__PURE__ */ window.React.createElement("option", { value: "front", style: { background: curTheme.panelBg } }, "Front View"),
      /* @__PURE__ */ window.React.createElement("option", { value: "iso", style: { background: curTheme.panelBg } }, "Isometric CAD")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowGrid(!showGrid),
        style: { background: showGrid ? curTheme.accentGlow : "transparent", border: showGrid ? `1px solid ${curTheme.accent}` : `1px solid ${curTheme.border}`, color: showGrid ? curTheme.accent : curTheme.textMuted, padding: "2px 6px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 3 },
        title: "Toggle Floor Grid"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Grid, { size: 11, color: showGrid ? curTheme.accent : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "Grid")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => setShowAxes(!showAxes),
        style: { background: showAxes ? "rgba(200,255,0,0.15)" : "transparent", border: showAxes ? "1px solid #c8ff00" : `1px solid ${curTheme.border}`, color: showAxes ? "#c8ff00" : curTheme.textMuted, padding: "2px 6px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 3 },
        title: "Toggle Cartesian Axes"
      },
      /* @__PURE__ */ window.React.createElement(Icons.Target, { size: 11, color: showAxes ? "#c8ff00" : curTheme.textMuted }),
      /* @__PURE__ */ window.React.createElement("span", null, "TCP")
    )), /* @__PURE__ */ window.React.createElement("div", { ref: threeMountRef, style: { width: "100%", height: "100%" } }))), activeActivity === "hardware" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, padding: 22, overflowY: "auto", display: "flex", flexDirection: "column", gap: 16, background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h1", { style: { fontSize: 20, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("span", null, "STACC Real-Time HAL Bus & Actuator Drivers"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 8px", background: curTheme.accentGlow, color: curTheme.accent, border: `1px solid ${curTheme.accent}`, borderRadius: 3, fontFamily: "JetBrains Mono", fontWeight: 700 } }, "1000Hz SHARED MEMORY BUS")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 11, color: curTheme.textMuted, marginTop: 2 } }, "SharedMemoryBus: 'stacc_main' @ 1000Hz | Latency: 0.018ms | Safety Cutoff: 85\xB0C | Zero-Copy RingBuffer")), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleToggleEStop,
        style: { background: eStopActive ? "#ef4444" : "#dc2626", color: "#fff", border: "none", padding: "8px 20px", borderRadius: 6, fontFamily: "JetBrains Mono", fontSize: 12, fontWeight: 800, cursor: "pointer", boxShadow: eStopActive ? "0 0 20px #ef4444" : "0 0 10px rgba(220,38,38,0.4)", display: "flex", alignItems: "center", gap: 8 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Stop, { size: 14, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, eStopActive ? "EMERGENCY STOPPED (RESET)" : "EMERGENCY E-STOP")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 16 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 11, fontFamily: "JetBrains Mono", marginBottom: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted } }, "Impedance Stiffness (Kp)"), /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.accent } }, kpGain.toFixed(1), " Nm/rad")), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "50",
        max: "500",
        step: "5",
        value: kpGain,
        onChange: (e) => {
          setKpGain(parseFloat(e.target.value));
          showToast(`Kp set to ${e.target.value} Nm/rad`);
        },
        style: { width: "100%", height: 3, background: curTheme.borderStrong, borderRadius: 2 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 11, fontFamily: "JetBrains Mono", marginBottom: 4 } }, /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.textMuted } }, "Impedance Damping (Kd)"), /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.success } }, kdGain.toFixed(1), " Nms/rad")), /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "range",
        min: "5",
        max: "100",
        step: "1",
        value: kdGain,
        onChange: (e) => {
          setKdGain(parseFloat(e.target.value));
          showToast(`Kd set to ${e.target.value} Nms/rad`);
        },
        style: { width: "100%", height: 3, background: curTheme.borderStrong, borderRadius: 2 }
      }
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "THERMAL CUTOFF THRESHOLD"), /* @__PURE__ */ window.React.createElement("strong", { style: { fontSize: 13, color: curTheme.text, fontFamily: "JetBrains Mono", marginTop: 2 } }, "85.0\xB0C (Auto-Decel)")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", justifyContent: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "MAX DECEL RATE"), /* @__PURE__ */ window.React.createElement("strong", { style: { fontSize: 13, color: curTheme.secondary, fontFamily: "JetBrains Mono", marginTop: 2 } }, "45.0 rad/s\xB2 (Active)"))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 } }, actuators.map((act) => /* @__PURE__ */ window.React.createElement("div", { key: act.id, style: { background: curTheme.cardBg, border: eStopActive ? "1px solid rgba(239,68,68,0.4)" : `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 13, fontWeight: 800, color: curTheme.text } }, act.id, " \u2014 ", act.name), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", padding: "2px 6px", background: act.status === "NOMINAL" ? "rgba(200,255,0,0.12)" : "rgba(239,68,68,0.2)", color: act.status === "NOMINAL" ? curTheme.success : "#ef4444", borderRadius: 3, fontWeight: 700 } }, act.status)), /* @__PURE__ */ window.React.createElement("div", { style: { marginTop: 10, display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6, fontFamily: "JetBrains Mono", fontSize: 11 } }, /* @__PURE__ */ window.React.createElement("div", null, "Temp: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: act.temp > 50 ? "#ff3d00" : curTheme.text } }, act.temp, "\xB0C")), /* @__PURE__ */ window.React.createElement("div", null, "Voltage: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.accent } }, act.voltage, " V")), /* @__PURE__ */ window.React.createElement("div", null, "Current: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.text } }, act.current, " A")), /* @__PURE__ */ window.React.createElement("div", null, "Max Limit: ", /* @__PURE__ */ window.React.createElement("strong", { style: { color: curTheme.textMuted } }, act.maxTorque, " Nm")))))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle } }, "LIVE 1000HZ CAN / ETHERCAT BUS TELEMETRY FRAMES"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.accent } }, "Rate: 1,000 frames/sec (0.018ms)")), /* @__PURE__ */ window.React.createElement("div", { style: { background: theme === "light" ? "#0f172a" : "#07080d", borderRadius: 4, padding: "8px 12px", fontFamily: "JetBrains Mono", fontSize: 10, lineHeight: 1.6, color: "#94a3b8" } }, /* @__PURE__ */ window.React.createElement("div", null, "[0x141 J1_BASE] POS: ", jointAngles[0].toFixed(3), " rad | VEL: +0.024 rad/s | TRQ: ", j1Torque, " Nm | TEMP: 38.4\xB0C | STATUS: OK_0x00"), /* @__PURE__ */ window.React.createElement("div", null, "[0x142 J2_SHLDR] POS: ", jointAngles[1].toFixed(3), " rad | VEL: -0.018 rad/s | TRQ: ", j2Torque, " Nm | TEMP: 42.1\xB0C | STATUS: OK_0x00"), /* @__PURE__ */ window.React.createElement("div", null, "[0x143 J3_ELBOW] POS: ", jointAngles[2].toFixed(3), " rad | VEL: +0.005 rad/s | TRQ: 5.3 Nm | TEMP: 39.8\xB0C | STATUS: OK_0x00"), /* @__PURE__ */ window.React.createElement("div", null, "[0x144 J4_WRIST1] POS: ", jointAngles[3].toFixed(3), " rad | VEL: 0.000 rad/s | TRQ: 2.1 Nm | TEMP: 35.2\xB0C | STATUS: OK_0x00"), /* @__PURE__ */ window.React.createElement("div", null, "[0x145 J5_WRIST2] POS: ", jointAngles[4].toFixed(3), " rad | VEL: +0.002 rad/s | TRQ: 1.0 Nm | TEMP: 36.0\xB0C | STATUS: OK_0x00"), /* @__PURE__ */ window.React.createElement("div", null, "[0x146 J6_WRIST3] POS: ", jointAngles[5].toFixed(3), " rad | VEL: 0.000 rad/s | TRQ: 0.4 Nm | TEMP: 34.5\xB0C | STATUS: OK_0x00")))), activeActivity === "ai" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, display: "grid", gridTemplateColumns: "320px 1fr 340px", background: curTheme.bg, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { borderRight: `1px solid ${curTheme.border}`, background: curTheme.panelBg, padding: "16px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 12 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h2", { style: { fontSize: 16, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 8 } }, /* @__PURE__ */ window.React.createElement("span", null, "NIL Cognitive Engine"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 6px", background: curTheme.accentGlow, color: curTheme.accent, borderRadius: 3, fontFamily: "JetBrains Mono", fontWeight: 700 } }, "7-STAGE PIPELINE")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 11, color: curTheme.textMuted, marginTop: 2 } }, "Closed-Loop In-Device Evolutionary Synthesis")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6 } }, evolutionStages.map((st, i) => /* @__PURE__ */ window.React.createElement("div", { key: st.name, style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 5, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 3 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: curTheme.text } }, i + 1, ". ", st.name), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: st.status === "ACTIVE" ? curTheme.accent : st.status === "SYNTHESIZING" ? curTheme.secondary : curTheme.success, fontWeight: 700 } }, st.status)), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textMuted, fontFamily: "JetBrains Mono" } }, st.desc), /* @__PURE__ */ window.React.createElement("div", { style: { width: "100%", height: 3, background: curTheme.borderStrong, borderRadius: 2, overflow: "hidden", marginTop: 2 } }, /* @__PURE__ */ window.React.createElement("div", { style: { width: `${st.pct}%`, height: "100%", background: curTheme.accent } }))))), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: handleTriggerEvolution,
        style: { background: curTheme.secondary, color: "#fff", border: "none", borderRadius: 4, padding: "8px 12px", fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, boxShadow: `0 0 12px ${curTheme.accentGlow}` }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 12, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Trigger In-Device Evolution")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", background: curTheme.panelBg, borderRight: `1px solid ${curTheme.border}`, minHeight: 0, overflow: "hidden" } }, /* @__PURE__ */ window.React.createElement("div", { style: { padding: "12px 16px", borderBottom: `1px solid ${curTheme.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h3", { style: { fontSize: 14, fontWeight: 800, color: curTheme.text } }, "7-Tier Cognitive Memory Store (Active DAG)"), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 10, color: curTheme.textMuted, marginTop: 1 } }, "Working \u2192 Episodic \u2192 Semantic \u2192 Procedural \u2192 Associative \u2192 Reflective \u2192 Sensorimotor")), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.success, fontWeight: 700 } }, "1,842 MEMORY TRACES")), /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, minHeight: 0, position: "relative", background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("canvas", { ref: topoCanvasRef, style: { width: "100%", height: "100%", display: "block" } }))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, padding: "16px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 14 } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h3", { style: { fontSize: 14, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ window.React.createElement("span", null, "Synthesized Skill Registry"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "1px 6px", background: "rgba(200,255,0,0.12)", color: curTheme.success, borderRadius: 3, fontFamily: "JetBrains Mono" } }, "58 SKILLS")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 10, color: curTheme.textMuted, marginTop: 2 } }, "Auto-Synthesized Motor & Perception Policies")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 6 } }, proceduralSkills.map((sk) => /* @__PURE__ */ window.React.createElement("div", { key: sk.name, style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 5, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 2 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: curTheme.text } }, sk.name), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.accent, fontWeight: 700 } }, sk.confidence, "% CONF")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.textMuted } }, /* @__PURE__ */ window.React.createElement("span", null, "Calls: ", sk.calls), /* @__PURE__ */ window.React.createElement("span", { style: { color: curTheme.success } }, sk.status))))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 10, display: "flex", flexDirection: "column", gap: 6 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle } }, "POLICY CONVERGENCE REWARD"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 9, fontFamily: "JetBrains Mono", color: curTheme.success } }, "+94.8% Reward")), /* @__PURE__ */ window.React.createElement("canvas", { ref: curvesCanvasRef, style: { height: 110, width: "100%", display: "block" } })))), activeActivity === "telemetry" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, padding: 22, overflowY: "auto", display: "flex", flexDirection: "column", gap: 16, background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h1", { style: { fontSize: 20, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("span", null, "High-Precision 1000Hz Telemetry & Signal Stream"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 8px", background: curTheme.accentGlow, color: curTheme.accent, border: `1px solid ${curTheme.accent}`, borderRadius: 3, fontFamily: "JetBrains Mono", fontWeight: 700 } }, "4-CHANNEL OSCILLOSCOPE")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 11, color: curTheme.textMuted, marginTop: 2 } }, "STACC Zero-Copy RingBuffer | 1,000 samples/sec | Bandwidth: 3.2 MB/s | Jitter: < 0.002ms")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 4, background: curTheme.cardBg, padding: 3, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, ["1x", "2x", "5x", "10x"].map((scale) => /* @__PURE__ */ window.React.createElement(
      "button",
      {
        key: scale,
        onClick: () => setTelemetryTimeScale(scale),
        style: { padding: "4px 8px", background: telemetryTimeScale === scale ? curTheme.accent : "transparent", color: telemetryTimeScale === scale ? "#fff" : curTheme.textMuted, border: "none", borderRadius: 3, fontSize: 10, fontFamily: "JetBrains Mono", fontWeight: 700, cursor: "pointer" }
      },
      scale
    ))), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          const csvContent = "data:text/csv;charset=utf-8,timestamp,j1_torque,j2_torque,j1_pos,j2_pos,velocity_error\n" + Array.from({ length: 20 }, (_, i) => `${i * 1e-3},${(14.2 + Math.sin(i) * 2).toFixed(2)},${(8.7 + Math.cos(i)).toFixed(2)},${(0.25 + Math.sin(i * 0.5) * 0.1).toFixed(3)},${(-0.45 + Math.cos(i * 0.5) * 0.1).toFixed(3)},0.0024`).join("\n");
          const encodedUri = encodeURI(csvContent);
          const link = document.createElement("a");
          link.setAttribute("href", encodedUri);
          link.setAttribute("download", "stacc_1000hz_telemetry.csv");
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          showToast("Exported stacc_1000hz_telemetry.csv");
        },
        style: { background: curTheme.cardBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "6px 14px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Download, { size: 13, color: curTheme.text }),
      /* @__PURE__ */ window.React.createElement("span", null, "Export CSV Dataset")
    ))), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 } }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: "#ff3d00", fontFamily: "JetBrains Mono" } }, "CHANNEL A: JOINT TORQUE OSCILLOSCOPE (Nm)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.text } }, "J1: ", j1Torque, " Nm | J2: ", j2Torque, " Nm")), /* @__PURE__ */ window.React.createElement("canvas", { ref: sigCanvasRefA, style: { height: 160, width: "100%", display: "block" } })), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: "#c8ff00", fontFamily: "JetBrains Mono" } }, "CHANNEL B: ANGULAR VELOCITY SPECTRUM (rad/s)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.text } }, "RMS: \xB10.024 rad/s")), /* @__PURE__ */ window.React.createElement("canvas", { ref: sigCanvasRefB, style: { height: 160, width: "100%", display: "block" } })), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: "#00d4ff", fontFamily: "JetBrains Mono" } }, "CHANNEL C: CLOSED-LOOP TRACKING ERROR (rad)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.text } }, "Mean Error: 0.0008 rad")), /* @__PURE__ */ window.React.createElement("canvas", { ref: sigCanvasRefC, style: { height: 160, width: "100%", display: "block" } })), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", flexDirection: "column" } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontWeight: 700, color: "#a855f7", fontFamily: "JetBrains Mono" } }, "CHANNEL D: HIGH-FREQUENCY FFT VIBRATION (Hz)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.text } }, "Resonance Peak: 48.2 Hz (Safe)")), /* @__PURE__ */ window.React.createElement("canvas", { ref: sigCanvasRefD, style: { height: 160, width: "100%", display: "block" } })))), activeActivity === "twin" && /* @__PURE__ */ window.React.createElement("div", { style: { flex: 1, padding: 22, overflowY: "auto", display: "flex", flexDirection: "column", gap: 16, background: curTheme.bg } }, /* @__PURE__ */ window.React.createElement("div", null, /* @__PURE__ */ window.React.createElement("h1", { style: { fontSize: 20, fontWeight: 800, color: curTheme.text, display: "flex", alignItems: "center", gap: 10 } }, /* @__PURE__ */ window.React.createElement("span", null, "Digital Twin, In-Device Compute & Multi-Agent Engine"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, padding: "2px 8px", background: "rgba(200,255,0,0.12)", color: curTheme.success, border: `1px solid ${curTheme.success}`, borderRadius: 3, fontFamily: "JetBrains Mono", fontWeight: 700 } }, hwStatus.accelerator || "IN-DEVICE", " ACTIVE")), /* @__PURE__ */ window.React.createElement("p", { style: { fontFamily: "JetBrains Mono", fontSize: 11, color: curTheme.textMuted, marginTop: 2 } }, "Hardware: ", hwStatus.vram_status?.[0]?.device || "AMD Ryzen 3 7320U with Radeon Graphics", " | OS: ", hwStatus.os_name || "Linux x86_64", " | RAM: ", hwStatus.ram_free_gb || 2.15, " GB Available / ", hwStatus.ram_total_gb || 7, " GB Total (", hwStatus.ram_percent || 69, "% Used)")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 } }, /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, padding: 10, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "HOST SYSTEM RAM (LIVE)"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: curTheme.accent, marginTop: 2 } }, hwStatus.ram_used_gb || 4.85, " GB ", /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textMuted } }, "/ ", hwStatus.ram_total_gb || 7, " GB")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginTop: 2 } }, hwStatus.ram_percent || 69.3, "% Allocated (", hwStatus.ram_free_gb || 2.15, " GB Free)")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, padding: 10, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "CPU PROCESSOR CORES"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: curTheme.success, marginTop: 2 } }, hwStatus.cpu_cores || 8, " Active Threads"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginTop: 2 } }, "Load: ", hwStatus.cpu_load_avg ? hwStatus.cpu_load_avg.join(", ") : "1.35, 2.06, 2.02")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, padding: 10, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "GPU / ACCELERATOR VRAM"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: curTheme.text, marginTop: 2 } }, hwStatus.vram_status?.[0]?.total_gb || 3.5, " GB ", /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, color: curTheme.textMuted } }, "Shared")), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, hwStatus.vram_status?.[0]?.device ? hwStatus.vram_status[0].device.includes("[") ? hwStatus.vram_status[0].device.split("[")[1].replace("]", "") : hwStatus.vram_status[0].device : "AMD Radeon 610M")), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.cardBg, padding: 10, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 10, color: curTheme.textSubtle, fontFamily: "JetBrains Mono" } }, "LOCAL MODELS ON DISK"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: "#a855f7", marginTop: 2 } }, hwStatus.installed_models_count || models.length, " Models Found"), /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 9, color: curTheme.textSubtle, fontFamily: "JetBrains Mono", marginTop: 2 } }, "HuggingFace Hub / Local Cache"))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 10 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 1 } }, "REAL IN-DEVICE MODEL REGISTRY (DISCOVERED ON LOCAL DISK)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.accent } }, "Zero Cloud Dependency")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10, maxHeight: 220, overflowY: "auto" } }, models.map((m) => /* @__PURE__ */ window.React.createElement("div", { key: m.id, style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 12, display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("div", { style: { minWidth: 0, paddingRight: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { fontSize: 12, fontWeight: 800, color: curTheme.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, m.name), /* @__PURE__ */ window.React.createElement("div", { style: { fontFamily: "JetBrains Mono", fontSize: 10, color: curTheme.textMuted, marginTop: 3 } }, "Category: ", m.category, " \xA0|\xA0 Disk: ", m.size, " \xA0|\xA0 VRAM: ", m.vram), m.local_path && /* @__PURE__ */ window.React.createElement("div", { style: { fontFamily: "JetBrains Mono", fontSize: 9, color: curTheme.textSubtle, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, m.local_path)), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => {
          setModels((prev) => prev.map((x) => x.id === m.id ? { ...x, running: !x.running } : x));
          showToast(`${m.name}: Toggled state`);
        },
        style: { background: m.running ? "rgba(200,255,0,0.15)" : curTheme.panelBg, border: m.running ? `1px solid ${curTheme.success}` : `1px solid ${curTheme.border}`, color: m.running ? curTheme.success : curTheme.textMuted, padding: "5px 12px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 10, fontWeight: 700, cursor: "pointer", flexShrink: 0 }
      },
      m.running ? "ACTIVE" : "STANDBY"
    ))))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 12 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle, letterSpacing: 1 } }, "AUTONOMOUS MULTI-AGENT ENGINEERING DISPATCHER (REAL SUBAGENT RUNTIME)"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.accent } }, "6 Subagents Available")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 6 } }, [
      { id: "architect", name: "Architect", icon: "Cad" },
      { id: "controls", name: "Controls", icon: "Sliders" },
      { id: "perception", name: "Perception", icon: "Eye" },
      { id: "simulation", name: "Simulation", icon: "Flask" },
      { id: "debugging", name: "Debugging", icon: "Bug" },
      { id: "deployment", name: "Deployment", icon: "Rocket" }
    ].map((ag) => {
      const AgIcon = Icons[ag.icon] || Icons.Brain;
      const isSelected = selectedAgent === ag.id;
      return /* @__PURE__ */ window.React.createElement(
        "button",
        {
          key: ag.id,
          onClick: () => setSelectedAgent(ag.id),
          style: { padding: "6px 4px", background: isSelected ? curTheme.accentGlow : curTheme.cardBg, border: isSelected ? `1px solid ${curTheme.accent}` : `1px solid ${curTheme.border}`, color: isSelected ? curTheme.accent : curTheme.textMuted, borderRadius: 4, fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 5 }
        },
        /* @__PURE__ */ window.React.createElement(AgIcon, { size: 12, color: isSelected ? curTheme.accent : curTheme.textMuted }),
        /* @__PURE__ */ window.React.createElement("span", null, ag.name)
      );
    })), /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" } }, /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleDispatchAgentTask("Evaluate optimal joint impedance parameters for high-speed pick maneuvers"),
        style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "5px 10px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 11, color: curTheme.accent }),
      /* @__PURE__ */ window.React.createElement("span", null, "Tune Impedance for 5kg Payload")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleDispatchAgentTask("Benchmark MuJoCo contact physics at 1000Hz stepping"),
        style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "5px 10px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Flask, { size: 11, color: curTheme.secondary }),
      /* @__PURE__ */ window.React.createElement("span", null, "Verify Collision Bounds in MuJoCo")
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        onClick: () => handleDispatchAgentTask("Compile synthesized procedural skill candidate to C++"),
        style: { background: curTheme.cardBg, border: `1px solid ${curTheme.border}`, color: curTheme.text, padding: "5px 10px", borderRadius: 4, fontSize: 10, fontFamily: "JetBrains Mono", cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Rocket, { size: 11, color: curTheme.success }),
      /* @__PURE__ */ window.React.createElement("span", null, "Compile Skill to C++ Shared Library")
    )), /* @__PURE__ */ window.React.createElement("form", { onSubmit: (e) => {
      e.preventDefault();
      handleDispatchAgentTask();
    }, style: { display: "flex", gap: 8 } }, /* @__PURE__ */ window.React.createElement(
      "input",
      {
        type: "text",
        value: agentPromptInput,
        onChange: (e) => setAgentPromptInput(e.target.value),
        placeholder: `Ask ${selectedAgent.toUpperCase()} Agent (e.g. 'Optimize joint damping ratio', 'Analyze collision mesh')...`,
        style: { flex: 1, background: curTheme.cardBg, border: `1px solid ${curTheme.borderStrong}`, color: curTheme.text, padding: "8px 12px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, outline: "none" }
      }
    ), /* @__PURE__ */ window.React.createElement(
      "button",
      {
        type: "submit",
        style: { background: curTheme.secondary, color: "#fff", border: "none", padding: "8px 18px", borderRadius: 4, fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }
      },
      /* @__PURE__ */ window.React.createElement(Icons.Zap, { size: 12, color: "#fff" }),
      /* @__PURE__ */ window.React.createElement("span", null, "Dispatch")
    )), /* @__PURE__ */ window.React.createElement("div", { style: { background: theme === "light" ? "#0f172a" : "#07080d", borderRadius: 4, padding: "10px 14px", fontFamily: "JetBrains Mono", fontSize: 11, lineHeight: 1.5, maxHeight: 160, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 } }, agentResponses.map((res, i) => /* @__PURE__ */ window.React.createElement("div", { key: i, style: { color: "#cbd5e1" } }, /* @__PURE__ */ window.React.createElement("strong", { style: { color: res.agent.includes("Controls") ? "#00d4ff" : res.agent.includes("Simulation") ? "#c8ff00" : "#ff3d00" } }, "[", res.agent, "]"), " ", res.text)))), /* @__PURE__ */ window.React.createElement("div", { style: { background: curTheme.panelBg, border: `1px solid ${curTheme.border}`, borderRadius: 6, padding: 14, display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ window.React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } }, /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 11, fontFamily: "JetBrains Mono", fontWeight: 700, color: curTheme.textSubtle } }, "DIGITAL TWIN REAL-TIME SYNCHRONIZATION MATRIX"), /* @__PURE__ */ window.React.createElement("span", { style: { fontSize: 10, fontFamily: "JetBrains Mono", color: curTheme.success } }, "FK Cartesian TCP: X=", (Math.cos(jointAngles[0]) * (0.35 * Math.cos(jointAngles[1]) + 0.3 * Math.cos(jointAngles[1] + jointAngles[2]))).toFixed(3), "m, Y=", (Math.sin(jointAngles[0]) * (0.35 * Math.cos(jointAngles[1]) + 0.3 * Math.cos(jointAngles[1] + jointAngles[2]))).toFixed(3), "m, Z=", (0.2 + 0.35 * Math.sin(jointAngles[1]) + 0.3 * Math.sin(jointAngles[1] + jointAngles[2])).toFixed(3), "m")), /* @__PURE__ */ window.React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8, fontFamily: "JetBrains Mono", fontSize: 11 } }, ["J1 Base Yaw", "J2 Shoulder Pitch", "J3 Elbow Pitch", "J4 Wrist Roll", "J5 Wrist Pitch", "J6 Wrist Yaw"].map((j, i) => /* @__PURE__ */ window.React.createElement("div", { key: j, style: { background: curTheme.cardBg, padding: 8, borderRadius: 4, border: `1px solid ${curTheme.border}` } }, /* @__PURE__ */ window.React.createElement("div", { style: { color: curTheme.textMuted, fontSize: 10 } }, j), /* @__PURE__ */ window.React.createElement("div", { style: { color: curTheme.accent, fontWeight: 700, marginTop: 2 } }, jointAngles[i].toFixed(3), " rad"), /* @__PURE__ */ window.React.createElement("div", { style: { color: curTheme.textSubtle, fontSize: 9, marginTop: 1 } }, (jointAngles[i] * 180 / Math.PI).toFixed(1), "\xB0 \xA0|\xA0 \u0394 0.0004 rad"))))))));
  };
  var App_default = App;
  return __toCommonJS(App_exports);
})();
